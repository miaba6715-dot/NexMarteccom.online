import React, { useState } from 'react';
import {
  X,
  Copy,
  Check,
  QrCode,
  ShieldCheck,
  Wallet,
  Coins,
  AlertCircle,
  ArrowRight,
  Sparkles,
  Search,
  Globe,
} from 'lucide-react';
import { UserProfile, Transaction } from '../types';
import { NATIONAL_LANGUAGES } from '../languages';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onAddTransaction: (tx: Transaction) => void;
  modalType: 'deposit' | 'withdraw' | 'about' | 'services' | 'invite' | 'withdrawal-account' | 'language' | null;
  onSelectLanguage?: (lang: string) => void;
  currentLanguage?: string;
}

export const Modals: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onAddTransaction,
  modalType,
  onSelectLanguage,
  currentLanguage = 'English',
}) => {
  const [copied, setCopied] = useState(false);
  const [depositAmount, setDepositAmount] = useState('100');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawPass, setWithdrawPass] = useState('');
  const [walletInput, setWalletInput] = useState(user.withdrawalAddress || 'TJ8YxP4rZ5mNk6Qv9tW2e1...8q9vK2');
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);
  const [languageSearch, setLanguageSearch] = useState('');

  if (!isOpen || !modalType) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDepositSubmit = (autoApprove: boolean = true) => {
    const num = parseFloat(depositAmount);
    if (isNaN(num) || num <= 0) return;

    if (autoApprove) {
      onUpdateUser({ balance: Number((user.balance + num).toFixed(2)) });
      onAddTransaction({
        id: `tx-${Date.now()}`,
        type: 'deposit',
        amount: num,
        status: 'Approved',
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
        method: 'USDT (TRC20)',
        txHash: `0x${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`,
      });
      setActionSuccessMessage(`Deposit of $${num.toFixed(2)} approved! Your balance has been updated.`);
    } else {
      onAddTransaction({
        id: `tx-${Date.now()}`,
        type: 'deposit',
        amount: num,
        status: 'Pending',
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
        method: 'USDT (TRC20)',
        txHash: `0x${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`,
      });
      setActionSuccessMessage(`Deposit of $${num.toFixed(2)} submitted for admin review! Check the Backend Admin to approve it.`);
    }

    setTimeout(() => {
      setActionSuccessMessage(null);
      onClose();
    }, 2500);
  };

  const handleWithdrawSubmit = () => {
    const num = parseFloat(withdrawAmount);
    if (isNaN(num) || num <= 0) {
      alert('Please enter a valid amount');
      return;
    }
    if (num > user.balance) {
      alert('Withdrawal amount exceeds your current balance!');
      return;
    }
    if (num < 30) {
      alert('Minimum withdrawal amount is $30.00');
      return;
    }

    // Deduct and create transaction
    onUpdateUser({ balance: Number((user.balance - num).toFixed(2)) });
    onAddTransaction({
      id: `tx-${Date.now()}`,
      type: 'withdraw',
      amount: num,
      status: 'Pending',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      method: 'USDT (TRC20)',
      account: user.withdrawalAddress,
    });

    setActionSuccessMessage(`Withdrawal request of $${num.toFixed(2)} submitted successfully! Pending approval.`);
    setTimeout(() => {
      setActionSuccessMessage(null);
      onClose();
    }, 2500);
  };

  const filteredLanguages = NATIONAL_LANGUAGES.filter((lang) => {
    const q = languageSearch.toLowerCase().trim();
    if (!q) return true;
    return (
      lang.label.toLowerCase().includes(q) ||
      lang.native.toLowerCase().includes(q) ||
      lang.country.toLowerCase().includes(q) ||
      lang.code.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl relative border border-gray-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Success Banner */}
        {actionSuccessMessage && (
          <div className="p-4 bg-emerald-500 text-white font-medium text-sm text-center flex items-center justify-center gap-2">
            <Check className="w-4 h-4" />
            <span>{actionSuccessMessage}</span>
          </div>
        )}

        {/* DEPOSIT MODAL */}
        {modalType === 'deposit' && (
          <div className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-[#1877f2]">
                <Coins className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Recharge / Deposit</h3>
                <p className="text-xs text-gray-500">Fast credit via USDT TRC20 network</p>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4">
              <div className="text-xs text-blue-800 flex items-center justify-between">
                <span>Current Account Balance:</span>
                <span className="font-bold text-base text-[#1877f2]">${user.balance.toFixed(2)}</span>
              </div>
            </div>

            {/* Network Selector */}
            <div className="mb-4">
              <label className="text-xs font-semibold text-gray-600 mb-1.5 block">Select Deposit Network</label>
              <div className="grid grid-cols-2 gap-2">
                <div className="border-2 border-[#1877f2] bg-blue-50/50 rounded-lg p-2.5 text-center cursor-pointer">
                  <span className="font-bold text-xs text-[#1877f2] block">USDT (TRC20)</span>
                  <span className="text-[10px] text-gray-500">Fast & Zero Gas</span>
                </div>
                <div className="border border-gray-200 rounded-lg p-2.5 text-center cursor-pointer hover:border-gray-300">
                  <span className="font-bold text-xs text-gray-700 block">USDT (ERC20)</span>
                  <span className="text-[10px] text-gray-400">Ethereum Mainnet</span>
                </div>
              </div>
            </div>

            {/* QR Code & Address */}
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200 flex flex-col items-center mb-4">
              <div className="bg-white p-2 rounded-lg shadow-xs border border-gray-200 mb-2">
                <QrCode className="w-28 h-28 text-gray-800" />
              </div>
              <span className="text-[11px] text-gray-400 mb-1">Official TRC20 Deposit Address:</span>
              <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-300 w-full justify-between">
                <span className="font-mono text-xs text-gray-800 truncate select-all">
                  TYm89kL9xQv77bZ4w1a2b3c4d5e6f7g8h9
                </span>
                <button
                  onClick={() => handleCopy('TYm89kL9xQv77bZ4w1a2b3c4d5e6f7g8h9')}
                  className="text-[#1877f2] hover:text-[#166fe5] p-1 flex items-center gap-1 text-xs font-semibold"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Quick Amount Selection */}
            <div className="mb-4">
              <label className="text-xs font-semibold text-gray-600 mb-1.5 block">Select Deposit Amount (USDT)</label>
              <div className="grid grid-cols-4 gap-2 mb-2">
                {['50', '100', '200', '500'].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setDepositAmount(amt)}
                    className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                      depositAmount === amt
                        ? 'bg-[#1877f2] text-white shadow-xs'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
              <input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Enter custom amount"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1877f2]"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <button
                onClick={() => handleDepositSubmit(true)}
                className="w-full py-2.5 bg-[#1877f2] hover:bg-[#166fe5] text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
              >
                Instant Simulated Deposit (+${depositAmount || '0'})
              </button>
              <button
                onClick={() => handleDepositSubmit(false)}
                className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium text-xs rounded-xl transition-colors"
              >
                Submit Deposit to Admin Approval Queue
              </button>
            </div>
          </div>
        )}

        {/* WITHDRAW MODAL */}
        {modalType === 'withdraw' && (
          <div className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-[#1877f2]">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Withdraw Funds</h3>
                <p className="text-xs text-gray-500">Transfer your profit to your bound wallet</p>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-4">
              <div className="text-xs text-gray-600 flex justify-between items-center mb-1">
                <span>Available Balance:</span>
                <span className="text-base font-bold text-[#1877f2]">${user.balance.toFixed(2)}</span>
              </div>
              <div className="text-[11px] text-gray-500 flex justify-between">
                <span>Completed Orders Today:</span>
                <span className="font-semibold text-gray-800">{user.completedOrders}/{user.totalOrders}</span>
              </div>
            </div>

            <div className="space-y-3.5 mb-5">
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Withdrawal Address (TRC20)</label>
                <div className="bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-xs font-mono text-gray-700">
                  {user.withdrawalAddress || 'TJ8YxP4...8q9vK2'}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-gray-600">Amount to Withdraw</label>
                  <button
                    onClick={() => setWithdrawAmount(user.balance.toString())}
                    className="text-[11px] text-[#1877f2] font-bold hover:underline"
                  >
                    Withdraw All
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-gray-400 font-bold">$</span>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="Min $30.00"
                    className="w-full pl-7 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1877f2]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Transaction Password</label>
                <input
                  type="password"
                  value={withdrawPass}
                  onChange={(e) => setWithdrawPass(e.target.value)}
                  placeholder="Enter 6-digit transaction PIN"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1877f2]"
                />
              </div>

              <div className="bg-gray-50 rounded-lg p-2.5 text-[11px] text-gray-500 space-y-1">
                <div className="flex justify-between">
                  <span>Handling Fee:</span>
                  <span className="text-emerald-600 font-bold">$0.00 (VIP 1 Free)</span>
                </div>
                <div className="flex justify-between">
                  <span>Arrival Time:</span>
                  <span>10 - 30 minutes</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleWithdrawSubmit}
              className="w-full py-2.5 bg-[#1877f2] hover:bg-[#166fe5] text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
            >
              Confirm Withdrawal
            </button>
          </div>
        )}

        {/* WITHDRAWAL ACCOUNT MODAL */}
        {modalType === 'withdrawal-account' && (
          <div className="p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-1">Bind Withdrawal Account</h3>
            <p className="text-xs text-gray-500 mb-4">Set your permanent cryptocurrency wallet address for instant payouts.</p>

            <div className="space-y-3 mb-5">
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Full Real Name</label>
                <input
                  type="text"
                  defaultValue="Mia Reynolds"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1877f2]"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">Currency / Network</label>
                <input
                  type="text"
                  readOnly
                  value="USDT (TRC-20 Network)"
                  className="w-full px-3 py-2 text-sm bg-gray-50 border border-gray-300 rounded-lg text-gray-600 font-medium cursor-not-allowed"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-600 block mb-1">USDT-TRC20 Wallet Address</label>
                <input
                  type="text"
                  value={walletInput}
                  onChange={(e) => setWalletInput(e.target.value)}
                  placeholder="Paste your Tron (TRC20) address starting with T"
                  className="w-full px-3 py-2 text-sm font-mono border border-gray-300 rounded-lg focus:outline-hidden focus:border-[#1877f2]"
                />
              </div>
            </div>

            <button
              onClick={() => {
                onUpdateUser({ withdrawalAddress: walletInput });
                setActionSuccessMessage('Withdrawal account successfully updated!');
                setTimeout(() => {
                  setActionSuccessMessage(null);
                  onClose();
                }, 1500);
              }}
              className="w-full py-2.5 bg-[#1877f2] hover:bg-[#166fe5] text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
            >
              Save Account Details
            </button>
          </div>
        )}

        {/* ABOUT US MODAL */}
        {modalType === 'about' && (
          <div className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-[#1877f2] mb-3 mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 text-center mb-1">About Boss Ecomm Marketing</h3>
            <span className="text-[11px] text-center block text-gray-400 mb-4 font-mono">Reg. No. BEM-99420-US</span>

            <div className="space-y-3 text-xs text-gray-600 leading-relaxed max-h-60 overflow-y-auto pr-1">
              <p>
                <strong>Boss Ecomm Marketing (BEM)</strong> is an enterprise cloud optimization platform partnering directly with tier-1 e-commerce merchants on Amazon, Shopify, and Walmart.
              </p>
              <p>
                Through algorithmic order simulation and product rank promotion, members assist global merchants in boosting listing visibility and sales velocity while earning guaranteed profit commissions on each submitted order.
              </p>
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-3">
                <h4 className="font-bold text-gray-800 mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#1877f2]" />
                  Authorized Partner Privileges
                </h4>
                <ul className="list-disc pl-4 space-y-1 text-[11px] text-gray-600">
                  <li>Daily real-time settlement of commissions</li>
                  <li>Automated order distribution system</li>
                  <li>100% financial security and verified escrow protection</li>
                  <li>Tiered VIP promotion bonuses and team rewards</li>
                </ul>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full mt-5 py-2.5 bg-[#1877f2] text-white font-bold text-sm rounded-xl hover:bg-[#166fe5] transition-colors"
            >
              Close
            </button>
          </div>
        )}

        {/* INVITE FRIENDS MODAL */}
        {modalType === 'invite' && (
          <div className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-[#1877f2] mb-3 mx-auto">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 text-center mb-1">Invite Friends & Earn</h3>
            <p className="text-xs text-center text-gray-500 mb-4">
              Get up to 16% commission reward for every order completed by your team!
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4 text-center">
              <span className="text-xs text-gray-500 block mb-1">Your Exclusive Invitation Code:</span>
              <div className="flex items-center justify-center gap-2">
                <span className="font-mono text-2xl font-black text-[#1877f2] tracking-widest">{user.referralCode}</span>
                <button
                  onClick={() => handleCopy(user.referralCode)}
                  className="p-1.5 bg-white border border-blue-200 rounded-md text-[#1877f2] hover:bg-blue-100"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="mb-4">
              <span className="text-xs text-gray-500 block mb-1">Your Referral Link:</span>
              <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg p-2">
                <span className="text-xs text-gray-700 font-mono truncate flex-1">
                  https://boostmarketingwithus.com/register?code={user.referralCode}
                </span>
                <button
                  onClick={() => handleCopy(`https://boostmarketingwithus.com/register?code=${user.referralCode}`)}
                  className="px-2.5 py-1 bg-[#1877f2] text-white rounded text-xs font-bold hover:bg-[#166fe5]"
                >
                  Copy
                </button>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-3 text-xs space-y-2 border border-gray-200">
              <div className="font-bold text-gray-800 mb-1">Team Commission Structure:</div>
              <div className="flex justify-between items-center text-gray-600">
                <span>Tier 1 Direct Invite:</span>
                <span className="font-bold text-[#1877f2]">16% of Order Commission</span>
              </div>
              <div className="flex justify-between items-center text-gray-600">
                <span>Tier 2 Secondary Invite:</span>
                <span className="font-bold text-blue-600">8% of Order Commission</span>
              </div>
              <div className="flex justify-between items-center text-gray-600">
                <span>Tier 3 Tertiary Invite:</span>
                <span className="font-bold text-blue-400">4% of Order Commission</span>
              </div>
            </div>
          </div>
        )}

        {/* LANGUAGE MODAL - All Country National Languages */}
        {modalType === 'language' && (
          <div className="p-5 sm:p-6">
            <div className="flex items-center gap-2.5 mb-1.5">
              <div className="w-8 h-8 rounded-full bg-blue-50 text-[#1877f2] flex items-center justify-center shrink-0">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-gray-900 leading-tight">National Languages</h3>
                <p className="text-[11px] sm:text-xs text-gray-500">Select your country's national or official language</p>
              </div>
            </div>

            {/* Search Bar */}
            <div className="relative mt-3.5 mb-3">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={languageSearch}
                onChange={(e) => setLanguageSearch(e.target.value)}
                placeholder="Search by country or language (e.g., Pakistan, Urdu, USA, Spanish)..."
                className="w-full pl-9 pr-8 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:border-[#1877f2] focus:bg-white transition-all"
              />
              {languageSearch && (
                <button
                  onClick={() => setLanguageSearch('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-0.5 text-xs font-bold"
                  title="Clear search"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Quick Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 no-scrollbar text-[11px]">
              {['All', 'English', 'Urdu', 'Arabic', 'Español', 'Français', 'Deutsch', 'Hindi', 'Chinese'].map((quick) => {
                const isActive = (quick === 'All' && !languageSearch) || languageSearch.toLowerCase() === quick.toLowerCase();
                return (
                  <button
                    key={quick}
                    onClick={() => setLanguageSearch(quick === 'All' ? '' : quick)}
                    className={`px-2.5 py-0.5 rounded-full whitespace-nowrap transition-colors font-medium ${
                      isActive
                        ? 'bg-[#1877f2] text-white'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                    }`}
                  >
                    {quick}
                  </button>
                );
              })}
            </div>

            {/* Language Count */}
            <div className="flex items-center justify-between text-[11px] text-gray-400 mb-2 px-1">
              <span>Showing {filteredLanguages.length} national languages</span>
              <span className="text-[#1877f2] font-semibold">Active: {currentLanguage}</span>
            </div>

            {/* Scrollable Language Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[380px] overflow-y-auto pr-1">
              {filteredLanguages.map((lang) => {
                const isSelected =
                  currentLanguage === lang.label ||
                  currentLanguage === lang.native ||
                  currentLanguage.startsWith(lang.label.split(' ')[0]);

                return (
                  <button
                    key={lang.code}
                    onClick={() => {
                      if (onSelectLanguage) onSelectLanguage(lang.label);
                      onClose();
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#1877f2] bg-blue-50/70 text-[#1877f2] shadow-xs'
                        : 'border-gray-100 hover:border-blue-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 pr-1.5">
                      <span className="text-xl shrink-0 leading-none">{lang.flag}</span>
                      <div className="flex flex-col min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-xs text-gray-900 truncate">{lang.label}</span>
                          {lang.native !== lang.label && (
                            <span className="text-[10px] text-gray-400 truncate">({lang.native})</span>
                          )}
                        </div>
                        <span className="text-[10px] text-gray-400 truncate">{lang.country}</span>
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-[#1877f2] shrink-0" />}
                  </button>
                );
              })}

              {filteredLanguages.length === 0 && (
                <div className="col-span-full py-8 text-center text-gray-400 text-xs">
                  No national languages found matching "{languageSearch}".
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
