import React, { useState, useEffect } from 'react';
import { Briefcase, Calendar, CheckCircle, Award, Sparkles, AlertCircle } from 'lucide-react';
import { UserProfile, Transaction } from '../types';
import { isSalaryClaimedToday, markSalaryClaimedToday } from '../services/notificationService';

interface SalaryViewProps {
  user: UserProfile;
  onClaimSalary: (amount: number) => void;
}

export const SalaryView: React.FC<SalaryViewProps> = ({ user, onClaimSalary }) => {
  const [claimedToday, setClaimedToday] = useState(isSalaryClaimedToday());
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    setClaimedToday(isSalaryClaimedToday());

    const handleSync = () => {
      setClaimedToday(isSalaryClaimedToday());
    };
    window.addEventListener('bam_salary_claimed_updated', handleSync);
    return () => window.removeEventListener('bam_salary_claimed_updated', handleSync);
  }, []);

  const dailySalary = user.currentVipLevel === 3 ? 50 : user.currentVipLevel === 2 ? 30 : 15;

  const handleClaim = () => {
    if (user.completedOrders < 1) {
      alert('You must complete at least 1 order today before claiming daily attendance salary!');
      return;
    }
    if (claimedToday) return;

    markSalaryClaimedToday();
    setClaimedToday(true);
    onClaimSalary(dailySalary);
    setToastMsg(`Daily salary of $${dailySalary}.00 claimed successfully!`);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const salaryTiers = [
    { rank: 'VIP 1 (Amazon)', minBalance: '$30.00', dailySalary: '$15.00', monthlyEst: '$450.00', teamReward: '16%' },
    { rank: 'VIP 2 (Shopify)', minBalance: '$499.00', dailySalary: '$30.00', monthlyEst: '$900.00', teamReward: '20%' },
    { rank: 'VIP 3 (Walmart)', minBalance: '$900.00', dailySalary: '$50.00', monthlyEst: '$1,500.00', teamReward: '25%' },
  ];

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-[#1877f2] rounded-2xl p-5 text-white shadow-md text-center">
        <h1 className="text-xl font-extrabold tracking-tight mb-1">Salary & Rewards</h1>
        <p className="text-xs text-blue-100">Daily attendance bonuses and official agency compensation</p>
      </div>

      {/* Claim Attendance Card */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-gray-100">
        <div className="flex items-center justify-between pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-[#1877f2] flex items-center justify-center">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-gray-900">Daily Attendance Salary</h3>
              <span className="text-xs text-gray-500">
                VIP {user.currentVipLevel} base: <strong className="text-emerald-600">${dailySalary}.00/day</strong>
              </span>
            </div>
          </div>

          <button
            disabled={claimedToday}
            onClick={handleClaim}
            className={`px-4 py-2 rounded-xl font-bold text-xs transition-all ${
              claimedToday
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-[#1877f2] hover:bg-[#166fe5] text-white shadow-xs'
            }`}
          >
            {claimedToday ? 'Claimed Today' : 'Sign In & Claim'}
          </button>
        </div>

        {toastMsg && (
          <div className="mt-3 bg-emerald-50 text-emerald-700 p-2.5 rounded-lg text-xs font-semibold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>{toastMsg}</span>
          </div>
        )}

        <div className="mt-3 text-[11px] text-gray-500 flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#1877f2] flex-shrink-0" />
          <span>Requirement: Must complete at least 1 order per day to be eligible for salary.</span>
        </div>
      </div>

      {/* Salary Structure Table */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-gray-100">
        <h3 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
          <Award className="w-4 h-4 text-[#1877f2]" />
          VIP Salary Compensation Structure
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-gray-200 text-gray-500 text-[10px] uppercase">
                <th className="py-2 font-bold">VIP Rank</th>
                <th className="py-2 font-bold">Min Balance</th>
                <th className="py-2 font-bold">Daily Salary</th>
                <th className="py-2 font-bold">Monthly Est.</th>
                <th className="py-2 font-bold text-right">Team Rebate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-gray-700">
              {salaryTiers.map((tier, idx) => (
                <tr
                  key={idx}
                  className={idx + 1 === user.currentVipLevel ? 'bg-blue-50/50 font-bold' : ''}
                >
                  <td className="py-2.5 text-gray-900 flex items-center gap-1.5">
                    <span>{tier.rank}</span>
                    {idx + 1 === user.currentVipLevel && (
                      <span className="bg-[#1877f2] text-white text-[9px] px-1.5 py-0.2 rounded-sm font-semibold">
                        CURRENT
                      </span>
                    )}
                  </td>
                  <td className="py-2.5">{tier.minBalance}</td>
                  <td className="py-2.5 text-emerald-600 font-bold">{tier.dailySalary}</td>
                  <td className="py-2.5 text-gray-900 font-semibold">{tier.monthlyEst}</td>
                  <td className="py-2.5 text-right text-[#1877f2] font-bold">{tier.teamReward}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Platform Guarantee & Rules */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs text-xs text-gray-600 space-y-2">
        <h4 className="font-bold text-gray-900 flex items-center gap-1.5">
          <Briefcase className="w-4 h-4 text-[#1877f2]" />
          Platform Agency Contract Guidelines:
        </h4>
        <p className="text-[11px] leading-relaxed text-gray-500">
          - Salaries are distributed directly to account balance and can be withdrawn immediately.
        </p>
        <p className="text-[11px] leading-relaxed text-gray-500">
          - Active agents who maintain 5+ direct referrals on VIP 1 or above qualify for the weekly manager bonus of $150.00.
        </p>
      </div>
    </div>
  );
};
