import React from 'react';
import { Home, Clock, ShoppingCart, Briefcase, User } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onSelectTab }) => {
  const tabs = [
    { id: 'home' as ActiveTab, label: 'Home', icon: Home },
    { id: 'history' as ActiveTab, label: 'History', icon: Clock },
    { id: 'order' as ActiveTab, label: 'Start/Order', icon: ShoppingCart },
    { id: 'salary' as ActiveTab, label: 'Salary', icon: Briefcase },
    { id: 'profile' as ActiveTab, label: 'My Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 shadow-[0_-2px_10px_rgba(0,0,0,0.04)]">
      <div className="max-w-md sm:max-w-xl md:max-w-3xl lg:max-w-5xl xl:max-w-6xl mx-auto flex items-center justify-around h-16 px-2 sm:px-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              id={`nav-btn-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center flex-1 h-full relative transition-colors cursor-pointer ${
                isActive ? 'text-[#1877f2]' : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              {/* Active top line indicator */}
              {isActive && (
                <span className="absolute top-0 w-12 sm:w-16 h-[3px] bg-[#1877f2] rounded-full" />
              )}
              
              <div className="relative">
                <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>

              <span className={`text-[11px] sm:text-xs mt-1 whitespace-nowrap ${isActive ? 'text-[#1877f2] font-bold' : 'text-gray-600 font-medium'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
