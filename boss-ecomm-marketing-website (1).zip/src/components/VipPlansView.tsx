import React from 'react';
import { UserProfile, VipPlan } from '../types';
import { AmazonLogo, ShopifyLogo, WalmartLogo } from './BrandLogos';
import { ArrowUp, Lock } from 'lucide-react';

interface VipPlansViewProps {
  user: UserProfile;
  vipPlans: VipPlan[];
  onSelectVip: (level: number) => void;
  onOpenDeposit: () => void;
}

// Five-Point Classic White Crown Icon matching Image 2
const CrownIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4 text-white" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M5 16L3 6L8.5 10.5L12 4L15.5 10.5L21 6L19 16H5ZM5 18C5 18.5523 5.44772 19 6 19H18C18.5523 19 19 18.5523 19 18V17H5V18Z" />
  </svg>
);

// 3-Bar Ascending Chart Icon with rounded pill bars matching Image 2
const BarChartIcon: React.FC<{ color?: string; className?: string }> = ({
  color = "#0062ff",
  className = "w-4 h-4",
}) => (
  <svg viewBox="0 0 24 24" className={className} fill="none">
    <rect x="3" y="14" width="4" height="7" rx="1.5" fill={color} />
    <rect x="10" y="9" width="4" height="12" rx="1.5" fill={color} />
    <rect x="17" y="4" width="4" height="17" rx="1.5" fill={color} />
  </svg>
);

// Flat Wallet Outline Icon matching Image 2
const StatWalletIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5 text-white" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M21 7H4C3.45 7 3 7.45 3 8V18C3 19.1 3.9 20 5 20H20C21.1 20 22 19.1 22 18V8C22 7.45 21.55 7 21 7ZM20 18H5V9H20V18ZM20 4H7C6.45 4 6 4.45 6 5C6 5.55 6.45 6 7 6H20V4Z" />
    <circle cx="16.5" cy="13.5" r="1.5" />
  </svg>
);

// Stacked 3 Coins Icon matching Image 2
const StatCoinsIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5 text-white" }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <ellipse cx="12" cy="6" rx="8" ry="3" />
    <path d="M4 6V11C4 12.66 7.58 14 12 14C16.42 14 20 12.66 20 11V6" />
    <path d="M4 11V16C4 17.66 7.58 19 12 19C16.42 19 20 17.66 20 16V11" />
  </svg>
);

// Circle Checkmark Icon matching Image 2
const CircleCheckIcon: React.FC<{ color?: string; className?: string }> = ({
  color = "#00c875",
  className = "w-4.5 h-4.5",
}) => (
  <svg viewBox="0 0 24 24" className={className} fill="none">
    <circle cx="12" cy="12" r="10" fill={color} />
    <path
      d="M8 12.2L10.8 15L16.2 9.5"
      stroke="white"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const VipPlansView: React.FC<VipPlansViewProps> = ({
  user,
  vipPlans,
  onSelectVip,
  onOpenDeposit,
}) => {
  // Exact configurations matching Image 2
  const plansConfig = [
    {
      level: 1,
      name: 'VIP 1',
      badgeProfit: 'Profit 4%',
      profitRateText: '4%',
      headerGradient: 'from-[#0062ff] to-[#0070f3]',
      badgeBg: 'bg-[#0047ba]/70',
      brand: 'amazon',
      barColor: '#0062ff',
      minBalance: 50.0,
      totalBalance: 50.0,
      statBg: 'bg-[#f0f6ff]',
      statIconBg: 'bg-[#0062ff]',
      checkColor: '#00a368',
      buttonGradient: 'from-[#0055ff] to-[#0077ff]',
      buttonShadow: 'shadow-[0_6px_22px_rgba(0,102,255,0.35)]',
      isUnlocked: true,
    },
    {
      level: 2,
      name: 'VIP 2',
      badgeProfit: 'Profit 8%',
      profitRateText: '8%',
      headerGradient: 'from-[#00c875] to-[#00b060]',
      badgeBg: 'bg-[#008f4c]/60',
      brand: 'shopify',
      barColor: '#00c875',
      minBalance: 99.0,
      totalBalance: 99.0,
      statBg: 'bg-[#eefbf6]',
      statIconBg: 'bg-[#00c875]',
      checkColor: '#00c875',
      buttonGradient: 'from-[#00c875] to-[#00aa55]',
      buttonShadow: 'shadow-[0_6px_22px_rgba(0,200,117,0.3)]',
      isUnlocked: user.balance >= 99.0,
    },
    {
      level: 3,
      name: 'VIP 3',
      badgeProfit: 'Profit 8%', // Matches screenshot 2 pill text
      profitRateText: '12%',
      headerGradient: 'from-[#2563eb] to-[#1d4ed8]',
      badgeBg: 'bg-[#1e40af]/70',
      brand: 'walmart',
      barColor: '#2563eb',
      minBalance: 100.0,
      totalBalance: 100.0,
      statBg: 'bg-[#f0f6ff]',
      statIconBg: 'bg-[#2563eb]',
      checkColor: '#2563eb',
      buttonGradient: 'from-[#3b82f6] to-[#2563eb]',
      buttonShadow: 'shadow-[0_6px_22px_rgba(37,99,235,0.3)]',
      isUnlocked: user.balance >= 100.0,
    },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* 3 VIP Cards Grid (EXACT MATCH FOR IMAGE 2) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6">
        {plansConfig.map((card) => {
          return (
            <div
              key={card.level}
              className="bg-white rounded-[26px] sm:rounded-[30px] overflow-hidden shadow-[0_10px_32px_rgba(0,0,0,0.06)] border border-blue-50/70 flex flex-col justify-between transition-all duration-200 hover:shadow-[0_16px_40px_rgba(0,0,0,0.09)]"
            >
              {/* Card Header Bar */}
              <div
                className={`bg-gradient-to-r ${card.headerGradient} text-white px-5 sm:px-6 py-3.5 sm:py-4 flex items-center justify-between font-bold`}
              >
                <div className="flex items-center gap-2">
                  <CrownIcon className="w-5 h-5 text-white drop-shadow-xs" />
                  <span className="text-base sm:text-lg font-black tracking-tight text-white">
                    {card.name}
                  </span>
                </div>

                <div
                  className={`${card.badgeBg} backdrop-blur-xs px-3.5 py-1 rounded-full text-xs font-bold text-white shadow-xs`}
                >
                  {card.badgeProfit}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between">
                <div>
                  {/* Brand Logo Area */}
                  <div className="flex items-center justify-center min-h-[70px] sm:min-h-[85px] my-2">
                    {card.brand === 'amazon' && (
                      <AmazonLogo className="h-10 sm:h-12" />
                    )}
                    {card.brand === 'shopify' && (
                      <ShopifyLogo className="h-11 sm:h-13" />
                    )}
                    {card.brand === 'walmart' && (
                      <WalmartLogo className="h-9 sm:h-11" />
                    )}
                  </div>

                  {/* Subtitle with 3-Bar Chart Icon */}
                  <div className="flex items-center justify-center gap-2.5 my-3 text-center">
                    <BarChartIcon color={card.barColor} className="w-4 h-4 shrink-0" />
                    <span className="text-xs sm:text-[13px] text-gray-700 font-medium leading-snug">
                      Get a VIP level with {card.profitRateText} profit rate
                    </span>
                  </div>

                  {/* Stat Box 1: Minimum Balance */}
                  <div
                    className={`${card.statBg} rounded-2xl p-3 sm:p-3.5 flex items-center gap-3.5 mb-3 border border-transparent`}
                  >
                    <div
                      className={`w-11 h-11 rounded-xl ${card.statIconBg} text-white flex items-center justify-center shrink-0 shadow-xs`}
                    >
                      <StatWalletIcon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-xs text-gray-500 font-medium">
                        Minimum Balance:
                      </span>
                      <span className="text-lg sm:text-xl font-black text-[#0f294a] leading-tight">
                        ${card.minBalance.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Stat Box 2: Total Balance */}
                  <div
                    className={`${card.statBg} rounded-2xl p-3 sm:p-3.5 flex items-center gap-3.5 mb-4 border border-transparent`}
                  >
                    <div
                      className={`w-11 h-11 rounded-xl ${card.statIconBg} text-white flex items-center justify-center shrink-0 shadow-xs`}
                    >
                      <StatCoinsIcon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-xs text-gray-500 font-medium">
                        Total Balance
                      </span>
                      <span className="text-lg sm:text-xl font-black text-[#0f294a] leading-tight">
                        ${card.totalBalance.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Completed Orders Status */}
                  <div className="flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-gray-700 mb-4">
                    <CircleCheckIcon color={card.checkColor} className="w-4.5 h-4.5 shrink-0" />
                    <span>
                      Completed Orders:{' '}
                      <span className="text-[#0062ff] font-extrabold">
                        {user.completedOrders}/{user.totalOrders}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Bottom Action Button */}
                <div>
                  {card.isUnlocked ? (
                    <button
                      type="button"
                      onClick={() => onSelectVip(card.level)}
                      className={`w-full py-3 sm:py-3.5 bg-gradient-to-r ${card.buttonGradient} hover:opacity-95 text-white font-extrabold text-sm sm:text-base rounded-2xl ${card.buttonShadow} flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98`}
                    >
                      <ArrowUp className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
                      <span>Upgrade Now</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={onOpenDeposit}
                      title={`Deposit to unlock ${card.name}`}
                      className={`w-full py-3 sm:py-3.5 bg-gradient-to-r ${card.buttonGradient} hover:opacity-95 text-white font-extrabold text-sm sm:text-base rounded-2xl ${card.buttonShadow} flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98`}
                    >
                      <Lock className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
                      <span>Locked</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* How VIP Levels Work Section (Added in Start/Order) */}
      <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 shadow-[0_4px_24px_rgba(0,0,0,0.05)] border border-blue-50/80 mt-6 sm:mt-8">
        <div className="flex items-center gap-2.5 pb-3.5 mb-4 border-b border-gray-100">
          <div className="w-8 h-8 rounded-xl bg-blue-50 text-[#0062ff] flex items-center justify-center font-black text-sm">
            ✦
          </div>
          <h3 className="text-lg sm:text-xl font-black text-[#0f294a] tracking-tight">
            How VIP Levels Work
          </h3>
        </div>

        <ul className="space-y-3 sm:space-y-3.5 text-xs sm:text-sm text-gray-700 font-medium leading-relaxed">
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              <strong className="font-bold text-[#0f294a]">VIP 1:</strong> Activated when your account balance reaches $30 or more.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              <strong className="font-bold text-[#0f294a]">VIP 2:</strong> Activated when your account balance reaches $499 or more.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              <strong className="font-bold text-[#0f294a]">VIP 3:</strong> Activated when your account balance reaches $900 or more.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              Higher VIP levels provide better profit percentages and increased earning potential.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              Once you unlock a higher VIP level, the lower VIP levels will automatically become locked.
            </span>
          </li>
          <li className="flex items-start gap-3">
            <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 shadow-2xs">
              ✓
            </span>
            <span>
              Your VIP status upgrades automatically as soon as you reach the required balance — no manual action needed.
            </span>
          </li>
        </ul>
      </div>
    </div>
  );
};
