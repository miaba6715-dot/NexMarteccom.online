import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  CreditCard,
  Search,
  FileSpreadsheet,
  PlusCircle,
  Layers,
  Key,
  Headphones,
  MessageSquare,
  Globe,
  LogOut,
  ExternalLink,
  Trash2,
  Eye,
  RefreshCw,
  MoreVertical,
  Users,
  DollarSign,
  Package,
  CheckCircle2,
  Clock,
  Check,
  X,
  Copy,
  UploadCloud,
  FileText,
  Send,
  UserCheck,
  AlertCircle,
  Wallet,
} from 'lucide-react';
import {
  UserProfile,
  AdminSidebarItem,
  OrderItem,
  AdminWithdrawalRecord,
  AdminDepositRecord,
  AdminRecoveryRequest,
  AdminConversation,
} from '../types';
import {
  INITIAL_ADMIN_WITHDRAWALS,
  INITIAL_ADMIN_DEPOSITS,
  INITIAL_RECOVERY_REQUESTS,
  INITIAL_CONVERSATIONS,
} from '../data';

interface AdminBackendProps {
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onVisitSite: () => void;
  productPool: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[];
  onAddProduct: (product: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>) => void;
  onSetProductPool?: (products: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[]) => void;
}

export const AdminBackend: React.FC<AdminBackendProps> = ({
  user,
  onUpdateUser,
  onVisitSite,
  productPool,
  onAddProduct,
  onSetProductPool,
}) => {
  const [activeMenu, setActiveMenu] = useState<AdminSidebarItem>('dashboard');
  const [withdrawals, setWithdrawals] = useState<AdminWithdrawalRecord[]>(() => {
    try {
      const stored = localStorage.getItem('bam_admin_withdrawals');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const validStored = parsed.filter(
            (w: any) =>
              w.username?.toLowerCase() !== 'kali' &&
              w.username?.toLowerCase() !== 'rani' &&
              w.userCode !== '992812' &&
              w.userCode !== '441029'
          );
          return validStored;
        }
      }
    } catch (e) {}
    return INITIAL_ADMIN_WITHDRAWALS.filter(
      (w) =>
        w.username?.toLowerCase() !== 'kali' &&
        w.username?.toLowerCase() !== 'rani' &&
        w.userCode !== '992812' &&
        w.userCode !== '441029'
    );
  });
  const [deposits, setDeposits] = useState<AdminDepositRecord[]>(() => {
    try {
      const stored = localStorage.getItem('bam_admin_deposits');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const validStored = parsed.filter(
            (d: any) =>
              d.username?.toLowerCase() !== 'kali' &&
              d.username?.toLowerCase() !== 'rani' &&
              d.userCode !== '992812' &&
              d.userCode !== '441029'
          );
          return validStored;
        }
      }
    } catch (e) {}
    return INITIAL_ADMIN_DEPOSITS.filter(
      (d) =>
        d.username?.toLowerCase() !== 'kali' &&
        d.username?.toLowerCase() !== 'rani' &&
        d.userCode !== '992812' &&
        d.userCode !== '441029'
    );
  });
  const [recoveryRequests, setRecoveryRequests] = useState<AdminRecoveryRequest[]>(() => {
    try {
      const stored = localStorage.getItem('bam_admin_recovery');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.filter(
            (r: any) =>
              r.matchedUsername?.toLowerCase() !== 'kali' &&
              r.matchedUsername?.toLowerCase() !== 'rani' &&
              r.userCode !== '992812' &&
              r.userCode !== '441029'
          );
        }
      }
    } catch (e) {}
    return INITIAL_RECOVERY_REQUESTS.filter(
      (r) =>
        r.matchedUsername?.toLowerCase() !== 'kali' &&
        r.matchedUsername?.toLowerCase() !== 'rani' &&
        r.userCode !== '992812' &&
        r.userCode !== '441029'
    );
  });
  const [conversations, setConversations] = useState<AdminConversation[]>(() => {
    try {
      const stored = localStorage.getItem('bam_admin_conversations');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const validStored = parsed.filter(
            (c: any) =>
              c.username?.toLowerCase() !== 'kali' &&
              c.username?.toLowerCase() !== 'rani' &&
              c.userCode !== '992812' &&
              c.userCode !== '441029'
          );
          // Persist the cleaned array back into localStorage so stale items don't linger
          try {
            localStorage.setItem('bam_admin_conversations', JSON.stringify(validStored));
          } catch (e) {}

          const parsedCodes = new Set(validStored.map((p: any) => p.userCode));
          const rest = INITIAL_CONVERSATIONS.filter(
            (c) =>
              !parsedCodes.has(c.userCode) &&
              c.username?.toLowerCase() !== 'kali' &&
              c.username?.toLowerCase() !== 'rani' &&
              c.userCode !== '992812' &&
              c.userCode !== '441029'
          );
          return [...validStored, ...rest];
        }
      }
    } catch (e) {
      console.warn('Failed to load admin conversations', e);
    }
    return INITIAL_CONVERSATIONS.filter(
      (c) =>
        c.username?.toLowerCase() !== 'kali' &&
        c.username?.toLowerCase() !== 'rani' &&
        c.userCode !== '992812' &&
        c.userCode !== '441029'
    );
  });
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [chatReplyText, setChatReplyText] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Live Chat Support Mode (Online = smart auto-reply; Offline = manual admin response only)
  const [chatMode, setChatMode] = useState<'online' | 'offline'>(() => {
    try {
      const mode = localStorage.getItem('bam_chat_mode');
      if (mode === 'offline' || mode === 'online') return mode;
    } catch (e) {}
    return 'online';
  });

  const handleToggleChatMode = (newMode: 'online' | 'offline') => {
    setChatMode(newMode);
    try {
      localStorage.setItem('bam_chat_mode', newMode);
      window.dispatchEvent(new Event('bam_chat_mode_changed'));
    } catch (e) {}
    showToast(
      `Live Chat is now ${newMode.toUpperCase()} mode${
        newMode === 'offline' ? ' (Auto-reply disabled: Admin will reply manually)' : ' (Smart auto-reply active)'
      }`
    );
  };

  // Real-time synchronization for customer conversations, withdrawals, deposits & mode changes
  useEffect(() => {
    const handleSync = () => {
      try {
        // Sync conversations
        const stored = localStorage.getItem('bam_admin_conversations');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const valid = parsed.filter(
              (c: any) =>
                c.username?.toLowerCase() !== 'kali' &&
                c.username?.toLowerCase() !== 'rani' &&
                c.userCode !== '992812' &&
                c.userCode !== '441029'
            );
            if (valid.length !== parsed.length) {
              try {
                localStorage.setItem('bam_admin_conversations', JSON.stringify(valid));
              } catch (e) {}
            }
            setConversations((prev) => {
              if (JSON.stringify(prev) !== JSON.stringify(valid)) {
                return valid;
              }
              return prev;
            });
          }
        }

        // Sync withdrawals
        const storedW = localStorage.getItem('bam_admin_withdrawals');
        if (storedW) {
          const parsedW = JSON.parse(storedW);
          if (Array.isArray(parsedW)) {
            const validW = parsedW.filter(
              (w: any) =>
                w.username?.toLowerCase() !== 'kali' &&
                w.username?.toLowerCase() !== 'rani' &&
                w.userCode !== '992812' &&
                w.userCode !== '441029'
            );
            if (validW.length !== parsedW.length) {
              try {
                localStorage.setItem('bam_admin_withdrawals', JSON.stringify(validW));
              } catch (e) {}
            }
            setWithdrawals((prev) => {
              if (JSON.stringify(prev) !== JSON.stringify(validW)) {
                return validW;
              }
              return prev;
            });
          }
        }

        // Sync deposits
        const storedD = localStorage.getItem('bam_admin_deposits');
        if (storedD) {
          const parsedD = JSON.parse(storedD);
          if (Array.isArray(parsedD)) {
            const validD = parsedD.filter(
              (d: any) =>
                d.username?.toLowerCase() !== 'kali' &&
                d.username?.toLowerCase() !== 'rani' &&
                d.userCode !== '992812' &&
                d.userCode !== '441029'
            );
            if (validD.length !== parsedD.length) {
              try {
                localStorage.setItem('bam_admin_deposits', JSON.stringify(validD));
              } catch (e) {}
            }
            setDeposits((prev) => {
              if (JSON.stringify(prev) !== JSON.stringify(validD)) {
                return validD;
              }
              return prev;
            });
          }
        }

        const mode = localStorage.getItem('bam_chat_mode');
        if (mode === 'online' || mode === 'offline') {
          setChatMode((prev) => (prev !== mode ? mode : prev));
        }
      } catch (e) {}
    };

    window.addEventListener('storage', handleSync);
    window.addEventListener('bam_chat_update', handleSync);
    window.addEventListener('bam_chat_mode_changed', handleSync);
    const timer = setInterval(handleSync, 1000);

    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('bam_chat_update', handleSync);
      window.removeEventListener('bam_chat_mode_changed', handleSync);
      clearInterval(timer);
    };
  }, []);

  // Update Balance State (Screenshot 4)
  const [balanceInviteCode, setBalanceInviteCode] = useState('');
  const [balanceAmount, setBalanceAmount] = useState('0');
  const [balanceActionType, setBalanceActionType] = useState<'add' | 'subtract'>('add');

  // User Finder State (Screenshot 5)
  const [searchUserCode, setSearchUserCode] = useState('');
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  // CSV Upload State (Screenshot 6)
  const [csvInviteCode, setCsvInviteCode] = useState('');
  const [csvUploadedFileName, setCsvUploadedFileName] = useState<string | null>(null);
  const [csvParsedProducts, setCsvParsedProducts] = useState<Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[]>([]);

  // Single Order Upload State (Screenshot 7)
  const [singlePlatform, setSinglePlatform] = useState('Amazon (4%)');
  const [singleTitle, setSingleTitle] = useState('');
  const [singleAmount, setSingleAmount] = useState('0.00');
  const [singleCommission, setSingleCommission] = useState('0.00');
  const [singleTotalProfit, setSingleTotalProfit] = useState('0.00');
  const [singleInviteCode, setSingleInviteCode] = useState('');

  // Combine Orders Upload State (Screenshot 8)
  const [combinePlatform, setCombinePlatform] = useState('Amazon (4%)');
  const [combineTitle, setCombineTitle] = useState('');
  const [combineAmount, setCombineAmount] = useState('0.00');
  const [combineCommission, setCombineCommission] = useState('0.00');
  const [combineTotalProfit, setCombineTotalProfit] = useState('0.00');
  const [combineInviteCode, setCombineInviteCode] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Copy to clipboard
  const handleCopy = (text: string) => {
    navigator.clipboard?.writeText(text);
    showToast('Copied address to clipboard');
  };

  // Approve / Reject withdrawal
  const handleWithdrawAction = (id: number, status: 'Approved' | 'Rejected') => {
    setWithdrawals((prev) => {
      const updated = prev.map((w) => (w.id === id ? { ...w, status } : w));
      try {
        localStorage.setItem('bam_admin_withdrawals', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    showToast(`Withdrawal #${id} marked as ${status}`);
  };

  // Delete withdrawal record
  const handleDeleteWithdrawal = (id: number) => {
    setWithdrawals((prev) => {
      const updated = prev.filter((w) => w.id !== id);
      try {
        localStorage.setItem('bam_admin_withdrawals', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    showToast(`Withdrawal record #${id} deleted`);
  };

  // Approve / Reject deposit
  const handleDepositAction = (id: number, status: 'Approved' | 'Rejected') => {
    setDeposits((prev) => {
      const updated = prev.map((d) => (d.id === id ? { ...d, status } : d));
      try {
        localStorage.setItem('bam_admin_deposits', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    showToast(`Deposit #${id} marked as ${status}`);
  };

  // Delete deposit record
  const handleDeleteDeposit = (id: number) => {
    setDeposits((prev) => {
      const updated = prev.filter((d) => d.id !== id);
      try {
        localStorage.setItem('bam_admin_deposits', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    showToast(`Deposit record #${id} deleted`);
  };

  // Delete recovery request
  const handleDeleteRecoveryRequest = (id: number) => {
    setRecoveryRequests((prev) => {
      const updated = prev.filter((r) => r.id !== id);
      try {
        localStorage.setItem('bam_admin_recovery', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    showToast(`Recovery request #${id} deleted`);
  };

  // Handle Update Balance Form Submit (Screenshot 4)
  const handleUpdateBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(balanceAmount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount greater than 0');
      return;
    }

    if (balanceInviteCode.trim() === user.referralCode || balanceInviteCode.trim().toLowerCase() === user.username.toLowerCase()) {
      const newBal =
        balanceActionType === 'add'
          ? Number((user.balance + amt).toFixed(2))
          : Math.max(0, Number((user.balance - amt).toFixed(2)));
      onUpdateUser({ balance: newBal });
      showToast(
        `Successfully ${balanceActionType === 'add' ? 'added' : 'subtracted'} $${amt.toFixed(2)} to ${user.username}'s balance! New balance: $${newBal.toFixed(2)}`
      );
    } else {
      showToast(
        `Balance updated for user code ${balanceInviteCode || '845868'}: ${balanceActionType === 'add' ? '+' : '-'}$${amt.toFixed(2)}`
      );
    }
  };

  // Handle User Search (Screenshot 5)
  const handleSearchUser = () => {
    setHasSearched(true);
    const code = searchUserCode.trim();
    if (code === user.referralCode || code.toLowerCase() === user.username.toLowerCase()) {
      setFoundUser(user);
    } else if (code === '845868' || code.toLowerCase() === 'mia') {
      setFoundUser({
        username: 'mia',
        referralCode: '845868',
        balance: 67.0,
        creditReputation: 100,
        todayProfit: 5.4,
        totalProfit: 5.4,
        completedOrders: 25,
        totalOrders: 25,
        currentVipLevel: 1,
        withdrawalAddress: 'TFZPSMrqG6CFHyZqaE6EPne94Hs...',
        phoneOrEmail: 'mia@gmail.com',
        avatarInitials: 'MI',
      });
    } else if (code === '751187' || code.toLowerCase() === 'user_751187') {
      setFoundUser({
        username: 'user_751187',
        referralCode: '751187',
        balance: 261.0,
        creditReputation: 98,
        todayProfit: 18.9,
        totalProfit: 412.0,
        completedOrders: 25,
        totalOrders: 25,
        currentVipLevel: 2,
        withdrawalAddress: 'TFZPSMrqG6CFHyZqaE6EPne94Hs...',
        phoneOrEmail: 'user751187@gmail.com',
        avatarInitials: 'U7',
      });
    } else {
      setFoundUser(null);
    }
  };

  // Handle Single Order Upload Submit (Screenshot 7)
  const handleSingleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!singleTitle.trim()) {
      alert('Please enter an order title');
      return;
    }
    const amt = parseFloat(singleAmount) || 100;
    const comm = parseFloat(singleCommission) || (amt * 0.04);

    onAddProduct({
      title: singleTitle,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
      thumbnails: [],
      platform: singlePlatform.toUpperCase().includes('SHOPIFY') || singlePlatform.toUpperCase().includes('ALIBABA')
        ? 'SHOPIFY'
        : singlePlatform.toUpperCase().includes('WALMART') || singlePlatform.toUpperCase().includes('ALIEXPRESS')
        ? 'WALMART'
        : 'AMAZON',
      orderAmount: amt,
      commissionRate: 0.04,
      commission: comm,
    });

    showToast('Single order uploaded and dispatched to user tasks!');
    setSingleTitle('');
    setSingleAmount('0.00');
    setSingleCommission('0.00');
    setSingleTotalProfit('0.00');
  };

  // Handle Combine Order Upload Submit (Screenshot 8)
  const handleCombineOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!combineTitle.trim()) {
      alert('Please enter order title');
      return;
    }
    const amt = parseFloat(combineAmount) || 250;
    const comm = parseFloat(combineCommission) || (amt * 0.08);

    onAddProduct({
      title: combineTitle,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80',
      thumbnails: [
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=200&auto=format&fit=crop&q=80',
      ],
      platform: combinePlatform.toUpperCase().includes('SHOPIFY') || combinePlatform.toUpperCase().includes('ALIBABA')
        ? 'SHOPIFY'
        : combinePlatform.toUpperCase().includes('WALMART') || combinePlatform.toUpperCase().includes('ALIEXPRESS')
        ? 'WALMART'
        : 'AMAZON',
      orderAmount: amt,
      commissionRate: 0.08,
      commission: comm,
    });

    showToast('Combine orders bundle created successfully!');
    setCombineTitle('');
    setCombineAmount('0.00');
    setCombineCommission('0.00');
    setCombineTotalProfit('0.00');
  };

  // Send message in Chat Support (Screenshot 10)
  const handleSendReply = () => {
    if (!chatReplyText.trim() || !selectedConversationId) return;

    setConversations((prev) => {
      const updated = prev.map((c) => {
        if (c.id === selectedConversationId) {
          const newMsg = {
            id: `msg-${Date.now()}`,
            sender: 'admin' as const,
            text: chatReplyText.trim(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };
          const updatedMessages = [...c.messages, newMsg];

          // Sync to localStorage for user live chat
          try {
            localStorage.setItem(`bam_chat_${c.userCode}`, JSON.stringify(updatedMessages));
          } catch (e) {
            console.warn('Sync to user chat failed:', e);
          }

          return {
            ...c,
            lastMessage: newMsg.text,
            time: newMsg.time,
            unreadCount: 0,
            messages: updatedMessages,
          };
        }
        return c;
      });

      try {
        localStorage.setItem('bam_admin_conversations', JSON.stringify(updated));
        window.dispatchEvent(new Event('bam_chat_update'));
      } catch (e) {
        console.warn('Sync admin conversations failed:', e);
      }

      showToast('Reply dispatched to customer live chat!');
      return updated;
    });

    setChatReplyText('');
  };

  const handleDeleteConversation = (convId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setConversations((prev) => {
      const updated = prev.filter((c) => c.id !== convId);
      try {
        localStorage.setItem('bam_admin_conversations', JSON.stringify(updated));
        window.dispatchEvent(new Event('bam_chat_update'));
      } catch (err) {
        console.warn('Sync delete conversation failed:', err);
      }
      return updated;
    });
    if (selectedConversationId === convId) {
      setSelectedConversationId(null);
    }
    showToast('Conversation removed from list');
  };

  const selectedConv = conversations.find((c) => c.id === selectedConversationId);

  // Stats calculation
  const totalPendingWithdrawals = withdrawals.filter((w) => w.status === 'Pending').length;
  const totalPendingDeposits = deposits.filter((d) => d.status === 'Pending').length;

  return (
    <div className="flex min-h-screen bg-[#f4f6fb] text-slate-800 -mx-3 sm:-mx-4 -my-3">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. SIDEBAR (Royal Blue #1877f2 matching screenshots) */}
      <aside className="w-64 bg-[#1877f2] text-white flex-shrink-0 flex flex-col min-h-screen">
        {/* Brand Header */}
        <div className="p-5 border-b border-blue-400/30">
          <h1 className="text-xl font-black tracking-tight text-white">Admin Panel</h1>
          <p className="text-xs text-blue-100 font-medium">Management Dashboard</p>
        </div>

        {/* Sidebar Nav Items */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          <button
            onClick={() => setActiveMenu('dashboard')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'dashboard'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveMenu('withdrawals')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left relative ${
              activeMenu === 'withdrawals'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Withdrawal Requests</span>
            {totalPendingWithdrawals > 0 && (
              <span className="ml-auto bg-amber-400 text-slate-900 text-[10px] font-black px-1.5 py-0.5 rounded-full">
                {totalPendingWithdrawals}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveMenu('deposits')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left relative ${
              activeMenu === 'deposits'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Deposit Requests</span>
            {totalPendingDeposits > 0 && (
              <span className="ml-auto bg-amber-400 text-slate-900 text-[10px] font-black px-1.5 py-0.5 rounded-full">
                {totalPendingDeposits}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveMenu('update-balance')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'update-balance'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Update Balance</span>
          </button>

          <button
            onClick={() => setActiveMenu('user-finder')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'user-finder'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>User Finder</span>
          </button>

          <button
            onClick={() => setActiveMenu('csv-upload')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'csv-upload'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>CSV Order Upload</span>
          </button>

          <button
            onClick={() => setActiveMenu('single-order')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'single-order'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Single Order Upload</span>
          </button>

          <button
            onClick={() => setActiveMenu('combine-orders')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'combine-orders'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Combine Orders Upload</span>
          </button>

          <button
            onClick={() => setActiveMenu('credentials')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'credentials'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Key className="w-4 h-4" />
            <span>User Credentials</span>
          </button>

          <button
            onClick={() => setActiveMenu('support-teams')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'support-teams'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Headphones className="w-4 h-4" />
            <span>Support Teams</span>
          </button>

          <button
            onClick={() => setActiveMenu('chat-support')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
              activeMenu === 'chat-support'
                ? 'bg-white/20 text-white shadow-xs font-extrabold'
                : 'text-blue-100 hover:bg-white/10 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Chat Support</span>
          </button>
        </nav>
      </aside>

      {/* 2. MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-3.5 flex items-center justify-between shadow-xs">
          <h2 className="text-xl font-bold text-[#1877f2] capitalize">
            {activeMenu.replace('-', ' ')}
          </h2>

          <div className="flex items-center gap-4">
            {/* Languages Dropdown Pill */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-full text-xs font-semibold text-gray-700">
              <Globe className="w-3.5 h-3.5 text-gray-500" />
              <span>Languages</span>
            </div>

            {/* Admin Avatar Pill */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#5c45b8] text-white flex items-center justify-center font-bold text-xs">
                A
              </div>
              <div className="hidden sm:block text-left">
                <span className="block text-xs font-bold text-gray-900 leading-tight">Admin</span>
                <span className="block text-[10px] text-gray-400 leading-tight">Administrator</span>
              </div>
            </div>

            {/* Visit Site Button */}
            <button
              onClick={onVisitSite}
              className="px-3.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-[#1877f2] border border-blue-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Visit Site</span>
            </button>

            {/* Red Logout Button */}
            <button
              onClick={onVisitSite}
              className="px-4 py-1.5 bg-[#e02424] hover:bg-[#c81e1e] text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </header>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {/* ==================================================== */}
          {/* VIEW 1: DASHBOARD (Screenshot 1) */}
          {/* ==================================================== */}
          {activeMenu === 'dashboard' && (
            <div className="space-y-6">
              {/* Dashboard Controls Header */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-lg font-black text-gray-900">Dashboard</h3>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setWithdrawals([]);
                      setDeposits([]);
                      try {
                        localStorage.setItem('bam_admin_withdrawals', JSON.stringify([]));
                        localStorage.setItem('bam_admin_deposits', JSON.stringify([]));
                      } catch (e) {}
                      showToast('All transaction records cleared.');
                    }}
                    className="px-3 py-1.5 bg-[#e02424] hover:bg-[#c81e1e] text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete All</span>
                  </button>
                  <button
                    onClick={() => showToast('Toggled hidden system records.')}
                    className="px-3 py-1.5 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Hidden Items</span>
                  </button>
                  <button
                    onClick={() => {
                      const cleanW = INITIAL_ADMIN_WITHDRAWALS.filter(
                        (w) =>
                          w.username?.toLowerCase() !== 'kali' &&
                          w.username?.toLowerCase() !== 'rani' &&
                          w.userCode !== '992812' &&
                          w.userCode !== '441029'
                      );
                      const cleanD = INITIAL_ADMIN_DEPOSITS.filter(
                        (d) =>
                          d.username?.toLowerCase() !== 'kali' &&
                          d.username?.toLowerCase() !== 'rani' &&
                          d.userCode !== '992812' &&
                          d.userCode !== '441029'
                      );
                      setWithdrawals(cleanW);
                      setDeposits(cleanD);
                      try {
                        localStorage.setItem('bam_admin_withdrawals', JSON.stringify(cleanW));
                        localStorage.setItem('bam_admin_deposits', JSON.stringify(cleanD));
                      } catch (e) {}
                      showToast('Platform metrics synced and refreshed.');
                    }}
                    className="px-4 py-1.5 bg-[#1877f2] hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Update
                  </button>
                  <button
                    onClick={onVisitSite}
                    className="px-3 py-1.5 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Visit Site</span>
                  </button>
                </div>
              </div>

              {/* 4 Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Total Users */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#1877f2] flex items-center justify-center">
                      <Users className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 font-semibold block">Total Users</span>
                      <span className="text-xl font-black text-gray-900 block mt-0.5">0</span>
                    </div>
                  </div>
                  <MoreVertical className="w-4 h-4 text-gray-400 cursor-pointer" />
                </div>

                {/* Total Balance */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <DollarSign className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 font-semibold block">Total Balance</span>
                      <span className="text-xl font-black text-gray-900 block mt-0.5">$0.00</span>
                    </div>
                  </div>
                  <MoreVertical className="w-4 h-4 text-gray-400 cursor-pointer" />
                </div>

                {/* Pending Withdraws */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                      <Package className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 font-semibold block">Pending Withdraws</span>
                      <span className="text-xl font-black text-gray-900 block mt-0.5">{totalPendingWithdrawals}</span>
                    </div>
                  </div>
                  <MoreVertical className="w-4 h-4 text-gray-400 cursor-pointer" />
                </div>

                {/* Pending Deposits */}
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-pink-50 text-pink-600 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 font-semibold block">Pending Deposits</span>
                      <span className="text-xl font-black text-gray-900 block mt-0.5">{totalPendingDeposits}</span>
                    </div>
                  </div>
                  <MoreVertical className="w-4 h-4 text-gray-400 cursor-pointer" />
                </div>
              </div>

              {/* Quick Actions Row */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-gray-900">Quick Actions</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div
                    onClick={() => setActiveMenu('withdrawals')}
                    className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs flex items-center justify-between cursor-pointer hover:border-amber-300 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                        <Package className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-gray-900 block">Withdrawal Requests</span>
                        <span className="text-[11px] text-gray-400">Withdraw Requests</span>
                      </div>
                    </div>
                    <MoreVertical className="w-4 h-4 text-gray-400" />
                  </div>

                  <div
                    onClick={() => setActiveMenu('deposits')}
                    className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs flex items-center justify-between cursor-pointer hover:border-pink-300 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-gray-900 block">Deposit Requests</span>
                        <span className="text-[11px] text-gray-400">Deposit Requests</span>
                      </div>
                    </div>
                    <MoreVertical className="w-4 h-4 text-gray-400" />
                  </div>

                  <div
                    onClick={() => setActiveMenu('update-balance')}
                    className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs flex items-center justify-between cursor-pointer hover:border-emerald-300 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <DollarSign className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-gray-900 block">Update Balance</span>
                        <span className="text-[11px] text-gray-400">Update Balance</span>
                      </div>
                    </div>
                    <MoreVertical className="w-4 h-4 text-gray-400" />
                  </div>
                </div>
              </div>

              {/* Withdraw Requests Preview Table Header */}
              <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-gray-900">Withdraw Requests</h4>
                  <span className="bg-blue-50 text-[#1877f2] text-xs font-bold px-3 py-1 rounded-full">
                    {totalPendingWithdrawals} pending
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-[#1877f2] text-white">
                        <th className="py-2.5 px-3 font-bold">#</th>
                        <th className="py-2.5 px-3 font-bold">Username</th>
                        <th className="py-2.5 px-3 font-bold">Tasks</th>
                        <th className="py-2.5 px-3 font-bold">Amount</th>
                        <th className="py-2.5 px-3 font-bold">Status</th>
                        <th className="py-2.5 px-3 font-bold">Date</th>
                        <th className="py-2.5 px-3 font-bold text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {withdrawals.slice(0, 5).map((w) => (
                        <tr key={w.id} className="hover:bg-gray-50">
                          <td className="py-2.5 px-3 font-mono font-bold text-gray-500">{w.id}</td>
                          <td className="py-2.5 px-3 font-semibold text-gray-900">{w.username}</td>
                          <td className="py-2.5 px-3 text-gray-600">{w.tasks}</td>
                          <td className="py-2.5 px-3 font-bold text-gray-900">${w.amount.toFixed(2)}</td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                w.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : w.status === 'Pending'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-rose-100 text-rose-700'
                              }`}
                            >
                              {w.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-gray-400 text-[11px]">{w.date}</td>
                          <td className="py-2.5 px-3 text-center">
                            <button
                              title="Delete record"
                              onClick={() => handleDeleteWithdrawal(w.id)}
                              className="p-1 rounded-md text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 2: WITHDRAWAL REQUESTS (Screenshot 2) */}
          {/* ==================================================== */}
          {activeMenu === 'withdrawals' && (
            <div className="space-y-6">
              {/* 4 Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#1877f2] flex items-center justify-center">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      TOTAL REQUESTS
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">{withdrawals.length}</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      PENDING
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">{totalPendingWithdrawals}</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Check className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      APPROVED
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">
                      {withdrawals.filter((w) => w.status === 'Approved').length}
                    </span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
                    <X className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      REJECTED
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">
                      {withdrawals.filter((w) => w.status === 'Rejected').length}
                    </span>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-gray-900">Withdrawal Requests</h3>
                    <span className="text-xs text-gray-400 font-semibold">{totalPendingWithdrawals} pending</span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-[#1877f2] text-white">
                        <th className="py-3 px-3 font-bold">#</th>
                        <th className="py-3 px-3 font-bold">Username</th>
                        <th className="py-3 px-3 font-bold">VIP Plan</th>
                        <th className="py-3 px-3 font-bold">Tasks</th>
                        <th className="py-3 px-3 font-bold">Amount</th>
                        <th className="py-3 px-3 font-bold">Wallet Address</th>
                        <th className="py-3 px-3 font-bold">Status</th>
                        <th className="py-3 px-3 font-bold">Date</th>
                        <th className="py-3 px-3 font-bold text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {withdrawals.map((w) => (
                        <tr key={w.id} className="hover:bg-gray-50/70">
                          <td className="py-3 px-3 font-mono font-bold text-gray-500">{w.id}</td>
                          <td className="py-3 px-3 font-bold text-gray-800">{w.username}</td>
                          <td className="py-3 px-3 text-gray-400">{w.vipPlan || '—'}</td>
                          <td className="py-3 px-3 font-medium text-gray-700">{w.tasks}</td>
                          <td className="py-3 px-3 font-bold text-gray-900">${w.amount.toFixed(2)}</td>
                          <td className="py-3 px-3">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono text-blue-600 truncate max-w-[150px]">{w.walletAddress}</span>
                              <button
                                onClick={() => handleCopy(w.walletAddress)}
                                className="text-gray-400 hover:text-gray-700"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                                w.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : w.status === 'Pending'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-rose-100 text-rose-700'
                              }`}
                            >
                              {w.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-gray-500 text-[11px] whitespace-nowrap">{w.date}</td>
                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {w.status === 'Pending' && (
                                <>
                                  <button
                                    onClick={() => handleWithdrawAction(w.id, 'Approved')}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleWithdrawAction(w.id, 'Rejected')}
                                    className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                              <button
                                title="Delete record"
                                onClick={() => handleDeleteWithdrawal(w.id)}
                                className="p-1 rounded-md text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 3: DEPOSIT REQUESTS (Screenshot 3) */}
          {/* ==================================================== */}
          {activeMenu === 'deposits' && (
            <div className="space-y-6">
              {/* 4 Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#1877f2] flex items-center justify-center">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      TOTAL REQUESTS
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">{deposits.length}</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      PENDING
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">{totalPendingDeposits}</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <Check className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      APPROVED
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">
                      {deposits.filter((d) => d.status === 'Approved').length}
                    </span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
                    <X className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">
                      REJECTED
                    </span>
                    <span className="text-2xl font-black text-gray-900 block mt-0.5">
                      {deposits.filter((d) => d.status === 'Rejected').length}
                    </span>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-gray-900">Deposit Requests</h3>
                    <span className="text-xs text-gray-400 font-semibold">{totalPendingDeposits} pending</span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-[#1877f2] text-white">
                        <th className="py-3 px-3 font-bold">#</th>
                        <th className="py-3 px-3 font-bold">Username</th>
                        <th className="py-3 px-3 font-bold">Amount</th>
                        <th className="py-3 px-3 font-bold">Status</th>
                        <th className="py-3 px-3 font-bold">Date</th>
                        <th className="py-3 px-3 font-bold text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {deposits.map((d) => (
                        <tr key={d.id} className="hover:bg-gray-50/70">
                          <td className="py-3 px-3 font-mono font-bold text-gray-500">{d.id}</td>
                          <td className="py-3 px-3 font-bold text-gray-800">{d.username}</td>
                          <td className="py-3 px-3 font-bold text-gray-900">${d.amount.toFixed(2)}</td>
                          <td className="py-3 px-3">
                            <span
                              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                                d.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : d.status === 'Pending'
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-rose-100 text-rose-700'
                              }`}
                            >
                              {d.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-gray-500 text-[11px] whitespace-nowrap">{d.date}</td>
                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {d.status === 'Pending' && (
                                <>
                                  <button
                                    onClick={() => handleDepositAction(d.id, 'Approved')}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleDepositAction(d.id, 'Rejected')}
                                    className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                              <button
                                title="Delete record"
                                onClick={() => handleDeleteDeposit(d.id)}
                                className="p-1 rounded-md text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 4: UPDATE BALANCE (Screenshot 4) */}
          {/* ==================================================== */}
          {activeMenu === 'update-balance' && (
            <div className="max-w-2xl mx-auto">
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm text-center">
                {/* Top Purple Icon */}
                <div className="w-16 h-16 rounded-full bg-[#5c45b8] text-white flex items-center justify-center mx-auto mb-4 shadow-md">
                  <span className="text-3xl font-light leading-none">+</span>
                </div>

                <h3 className="text-xl font-black text-gray-900">Update User Balance</h3>
                <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
                  Add or subtract balance from user accounts using their invite code
                </p>

                <form onSubmit={handleUpdateBalanceSubmit} className="mt-8 text-left space-y-5">
                  {/* User Invite Code */}
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">
                      User Invite Code
                    </label>
                    <input
                      type="text"
                      placeholder="Enter user invite code (e.g. 845868 for mia)"
                      value={balanceInviteCode}
                      onChange={(e) => setBalanceInviteCode(e.target.value)}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:border-[#1877f2]"
                    />
                    <span className="text-[10px] text-gray-400 block mt-1">
                      Enter the exact invite code of the user
                    </span>
                  </div>

                  {/* Amount */}
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">Amount</label>
                    <input
                      type="number"
                      step="0.01"
                      value={balanceAmount}
                      onChange={(e) => setBalanceAmount(e.target.value)}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#1877f2]"
                    />
                    <span className="text-[10px] text-gray-400 block mt-1">
                      Enter the amount to add or subtract (e.g., 30.50)
                    </span>
                  </div>

                  {/* Action Type */}
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1.5">Action Type</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setBalanceActionType('add')}
                        className={`py-3 rounded-xl text-xs font-bold transition-all ${
                          balanceActionType === 'add'
                            ? 'bg-[#16a34a] text-white shadow-xs'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        + Add Balance
                      </button>
                      <button
                        type="button"
                        onClick={() => setBalanceActionType('subtract')}
                        className={`py-3 rounded-xl text-xs font-bold transition-all ${
                          balanceActionType === 'subtract'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                        }`}
                      >
                        — Subtract Balance
                      </button>
                    </div>
                  </div>

                  {/* Summary Box */}
                  <div className="bg-[#f8faff] rounded-2xl p-4 border border-blue-100 space-y-2">
                    <div className="text-center font-bold text-xs text-gray-700 flex items-center justify-center gap-1.5">
                      <span>📋</span>
                      <span>Summary</span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>User Invite Code:</span>
                      <span className="font-mono font-bold text-gray-900">{balanceInviteCode || '—'}</span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>Action:</span>
                      <span
                        className={`font-bold ${
                          balanceActionType === 'add' ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {balanceActionType === 'add' ? 'Add Balance' : 'Subtract Balance'}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>Amount:</span>
                      <span className="font-bold text-gray-900">
                        ${(parseFloat(balanceAmount) || 0).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Update Balance Action Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-[#1877f2] hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
                  >
                    Update Balance — {balanceActionType === 'add' ? 'Add' : 'Subtract'} $
                    {(parseFloat(balanceAmount) || 0).toFixed(2)}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 5: USER FINDER (Screenshot 5) */}
          {/* ==================================================== */}
          {activeMenu === 'user-finder' && (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm text-center">
                {/* Purple Search Icon */}
                <div className="w-16 h-16 rounded-full bg-[#5c45b8] text-white flex items-center justify-center mx-auto mb-4 shadow-md">
                  <Search className="w-7 h-7" />
                </div>

                <h3 className="text-xl font-black text-gray-900">User Finder</h3>
                <p className="text-xs text-gray-400 mt-1">
                  Search users by their unique 6-digit User Code
                </p>

                <div className="mt-6 flex items-center gap-3">
                  <input
                    type="text"
                    placeholder="Enter 6-digit User Code (e.g. 845868, 751187, 189402)"
                    value={searchUserCode}
                    onChange={(e) => setSearchUserCode(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearchUser()}
                    className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:border-[#5c45b8]"
                  />
                  <button
                    onClick={handleSearchUser}
                    className="px-6 py-3 bg-[#5c45b8] hover:bg-[#4b379c] text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-2"
                  >
                    <Search className="w-4 h-4" />
                    <span>Search</span>
                  </button>
                </div>
              </div>

              {/* Search Result Card */}
              {hasSearched && foundUser && (
                <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-black text-base">
                        {foundUser.avatarInitials}
                      </div>
                      <div>
                        <h4 className="text-base font-bold text-gray-900">{foundUser.username}</h4>
                        <span className="text-xs text-gray-400">{foundUser.phoneOrEmail}</span>
                      </div>
                    </div>
                    <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full border border-emerald-200">
                      Active Member
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="bg-gray-50 p-3 rounded-xl">
                      <span className="text-gray-400 block text-[10px] uppercase font-bold">User Code</span>
                      <span className="font-mono font-bold text-gray-900 block mt-0.5">{foundUser.referralCode}</span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-xl">
                      <span className="text-gray-400 block text-[10px] uppercase font-bold">Balance</span>
                      <span className="font-bold text-[#1877f2] text-sm block mt-0.5">${foundUser.balance.toFixed(2)}</span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-xl">
                      <span className="text-gray-400 block text-[10px] uppercase font-bold">VIP Tier</span>
                      <span className="font-bold text-gray-900 block mt-0.5">VIP {foundUser.currentVipLevel}</span>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-xl">
                      <span className="text-gray-400 block text-[10px] uppercase font-bold">Tasks</span>
                      <span className="font-bold text-gray-900 block mt-0.5">
                        {foundUser.completedOrders}/{foundUser.totalOrders}
                      </span>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-3 rounded-xl text-xs space-y-1">
                    <span className="text-gray-400 block text-[10px] uppercase font-bold">Wallet Address</span>
                    <span className="font-mono text-gray-800 break-all">{foundUser.withdrawalAddress}</span>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => {
                        setBalanceInviteCode(foundUser.referralCode);
                        setActiveMenu('update-balance');
                      }}
                      className="px-4 py-2 bg-[#1877f2] text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors"
                    >
                      Update Balance for {foundUser.username}
                    </button>
                  </div>
                </div>
              )}

              {hasSearched && !foundUser && (
                <div className="bg-white rounded-2xl p-8 border border-gray-100 text-center text-gray-400 text-xs">
                  No user record found for code <span className="font-mono font-bold text-gray-700">{searchUserCode}</span>.
                </div>
              )}
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 6: CSV ORDER UPLOAD (Screenshot 6) */}
          {/* ==================================================== */}
          {activeMenu === 'csv-upload' && (
            <div className="max-w-2xl mx-auto">
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm text-center">
                {/* Green Document Icon */}
                <div className="w-16 h-16 rounded-full bg-[#10b981] text-white flex items-center justify-center mx-auto mb-4 shadow-md">
                  <FileText className="w-7 h-7" />
                </div>

                <h3 className="text-xl font-black text-gray-900">CSV Order Upload</h3>
                <p className="text-xs text-gray-400 mt-1">
                  Upload multiple orders via CSV file for bulk processing
                </p>

                <div className="mt-8 text-left space-y-5">
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">
                      User Invitation Code
                    </label>
                    <input
                      type="text"
                      placeholder="Enter user invitation code"
                      value={csvInviteCode}
                      onChange={(e) => setCsvInviteCode(e.target.value)}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#10b981]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">CSV File</label>
                    <label className="border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 bg-gray-50/50 transition-colors">
                      <UploadCloud className="w-10 h-10 text-emerald-500 mb-2" />
                      <span className="text-xs font-bold text-gray-800">
                        {csvUploadedFileName || 'Click to upload or drag and drop'}
                      </span>
                      <span className="text-[10px] text-gray-400 mt-0.5">CSV file only (MAX. 10MB)</span>
                      <input
                        type="file"
                        accept=".csv"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          setCsvUploadedFileName(file.name);
                          const reader = new FileReader();
                          reader.onload = (evt) => {
                            const text = evt.target?.result as string;
                            if (!text) return;
                            
                            const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
                            if (lines.length < 2) {
                              showToast('CSV file is empty or missing data rows');
                              return;
                            }

                            const parseLine = (line: string): string[] => {
                              const result: string[] = [];
                              let cur = '';
                              let inQuotes = false;
                              for (let i = 0; i < line.length; i++) {
                                const char = line[i];
                                if (char === '"' || char === "'") {
                                  inQuotes = !inQuotes;
                                } else if (char === ',' && !inQuotes) {
                                  result.push(cur.trim().replace(/^["']|["']$/g, ''));
                                  cur = '';
                                } else {
                                  cur += char;
                                }
                              }
                              result.push(cur.trim().replace(/^["']|["']$/g, ''));
                              return result;
                            };

                            const header = parseLine(lines[0]).map((h) => h.toLowerCase().trim());
                            const titleIdx = header.findIndex((h) => h.includes('title'));
                            const amountIdx = header.findIndex((h) => h.includes('amount'));
                            const commissionIdx = header.findIndex((h) => h.includes('commission'));
                            const totalProfitIdx = header.findIndex((h) => h.includes('total') || h.includes('profit'));
                            const imageIdx = header.findIndex((h) => h.includes('image') || h.includes('imange'));
                            const positionIdx = header.findIndex((h) => h.includes('position') || h.includes('pos'));

                            const parsedList: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[] = [];

                            for (let i = 1; i < lines.length; i++) {
                              const cols = parseLine(lines[i]);
                              if (cols.length < 3) continue;

                              const title = titleIdx !== -1 && cols[titleIdx] ? cols[titleIdx] : `Product ${i}`;
                              const rawAmount = amountIdx !== -1 && cols[amountIdx] ? cols[amountIdx].replace(/[^0-9.]/g, '') : '20';
                              const rawCommission = commissionIdx !== -1 && cols[commissionIdx] ? cols[commissionIdx].replace(/[^0-9.]/g, '') : '0.80';
                              const rawTotalProfit = totalProfitIdx !== -1 && cols[totalProfitIdx] ? cols[totalProfitIdx].replace(/[^0-9.]/g, '') : '40';
                              let rawImage = imageIdx !== -1 && cols[imageIdx] ? cols[imageIdx] : 'https://m.media-amazon.com/images/I/618e8aob+ZL._AC_SY679_.jpg';

                              if (rawImage.includes('https://') && rawImage.indexOf('https://') !== rawImage.lastIndexOf('https://')) {
                                rawImage = rawImage.substring(rawImage.lastIndexOf('https://'));
                              }

                              const position = positionIdx !== -1 && cols[positionIdx] ? parseInt(cols[positionIdx], 10) : i;
                              const amount = parseFloat(rawAmount) || 20.0;
                              const commission = parseFloat(rawCommission) || 0.8;
                              const totalProfit = parseFloat(rawTotalProfit) || (amount + commission);

                              parsedList.push({
                                title,
                                image: rawImage,
                                thumbnails: [rawImage],
                                platform: 'AMAZON',
                                orderAmount: amount,
                                commissionRate: 0.04,
                                commission,
                                totalProfit,
                                position,
                                type: 'single',
                              });
                            }

                            if (parsedList.length > 0) {
                              setCsvParsedProducts(parsedList);
                              showToast(`Loaded ${parsedList.length} products from CSV! Click "Upload CSV Orders Now" to apply.`);
                            } else {
                              showToast('No valid product rows parsed from CSV.');
                            }
                          };
                          reader.readAsText(file);
                        }}
                      />
                    </label>
                  </div>

                  {/* CSV Preview when loaded */}
                  {csvParsedProducts.length > 0 && (
                    <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-900">
                          {csvParsedProducts.length} Products Ready to Deploy:
                        </span>
                        <span className="text-[11px] text-emerald-700 font-semibold">
                          Total Value: ${csvParsedProducts.reduce((acc, p) => acc + p.orderAmount, 0).toFixed(2)}
                        </span>
                      </div>
                      <div className="max-h-40 overflow-y-auto space-y-1.5 divide-y divide-emerald-100 pr-1">
                        {csvParsedProducts.slice(0, 5).map((p, idx) => (
                          <div key={idx} className="pt-1.5 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 truncate">
                              <span className="font-mono font-bold text-emerald-800">#{p.position || idx + 1}</span>
                              <span className="truncate text-gray-800 font-medium">{p.title}</span>
                            </div>
                            <span className="font-bold text-emerald-700 whitespace-nowrap">${p.orderAmount.toFixed(2)}</span>
                          </div>
                        ))}
                        {csvParsedProducts.length > 5 && (
                          <div className="text-[11px] text-emerald-600 font-medium text-center pt-1">
                            + {csvParsedProducts.length - 5} more products in queue
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* CSV Format Requirements Box */}
                  <div className="bg-[#f0fdf4] rounded-2xl p-4 border border-emerald-200 text-xs space-y-2">
                    <h5 className="font-bold text-emerald-800">CSV Format Requirements</h5>
                    <p className="text-[11px] text-emerald-700">
                      Required columns: <span className="font-mono font-semibold">platform, title, amount, commission, totalProfit, image</span>
                    </p>
                    <p className="text-[11px] text-emerald-700">
                      Optional columns: <span className="font-mono font-semibold">position, type (single/combine)</span>
                    </p>
                    <div className="bg-white p-3 rounded-xl border border-emerald-200 font-mono text-[10px] text-gray-700 overflow-x-auto leading-relaxed">
                      platform,title,amount,commission,total profit,imange,position<br />
                      amazon,"Bulova Men's Watch",$15.20,$0.61,$40.49,"https://m.media-amazon.com/...",1
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (csvParsedProducts.length > 0) {
                        if (onSetProductPool) {
                          onSetProductPool(csvParsedProducts);
                        } else {
                          csvParsedProducts.forEach((p) => onAddProduct(p));
                        }
                        showToast(`Successfully uploaded and applied ${csvParsedProducts.length} orders into the merchant queue!`);
                        setCsvParsedProducts([]);
                        setCsvUploadedFileName(null);
                      } else {
                        if (!csvUploadedFileName) {
                          alert('Please select a CSV file first');
                          return;
                        }
                        showToast('CSV batch orders uploaded and added to merchant queue!');
                      }
                    }}
                    className="w-full py-3.5 bg-[#10b981] hover:bg-emerald-600 text-white font-bold text-sm rounded-xl transition-colors shadow-xs cursor-pointer"
                  >
                    Upload CSV Orders Now
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 7: SINGLE ORDER UPLOAD (Screenshot 7) */}
          {/* ==================================================== */}
          {activeMenu === 'single-order' && (
            <div className="max-w-2xl mx-auto">
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm text-center">
                {/* Green Document Icon */}
                <div className="w-16 h-16 rounded-full bg-[#10b981] text-white flex items-center justify-center mx-auto mb-4 shadow-md">
                  <FileText className="w-7 h-7" />
                </div>

                <h3 className="text-xl font-black text-gray-900">Single Order Upload</h3>
                <p className="text-xs text-gray-400 mt-1">
                  Upload a single order with platform details and one image
                </p>

                <form onSubmit={handleSingleOrderSubmit} className="mt-8 text-left space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Platform</label>
                      <select
                        value={singlePlatform}
                        onChange={(e) => setSinglePlatform(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#10b981]"
                      >
                        <option value="Amazon (4%)">Amazon (4%)</option>
                        <option value="Shopify (8%)">Shopify (8%)</option>
                        <option value="Walmart (12%)">Walmart (12%)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Order Title</label>
                      <input
                        type="text"
                        placeholder="Enter order title"
                        value={singleTitle}
                        onChange={(e) => setSingleTitle(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#10b981]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Amount ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={singleAmount}
                        onChange={(e) => setSingleAmount(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#10b981]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Commission ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={singleCommission}
                        onChange={(e) => setSingleCommission(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#10b981]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Total Profit ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={singleTotalProfit}
                        onChange={(e) => setSingleTotalProfit(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#10b981]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">
                      Invitation Code
                    </label>
                    <input
                      type="text"
                      placeholder="Enter user invitation code (optional)"
                      value={singleInviteCode}
                      onChange={(e) => setSingleInviteCode(e.target.value)}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#10b981]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">Order Image</label>
                    <div className="border-2 border-dashed border-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 bg-gray-50/50 transition-colors">
                      <UploadCloud className="w-8 h-8 text-emerald-500 mb-1.5" />
                      <span className="text-xs font-bold text-gray-800">Click to upload or drag and drop</span>
                      <span className="text-[10px] text-gray-400 mt-0.5">PNG, JPG, JPEG (MAX. 5MB)</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-[#10b981] hover:bg-emerald-600 text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
                  >
                    Upload Now
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 8: COMBINE ORDERS UPLOAD (Screenshot 8) */}
          {/* ==================================================== */}
          {activeMenu === 'combine-orders' && (
            <div className="max-w-2xl mx-auto">
              <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm text-center">
                {/* Magenta App Grid Icon */}
                <div className="w-16 h-16 rounded-full bg-[#c026d3] text-white flex items-center justify-center mx-auto mb-4 shadow-md">
                  <Layers className="w-7 h-7" />
                </div>

                <h3 className="text-xl font-black text-gray-900">Combine Orders Upload</h3>
                <p className="text-xs text-gray-400 mt-1">
                  Upload multiple orders together with platform details and up to 5 images
                </p>

                <form onSubmit={handleCombineOrderSubmit} className="mt-8 text-left space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Platform</label>
                      <select
                        value={combinePlatform}
                        onChange={(e) => setCombinePlatform(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#c026d3]"
                      >
                        <option value="Amazon (4%)">Amazon (4%)</option>
                        <option value="Shopify (8%)">Shopify (8%)</option>
                        <option value="Walmart (12%)">Walmart (12%)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Order Title</label>
                      <input
                        type="text"
                        placeholder="Enter order title"
                        value={combineTitle}
                        onChange={(e) => setCombineTitle(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#c026d3]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Amount ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={combineAmount}
                        onChange={(e) => setCombineAmount(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#c026d3]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Commission ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={combineCommission}
                        onChange={(e) => setCombineCommission(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#c026d3]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">Total Profit ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={combineTotalProfit}
                        onChange={(e) => setCombineTotalProfit(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-900 focus:outline-none focus:border-[#c026d3]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">
                      Invitation Code
                    </label>
                    <input
                      type="text"
                      placeholder="Enter user invitation code"
                      value={combineInviteCode}
                      onChange={(e) => setCombineInviteCode(e.target.value)}
                      className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#c026d3]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">Order Images (Up to 5)</label>
                    <div className="border-2 border-dashed border-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer hover:border-fuchsia-500 bg-gray-50/50 transition-colors">
                      <UploadCloud className="w-8 h-8 text-fuchsia-500 mb-1.5" />
                      <span className="text-xs font-bold text-gray-800">Click to upload or drag and drop</span>
                      <span className="text-[10px] text-gray-400 mt-0.5">PNG, JPG, JPEG (MAX. 5 images, 5MB each)</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-[#c026d3] hover:bg-fuchsia-700 text-white font-bold text-sm rounded-xl transition-colors shadow-xs"
                  >
                    Upload Now
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 9: USER CREDENTIALS (Screenshot 9) */}
          {/* ==================================================== */}
          {activeMenu === 'credentials' && (
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
                {/* Header Block */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-[#1877f2] flex items-center justify-center">
                      <Key className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-gray-900">Recovery Requests</h3>
                      <p className="text-xs text-gray-500">
                        Users who submitted a "Forgot Password" request — click their code to auto-fill the reset tool below.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => showToast('Recovery list refreshed')}
                    className="px-3.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>

                {/* Table with Header */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-[#1877f2] text-white">
                        <th className="py-3 px-3 font-bold">#</th>
                        <th className="py-3 px-3 font-bold">USER CODE</th>
                        <th className="py-3 px-3 font-bold">ISSUE DESCRIPTION</th>
                        <th className="py-3 px-3 font-bold">MATCHED USERNAME</th>
                        <th className="py-3 px-3 font-bold">STATUS</th>
                        <th className="py-3 px-3 font-bold">SUBMITTED AT</th>
                        <th className="py-3 px-3 font-bold text-center">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {recoveryRequests.map((r) => (
                        <tr key={r.id} className="hover:bg-gray-50/70">
                          <td className="py-3 px-3 font-mono font-bold text-gray-500">{r.id}</td>
                          <td className="py-3 px-3">
                            <span className="bg-blue-50 text-blue-700 border border-blue-200 font-mono font-bold px-2 py-0.5 rounded-md inline-flex items-center gap-1 text-[11px]">
                              <span>🔑</span>
                              <span>{r.userCode}</span>
                            </span>
                          </td>
                          <td className="py-3 px-3 text-gray-700 font-medium max-w-[200px] truncate">
                            {r.issueDescription}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`font-semibold ${
                                r.matchedUsername !== 'Not found' ? 'text-emerald-600' : 'text-gray-400'
                              }`}
                            >
                              {r.matchedUsername}
                            </span>
                          </td>
                          <td className="py-3 px-3">
                            <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              {r.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-gray-400 text-[11px] whitespace-nowrap">
                            {r.submittedAt}
                          </td>
                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-2">
                              {r.userCode !== '—' ? (
                                <button
                                  onClick={() => {
                                    setSearchUserCode(r.userCode);
                                    setActiveMenu('user-finder');
                                    showToast(`Auto-filled code ${r.userCode} in User Finder`);
                                  }}
                                  className="text-[#1877f2] hover:text-[#166fe5] font-bold text-xs inline-flex items-center gap-1"
                                >
                                  <span>↓</span>
                                  <span>Use Code</span>
                                </button>
                              ) : (
                                <span className="text-gray-400">—</span>
                              )}
                              <button
                                title="Delete request"
                                onClick={() => handleDeleteRecoveryRequest(r.id)}
                                className="p-1 rounded-md text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 10: SUPPORT TEAMS */}
          {/* ==================================================== */}
          {activeMenu === 'support-teams' && (
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-gray-900">Support Team Management</h3>
                    <p className="text-xs text-gray-400">Assigned customer service representatives and live duty shifts</p>
                  </div>
                  <button
                    onClick={() => showToast('Team member added')}
                    className="px-3 py-1.5 bg-[#1877f2] text-white rounded-xl text-xs font-bold"
                  >
                    + Add Agent
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                        EA
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-gray-900">Emily Adams</h4>
                        <span className="text-[10px] text-emerald-600 font-bold">● Shift Active (TRC20 Dept)</span>
                      </div>
                    </div>
                    <div className="mt-3 text-xs text-gray-500 space-y-1">
                      <div>Resolved today: 42 tickets</div>
                      <div>Avg response: 1.4 mins</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-xs">
                        MC
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-gray-900">Marcus Chen</h4>
                        <span className="text-[10px] text-emerald-600 font-bold">● Shift Active (VIP Orders)</span>
                      </div>
                    </div>
                    <div className="mt-3 text-xs text-gray-500 space-y-1">
                      <div>Resolved today: 38 tickets</div>
                      <div>Avg response: 2.1 mins</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                        SO
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-gray-900">Sarah O'Connor</h4>
                        <span className="text-[10px] text-gray-400 font-bold">○ Offline (Next shift: 18:00)</span>
                      </div>
                    </div>
                    <div className="mt-3 text-xs text-gray-500 space-y-1">
                      <div>Resolved today: 19 tickets</div>
                      <div>Avg response: 1.8 mins</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================================================== */}
          {/* VIEW 11: CHAT SUPPORT (Screenshot 10) */}
          {/* ==================================================== */}
          {activeMenu === 'chat-support' && (
            <div className="space-y-4">
              {/* Top Banner: Chat Mode Control & Backend Manager */}
              <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      chatMode === 'online' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                    }`}
                  >
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-gray-900">Live Chat Support Mode</h4>
                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          chatMode === 'online'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        ● {chatMode === 'online' ? 'Online Mode' : 'Offline Mode (Manual Only)'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {chatMode === 'online'
                        ? 'Smart auto-responder is active with debounced non-repeating answers.'
                        : 'Auto-reply is completely disabled. You have full manual control to reply to customers from this desk.'}
                    </p>
                  </div>
                </div>

                {/* Mode Selector Buttons */}
                <div className="flex items-center bg-gray-100 p-1 rounded-xl border border-gray-200 shrink-0">
                  <button
                    onClick={() => handleToggleChatMode('online')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      chatMode === 'online'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                    <span>Online (Auto-Reply)</span>
                  </button>
                  <button
                    onClick={() => handleToggleChatMode('offline')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      chatMode === 'offline'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-white"></span>
                    <span>Offline (Manual Only)</span>
                  </button>
                </div>
              </div>

              {/* Main Chat Interface */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-xs flex flex-col md:flex-row h-[720px] overflow-hidden">
                {/* Left Column: Conversations */}
                <div className="w-full md:w-80 border-r border-gray-200 flex flex-col bg-white">
                  <div className="p-4 border-b border-gray-100 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-black text-gray-900">Conversations</h4>
                      <span className="text-[10px] font-bold text-gray-400">
                        {conversations.length} Active
                      </span>
                    </div>

                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search customer username..."
                        value={searchUserCode}
                        onChange={(e) => setSearchUserCode(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-700 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
                    {conversations
                      .filter(
                        (c) =>
                          c.username.toLowerCase() !== 'kali' &&
                          c.username.toLowerCase() !== 'rani' &&
                          c.userCode !== '992812' &&
                          c.userCode !== '441029' &&
                          (!searchUserCode ||
                            c.username.toLowerCase().includes(searchUserCode.toLowerCase()) ||
                            c.userCode.toLowerCase().includes(searchUserCode.toLowerCase()))
                      )
                      .map((conv) => {
                        const isSelected = selectedConversationId === conv.id;
                        const initial = conv.username.charAt(0).toUpperCase();

                        return (
                          <div
                            key={conv.id}
                            onClick={() => setSelectedConversationId(conv.id)}
                            className={`p-3.5 flex items-start gap-3 cursor-pointer transition-colors group relative ${
                              isSelected ? 'bg-blue-50/80 border-l-4 border-[#1877f2]' : 'hover:bg-gray-50'
                            }`}
                          >
                            <div className="w-10 h-10 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-bold text-xs flex-shrink-0 relative">
                              {initial}
                              {conv.unreadCount && conv.unreadCount > 0 ? (
                                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center border-2 border-white">
                                  {conv.unreadCount}
                                </span>
                              ) : null}
                            </div>

                            <div className="flex-1 min-w-0 pr-6">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-gray-900 truncate">{conv.username}</span>
                                <span className="text-[10px] text-gray-400 whitespace-nowrap">{conv.time}</span>
                              </div>
                              <p className="text-[11px] text-gray-500 truncate mt-0.5">{conv.lastMessage}</p>
                              <span className="text-[9px] text-blue-600 font-semibold mt-0.5 inline-block">
                                Code: {conv.userCode}
                              </span>
                            </div>

                            {/* Delete single conversation from list */}
                            <button
                              title="Delete conversation"
                              onClick={(e) => handleDeleteConversation(conv.id, e)}
                              className="absolute top-3.5 right-2 opacity-0 group-hover:opacity-100 p-1 rounded-md text-gray-400 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Right Column: Chat Window or Empty State */}
                <div className="flex-1 flex flex-col bg-[#fcfdff]">
                  {selectedConv ? (
                    <div className="flex-1 flex flex-col h-full">
                      {/* Active Conversation Header */}
                      <div className="p-4 border-b border-gray-200 bg-white flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-[#1877f2] text-white flex items-center justify-center font-bold text-sm">
                            {selectedConv.username.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-gray-900">{selectedConv.username}</h4>
                              <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                                Code: {selectedConv.userCode}
                              </span>
                            </div>
                            <span className="text-[10px] text-gray-400">
                              {chatMode === 'offline' ? 'Manual Response Desk' : 'Smart Live Chat'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setBalanceInviteCode(selectedConv.userCode);
                              setActiveMenu('update-balance');
                            }}
                            className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded-lg cursor-pointer transition-colors"
                          >
                            Modify Balance
                          </button>
                          <button
                            onClick={() => handleDeleteConversation(selectedConv.id)}
                            title="Delete this conversation"
                            className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-semibold rounded-lg cursor-pointer transition-colors flex items-center gap-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>

                      {/* Messages Scroll Area */}
                      <div className="flex-1 p-5 overflow-y-auto space-y-3">
                        {selectedConv.messages.map((m) => (
                          <div
                            key={m.id}
                            className={`flex flex-col ${m.sender === 'admin' ? 'items-end' : 'items-start'}`}
                          >
                            <div
                              className={`max-w-md px-4 py-2.5 rounded-2xl text-xs font-medium space-y-1.5 ${
                                m.sender === 'admin'
                                  ? 'bg-[#1877f2] text-white rounded-br-none'
                                  : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-xs'
                              }`}
                            >
                              {m.imageUrl && (
                                <div className="mb-1 rounded-lg overflow-hidden border border-gray-200/50 max-w-[200px]">
                                  <img
                                    src={m.imageUrl}
                                    alt="Customer attachment"
                                    className="w-full h-auto object-cover cursor-pointer hover:opacity-95"
                                    onClick={() => window.open(m.imageUrl, '_blank')}
                                  />
                                </div>
                              )}
                              {m.isAudio && (
                                <div className="flex items-center gap-2 py-1 text-xs font-bold text-blue-600">
                                  <span>🎵 Voice Note ({m.audioDuration || '0:03'})</span>
                                </div>
                              )}
                              <p className="leading-relaxed">{m.text}</p>
                            </div>
                            <span className="text-[10px] text-gray-400 mt-1 px-1">{m.time}</span>
                          </div>
                        ))}
                      </div>

                      {/* Quick Reply Canned Messages */}
                      <div className="px-3 py-2 bg-gray-50 border-t border-gray-100 flex items-center gap-1.5 overflow-x-auto text-[11px]">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider shrink-0 mr-1">
                          Quick Replies:
                        </span>
                        {[
                          'Your deposit of USDT has been verified and added to your balance.',
                          'Your withdrawal is audited and sent to your TRC-20 wallet.',
                          'Please provide your TRC-20 Transaction ID (TxID) or payment receipt.',
                          'Your merchant orders have been updated. Please check your tasks.',
                          'All resolved! Please refresh your dashboard to view your updated balance.',
                        ].map((quick, idx) => (
                          <button
                            key={idx}
                            onClick={() => setChatReplyText(quick)}
                            className="px-2.5 py-1 bg-white hover:bg-blue-50 hover:text-blue-600 border border-gray-200 rounded-lg text-gray-600 whitespace-nowrap cursor-pointer transition-colors"
                          >
                            {quick.slice(0, 30)}...
                          </button>
                        ))}
                      </div>

                      {/* Chat Input */}
                      <div className="p-3 bg-white border-t border-gray-200 flex items-center gap-2">
                        <input
                          type="text"
                          placeholder={
                            chatMode === 'offline'
                              ? `Reply directly to ${selectedConv.username} (Offline Mode)...`
                              : `Type manual response to ${selectedConv.username}...`
                          }
                          value={chatReplyText}
                          onChange={(e) => setChatReplyText(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSendReply()}
                          className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 focus:outline-none focus:border-[#1877f2]"
                        />
                        <button
                          onClick={handleSendReply}
                          className="px-4 py-2.5 bg-[#1877f2] hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send Reply</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Exact Empty State from Screenshot 10 */
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                      <div className="w-16 h-16 rounded-full bg-gray-100 text-gray-300 flex items-center justify-center mb-4">
                        <MessageSquare className="w-8 h-8 text-gray-300" />
                      </div>
                      <h3 className="text-base font-bold text-gray-900">Select a Conversation</h3>
                      <p className="text-xs text-gray-400 mt-1 max-w-sm">
                        Choose a user from the conversation list to view attachments and reply directly to their inquiries.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
