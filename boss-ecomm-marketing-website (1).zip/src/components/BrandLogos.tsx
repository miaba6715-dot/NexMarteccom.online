export function AmazonLogo({ className = 'h-10' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 160 55" className="h-full w-auto max-w-full">
        {/* amazon text */}
        <text
          x="75"
          y="32"
          textAnchor="middle"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="bold"
          fontSize="36"
          fill="#131921"
          letterSpacing="-0.5px"
        >
          amazon
        </text>
        {/* curved smile arrow pointing from 'a' to 'z' */}
        <path
          d="M 28 38 Q 74 53 122 38"
          fill="none"
          stroke="#ff9900"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
        <path
          d="M 120 34 L 128 37.5 L 122 43 Z"
          fill="#ff9900"
        />
      </svg>
    </div>
  );
}

export function AlibabaLogo({ className = 'h-12' }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <svg viewBox="0 0 200 80" className="h-full w-auto max-w-full">
        {/* Alibaba Group stylized smiling profile outline */}
        <g transform="translate(15, 0)">
          <path
            d="M 68 34 C 64 16 86 6 100 8 C 114 10 126 18 122 30 C 118 40 102 42 90 40 C 80 38 74 34 68 34 Z"
            fill="none"
            stroke="#ff6000"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {/* Eye */}
          <circle cx="92" cy="22" r="3" fill="#ff6000" />
          {/* Smile line */}
          <path
            d="M 88 28 Q 98 34 108 27"
            fill="none"
            stroke="#ff6000"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </g>
        {/* Alibaba Group text */}
        <text
          x="100"
          y="68"
          textAnchor="middle"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="22"
          fill="#ff6000"
        >
          Alibaba Group
        </text>
      </svg>
    </div>
  );
}

export function AliExpressLogo({ className = 'h-12' }: { className?: string }) {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className="flex items-center justify-center">
        <span className="font-extrabold text-2xl sm:text-3xl tracking-tight text-[#ff4747]">
          Ali<span className="text-[#e62e04]">Express</span>
        </span>
      </div>
      <span className="text-[10px] sm:text-[11px] text-[#4b5563] font-medium tracking-tight mt-0.5 whitespace-nowrap">
        Smarter Shopping, Better Living!
      </span>
    </div>
  );
}

export function ShopifyLogo({ className = 'h-12' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 170 50" className="h-full w-auto max-w-full">
        {/* Shopify Bag Icon */}
        <g transform="translate(10, 5)">
          {/* Handle */}
          <path
            d="M 16 13 C 16 6 24 6 24 6 C 24 6 32 6 32 13"
            fill="none"
            stroke="#5e8e3e"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          {/* Bag Body */}
          <path
            d="M 8 13 L 38 9 L 44 38 L 4 38 Z"
            fill="#95bf47"
          />
          {/* Left Bag Side fold */}
          <path
            d="M 8 13 L 21 11.5 L 18 38 L 4 38 Z"
            fill="#64943e"
          />
          {/* S glyph */}
          <path
            d="M 28 19 C 24 17 21 19 21 21.5 C 21 24.5 30 25 30 28.5 C 30 32 25 33.5 21 31"
            fill="none"
            stroke="#ffffff"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
        </g>
        {/* shopify text */}
        <text
          x="62"
          y="33"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="28"
          fill="#212326"
          letterSpacing="-0.5px"
        >
          shopify
        </text>
      </svg>
    </div>
  );
}

export function WalmartLogo({ className = 'h-12' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 180 50" className="h-full w-auto max-w-full">
        {/* Walmart Blue Text */}
        <text
          x="10"
          y="33"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="29"
          fill="#0071ce"
          letterSpacing="-0.5px"
        >
          Walmart
        </text>
        {/* Walmart Yellow Spark (6 rounded radiating petals) */}
        <g transform="translate(148, 25)">
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" />
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" transform="rotate(60)" />
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" transform="rotate(120)" />
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" transform="rotate(180)" />
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" transform="rotate(240)" />
          <rect x="-2.2" y="-16" width="4.4" height="9" rx="2.2" fill="#ffc220" transform="rotate(300)" />
        </g>
      </svg>
    </div>
  );
}

