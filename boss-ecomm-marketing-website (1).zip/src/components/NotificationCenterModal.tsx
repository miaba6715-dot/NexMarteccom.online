import React, { useState } from 'react';
import {
  Bell,
  X,
  CheckCircle2,
  Trash2,
  Volume2,
  VolumeX,
  Smartphone,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  Clock,
  RefreshCw,
  Check,
} from 'lucide-react';
import { AppNotification, NotificationSettings } from '../types';
import { playNotificationSound, requestBrowserPermission } from '../services/notificationService';

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
  settings: NotificationSettings;
  onUpdateSettings: (newSettings: NotificationSettings) => void;
  onMarkAllRead: () => void;
  onClearAll: () => void;
  onDeleteNotification: (id: string) => void;
  onAction: (notification: AppNotification) => void;
  onSimulateQuotaRefresh: () => void;
  onSimulateSalaryAvailable: () => void;
}

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  isOpen,
  onClose,
  notifications,
  settings,
  onUpdateSettings,
  onMarkAllRead,
  onClearAll,
  onDeleteNotification,
  onAction,
  onSimulateQuotaRefresh,
  onSimulateSalaryAvailable,
}) => {
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [browserPermStatus, setBrowserPermStatus] = useState<string>(
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported'
  );

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;
  const filteredList =
    filter === 'unread' ? notifications.filter((n) => !n.read) : notifications;

  const handleToggleSound = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    onUpdateSettings(updated);
    if (updated.soundEnabled) {
      playNotificationSound();
    }
  };

  const handleToggleBrowser = async () => {
    if (!('Notification' in window)) {
      alert('Browser notifications are not supported on this device/browser.');
      return;
    }
    if (Notification.permission === 'granted') {
      const updated = { ...settings, browserEnabled: !settings.browserEnabled };
      onUpdateSettings(updated);
      setBrowserPermStatus('granted');
    } else {
      const res = await requestBrowserPermission();
      setBrowserPermStatus(res);
      if (res === 'granted') {
        onUpdateSettings({ ...settings, browserEnabled: true });
      } else {
        onUpdateSettings({ ...settings, browserEnabled: false });
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[130] flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-gray-100 flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-extrabold tracking-tight text-white">
                  Notification Center
                </h3>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-red-500 text-white text-[10px] font-black tracking-wider">
                    {unreadCount} NEW
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Daily task quota & VIP salary alerts
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preferences & Quick Toggles */}
        <div className="px-4 sm:px-5 py-3 bg-slate-50 border-b border-gray-200/80 flex flex-wrap items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2">
            {/* Sound Toggle */}
            <button
              type="button"
              onClick={handleToggleSound}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 font-semibold transition-all cursor-pointer ${
                settings.soundEnabled
                  ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-xs'
                  : 'bg-white border-gray-200 text-gray-500'
              }`}
              title="Toggle audio chime on alerts"
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-3.5 h-3.5 text-[#1877f2]" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-gray-400" />
              )}
              <span>Sound {settings.soundEnabled ? 'ON' : 'OFF'}</span>
            </button>

            {/* Test Chime */}
            {settings.soundEnabled && (
              <button
                type="button"
                onClick={playNotificationSound}
                className="px-2.5 py-1.5 rounded-xl bg-white border border-gray-200 hover:bg-gray-100 text-gray-600 font-medium text-[11px] transition-colors cursor-pointer"
                title="Play test chime"
              >
                Test Sound
              </button>
            )}

            {/* Browser Push Toggle */}
            <button
              type="button"
              onClick={handleToggleBrowser}
              className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 font-semibold transition-all cursor-pointer ${
                settings.browserEnabled && browserPermStatus === 'granted'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-700 shadow-xs'
                  : 'bg-white border-gray-200 text-gray-600'
              }`}
              title="Toggle Native Browser Push Notifications"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>
                Push{' '}
                {browserPermStatus === 'granted' && settings.browserEnabled
                  ? 'Active'
                  : 'Enable'}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={onMarkAllRead}
                className="text-[11px] font-bold text-[#1877f2] hover:underline cursor-pointer"
              >
                Mark all read
              </button>
            )}
            {notifications.length > 0 && (
              <button
                type="button"
                onClick={onClearAll}
                className="text-[11px] font-bold text-gray-400 hover:text-red-500 transition-colors ml-2 cursor-pointer flex items-center gap-0.5"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Pills */}
        <div className="px-4 sm:px-5 pt-3 pb-2 flex items-center justify-between border-b border-gray-100">
          <div className="flex items-center gap-1.5 bg-gray-100 p-1 rounded-xl text-xs font-bold">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filter === 'all'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('unread')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                filter === 'unread'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              Unread ({unreadCount})
            </button>
          </div>

          <span className="text-[11px] text-gray-400 font-medium">
            Local Device Storage
          </span>
        </div>

        {/* Notifications Scroll List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 divide-y-0">
          {filteredList.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-14 h-14 mx-auto rounded-3xl bg-blue-50 text-blue-500 flex items-center justify-center mb-3">
                <Bell className="w-7 h-7 text-[#1877f2]" />
              </div>
              <h4 className="text-sm font-bold text-gray-800">
                {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
              </h4>
              <p className="text-xs text-gray-500 max-w-xs mx-auto mt-1">
                You will receive instant alerts here whenever your daily task quota refreshes or when a VIP salary is ready to claim.
              </p>
            </div>
          ) : (
            filteredList.map((notif) => {
              const isSalary = notif.type === 'salary_available';
              const isQuota = notif.type === 'quota_refreshed';

              return (
                <div
                  key={notif.id}
                  className={`p-3.5 sm:p-4 rounded-2xl border transition-all relative group ${
                    !notif.read
                      ? 'bg-blue-50/50 border-blue-100 shadow-xs'
                      : 'bg-white border-gray-100 hover:border-gray-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Icon */}
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isSalary
                          ? 'bg-emerald-100 text-emerald-600'
                          : isQuota
                          ? 'bg-blue-100 text-[#1877f2]'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {isSalary ? (
                        <Sparkles className="w-4 h-4" />
                      ) : isQuota ? (
                        <ShoppingBag className="w-4 h-4" />
                      ) : (
                        <Bell className="w-4 h-4" />
                      )}
                    </div>

                    {/* Text Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md ${
                              isSalary
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {isSalary ? 'VIP Salary' : 'Task Quota'}
                          </span>
                          {!notif.read && (
                            <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                          )}
                        </div>
                        <span className="text-[11px] text-gray-400 font-medium">
                          {notif.timestamp}
                        </span>
                      </div>

                      <h4 className="text-sm font-bold text-gray-900 mt-1 leading-snug">
                        {notif.title}
                      </h4>
                      <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">
                        {notif.message}
                      </p>

                      {/* Action Button */}
                      <div className="mt-3 flex items-center justify-between">
                        {notif.actionType === 'claim_salary' && (
                          <button
                            type="button"
                            onClick={() => {
                              onAction(notif);
                              onClose();
                            }}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 flex items-center gap-1.5 cursor-pointer"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>
                              Claim{' '}
                              {notif.metadata?.salaryAmount
                                ? `$${notif.metadata.salaryAmount}.00`
                                : 'Salary'}
                            </span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}

                        {notif.actionType === 'navigate_tasks' && (
                          <button
                            type="button"
                            onClick={() => {
                              onAction(notif);
                              onClose();
                            }}
                            className="px-3.5 py-1.5 bg-[#1877f2] hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 flex items-center gap-1.5 cursor-pointer"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Grab 25 Orders</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onDeleteNotification(notif.id)}
                          className="text-gray-400 hover:text-red-500 p-1 rounded-lg transition-colors ml-auto cursor-pointer"
                          title="Delete notification"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with Quick Simulation / Demo triggers for testing */}
        <div className="p-3.5 sm:p-4 bg-gray-50 border-t border-gray-200/80">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
              Instant Simulation:
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onSimulateQuotaRefresh}
                className="flex-1 sm:flex-none px-3 py-1.5 bg-white border border-blue-200 text-[#1877f2] hover:bg-blue-50 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Simulate Quota Refresh</span>
              </button>
              <button
                type="button"
                onClick={onSimulateSalaryAvailable}
                className="flex-1 sm:flex-none px-3 py-1.5 bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-50 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3 h-3" />
                <span>Simulate VIP Salary</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
