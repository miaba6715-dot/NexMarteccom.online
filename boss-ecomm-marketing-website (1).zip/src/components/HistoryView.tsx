import React, { useState } from 'react';
import { ShoppingCart, ArrowDownLeft, ArrowUpRight, CheckCircle2, Clock } from 'lucide-react';
import { OrderItem, Transaction } from '../types';

interface HistoryViewProps {
  orders: OrderItem[];
  transactions: Transaction[];
}

export const HistoryView: React.FC<HistoryViewProps> = ({ orders, transactions }) => {
  const [activeSubTab, setActiveSubTab] = useState<'orders' | 'finance'>('orders');
  const [filterStatus, setFilterStatus] = useState<'all' | 'completed' | 'pending'>('all');

  const filteredOrders = orders.filter((order) => {
    if (filterStatus === 'completed') return order.status === 'Completed';
    if (filterStatus === 'pending') return order.status === 'Pending';
    return true;
  });

  const filteredTransactions = transactions.filter((tx) => {
    if (filterStatus === 'completed') return tx.status === 'Approved';
    if (filterStatus === 'pending') return tx.status === 'Pending';
    return true;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-[#1877f2] rounded-2xl p-5 text-white shadow-md text-center">
        <h1 className="text-xl font-extrabold tracking-tight mb-1">Activity History</h1>
        <p className="text-xs text-blue-100">Review your past submitted orders and transaction records</p>
      </div>

      {/* Sub Tabs: Orders / Financial Records */}
      <div className="flex bg-white rounded-xl p-1 shadow-xs border border-gray-100">
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            activeSubTab === 'orders' ? 'bg-[#1877f2] text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Orders History ({orders.length})
        </button>
        <button
          onClick={() => setActiveSubTab('finance')}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
            activeSubTab === 'finance' ? 'bg-[#1877f2] text-white shadow-xs' : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          Financial Records ({transactions.length})
        </button>
      </div>

      {/* Filter status pills */}
      <div className="flex items-center gap-2 text-xs font-semibold">
        <span className="text-gray-400 text-[11px]">Filter:</span>
        {(['all', 'completed', 'pending'] as const).map((status) => (
          <button
            key={status}
            onClick={() => setFilterStatus(status)}
            className={`px-3 py-1 rounded-full text-xs capitalize transition-colors ${
              filterStatus === status
                ? 'bg-gray-800 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {/* ORDERS LIST */}
      {activeSubTab === 'orders' && (
        <div className="space-y-3">
          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center text-gray-400 border border-gray-100">
              <ShoppingCart className="w-10 h-10 mx-auto mb-2 text-gray-300" />
              <p className="text-xs font-medium">No orders found matching this filter.</p>
            </div>
          ) : (
            filteredOrders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-gray-100 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={order.image}
                      alt={order.title}
                      className="w-14 h-14 rounded-xl object-contain bg-gray-50 p-1 border border-gray-200 flex-shrink-0"
                    />
                    <div>
                      <span className="text-[10px] font-mono font-bold text-gray-400 block">
                        #{order.orderNumber}
                      </span>
                      <h4 className="text-xs font-bold text-gray-900 line-clamp-2 leading-snug">
                        {order.title}
                      </h4>
                      <span className="text-[10px] text-gray-400 font-medium">
                        {order.timestamp}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${
                      order.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {order.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-[#fbfbfb] rounded-xl p-2.5 text-center border border-gray-100">
                  <div>
                    <span className="text-[10px] text-gray-400 block">Order Value</span>
                    <span className="text-xs font-black text-gray-900">${order.orderAmount.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block">Commission Rate</span>
                    <span className="text-xs font-black text-[#1877f2]">
                      {(order.commissionRate * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-400 block">Earned Profit</span>
                    <span className="text-xs font-black text-emerald-600">
                      +${order.commission.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* FINANCIAL RECORDS LIST */}
      {activeSubTab === 'finance' && (
        <div className="space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 text-center text-gray-400 border border-gray-100">
              <Clock className="w-10 h-10 mx-auto mb-2 text-gray-300" />
              <p className="text-xs font-medium">No transactions found.</p>
            </div>
          ) : (
            filteredTransactions.map((tx) => (
              <div
                key={tx.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-gray-100 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${
                      tx.type === 'deposit'
                        ? 'bg-emerald-100 text-emerald-600'
                        : tx.type === 'withdraw'
                        ? 'bg-rose-100 text-rose-600'
                        : 'bg-blue-100 text-[#1877f2]'
                    }`}
                  >
                    {tx.type === 'deposit' && <ArrowDownLeft className="w-5 h-5" />}
                    {tx.type === 'withdraw' && <ArrowUpRight className="w-5 h-5" />}
                    {tx.type === 'commission' && <CheckCircle2 className="w-5 h-5" />}
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-gray-900 capitalize">
                      {tx.type === 'deposit'
                        ? 'USDT Deposit'
                        : tx.type === 'withdraw'
                        ? 'Account Withdrawal'
                        : 'Order Commission'}
                    </h4>
                    <span className="text-[10px] text-gray-400 block">{tx.timestamp}</span>
                    {tx.txHash && (
                      <span className="text-[9px] font-mono text-gray-400 block">Hash: {tx.txHash}</span>
                    )}
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`text-sm font-black block ${
                      tx.type === 'deposit' || tx.type === 'commission'
                        ? 'text-emerald-600'
                        : 'text-rose-600'
                    }`}
                  >
                    {tx.type === 'withdraw' ? '-' : '+'}${tx.amount.toFixed(2)}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                      tx.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-700'
                        : tx.status === 'Pending'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-rose-100 text-rose-700'
                    }`}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
