import React from 'react';
import {
  Globe,
  ChevronDown,
  Camera,
  CheckCircle,
  Copy,
  Check,
  ArrowRight,
  LogOut,
  Bell,
} from 'lucide-react';
import { UserProfile, VipPlan } from '../types';
import { AmazonLogo, ShopifyLogo, WalmartLogo } from './BrandLogos';
import { LanguageDropdown } from './LanguageDropdown';

interface HomeViewProps {
  user: UserProfile;
  vipPlans: VipPlan[];
  onOpenModal: (type: 'deposit' | 'withdraw' | 'about' | 'services' | 'language') => void;
  onNavigateToOrder: (vipLevel?: number) => void;
  onLogout: () => void;
  currentLanguage: string;
  onSelectLanguage?: (languageName: string) => void;
  onUpdateUser?: (updated: Partial<UserProfile>) => void;
  unreadNotificationCount?: number;
  onOpenNotifications?: () => void;
}

// NexMart Ecom modern logo matching reference
function NexMartLogo({ className = 'w-12 h-12 sm:w-14 sm:h-14' }: { className?: string }) {
  return (
    <div className={`relative shrink-0 flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 60 60" className="w-full h-full drop-shadow-[0_0_12px_rgba(0,255,135,0.45)]">
        <defs>
          <linearGradient id="nexGreenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00ff87" />
            <stop offset="50%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
          <linearGradient id="nexBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#082b1e" />
            <stop offset="100%" stopColor="#02140d" />
          </linearGradient>
        </defs>

        {/* Outer Rounded Squircle Base with Neon Green Border */}
        <rect
          x="3"
          y="3"
          width="54"
          height="54"
          rx="15"
          fill="url(#nexBgGrad)"
          stroke="url(#nexGreenGrad)"
          strokeWidth="2.2"
        />

        {/* Shopping Bag Handle with Neon Green Gradient */}
        <path
          d="M23 23 C23 15, 37 15, 37 23"
          fill="none"
          stroke="url(#nexGreenGrad)"
          strokeWidth="3.2"
          strokeLinecap="round"
        />

        {/* Shopping Bag Body */}
        <path
          d="M15 22 L45 22 L41 46 C40.5 48.5 38.5 50 36 50 L24 50 C21.5 50 19.5 48.5 19 46 Z"
          fill="#0a3525"
          stroke="url(#nexGreenGrad)"
          strokeWidth="2.4"
          strokeLinejoin="round"
        />

        {/* Facet Gradient Shading */}
        <path
          d="M30 22 L30 50 L41 46 L45 22 Z"
          fill="rgba(6, 182, 212, 0.16)"
        />

        {/* Futuristic 'N' Crest / Cart Monogram */}
        <path
          d="M23 43 L23 29 L37 43 L37 29"
          fill="none"
          stroke="url(#nexGreenGrad)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Glowing Spark Star in top-right */}
        <path
          d="M44 11 L45.5 15.5 L50 17 L45.5 18.5 L44 23 L42.5 18.5 L38 17 L42.5 15.5 Z"
          fill="#00ff87"
        />
        <circle cx="44" cy="17" r="1.5" fill="#ffffff" />
      </svg>
    </div>
  );
}

// Glowing Green & Emerald Wallet icon for Balance card
function BalanceWalletIcon({ className = 'w-10 h-9 sm:w-11 sm:h-10' }: { className?: string }) {
  return (
    <div className={`relative shrink-0 flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 46 40" className="w-full h-full drop-shadow-[0_0_10px_rgba(0,255,135,0.4)]">
        <defs>
          <linearGradient id="walletGreenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00ff87" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
        </defs>
        {/* Dollar cash bills peeking out */}
        <rect x="10" y="3" width="23" height="13" rx="3" fill="#6ee7b7" />
        <circle cx="21.5" cy="9.5" r="3.2" fill="#00ff87" />
        {/* Main wallet body */}
        <rect x="4" y="9" width="38" height="27" rx="7" fill="url(#walletGreenGrad)" />
        {/* Wallet top fold flap */}
        <path d="M4 14.5 C 4 10.5 7.5 9 11 9 L 35 9 C 38.5 9 42 10.5 42 14.5 Z" fill="#047857" />
        {/* Wallet snap clasp tab */}
        <path d="M29 18 H 40 C 42 18 43 19.5 43 22.5 C 43 25.5 42 27 40 27 H 29 Z" fill="#065f46" />
        <circle cx="36" cy="22.5" r="2.5" fill="#ffffff" />
      </svg>
    </div>
  );
}

// Withdraw icon matching Image 2
function WithdrawWalletIcon() {
  return (
    <svg
      viewBox="0 0 36 36"
      className="w-8 h-8 sm:w-10 sm:h-10 text-white fill-none stroke-current"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="4" y="9" width="28" height="21" rx="4.5" />
      <path d="M8 9 V 7 C 8 5.5 9.5 4.5 11 4.5 H 25 C 26.5 4.5 28 5.5 28 7 V 9" />
      <path d="M23 16 H 31 C 32 16 32.5 17 32.5 19.5 C 32.5 22 32 23 31 23 H 23 Z" />
      <circle cx="27.5" cy="19.5" r="1.5" fill="currentColor" />
    </svg>
  );
}

// Deposit icon matching Image 2 (two overlapping coins with plus sign)
function DepositCoinsIcon() {
  return (
    <svg
      viewBox="0 0 36 36"
      className="w-8 h-8 sm:w-10 sm:h-10 text-white fill-none stroke-current"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="14" cy="14" r="8" />
      <line x1="14" y1="10" x2="14" y2="18" strokeWidth="2.4" />
      <line x1="10" y1="14" x2="18" y2="14" strokeWidth="2.4" />
      <path d="M20 18 C 22.5 17.5 25.5 18.5 27 21 C 29 24 28 28 25 30 C 22 32 18 31 16 28 C 15 26.5 15 24.5 16 23" />
      <circle cx="22" cy="24.5" r="1.5" fill="currentColor" />
    </svg>
  );
}

// Live Chat Support icon matching Image 2 (speech bubble with green notification dot)
function LiveChatSupportIcon() {
  return (
    <div className="relative flex items-center justify-center">
      <svg
        viewBox="0 0 36 36"
        className="w-8 h-8 sm:w-10 sm:h-10 text-white fill-none stroke-current"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M7 6 C 5.5 6 4 7.5 4 9 V 23 C 4 24.5 5.5 26 7 26 H 10 L 10 30 L 16 26 H 27 C 28.5 26 30 24.5 30 23 V 9 C 30 7.5 28.5 6 27 6 Z" />
        <line x1="9" y1="12" x2="22" y2="12" strokeWidth="2.2" />
        <line x1="9" y1="16" x2="19" y2="16" strokeWidth="2.2" />
        <line x1="9" y1="20" x2="16" y2="20" strokeWidth="2.2" />
      </svg>
      {/* Green active status indicator */}
      <span className="absolute -top-1 -right-1 w-3 h-3 sm:w-3.5 sm:h-3.5 bg-[#10e599] border-2 border-white rounded-full shadow-xs" />
    </div>
  );
}

export const HomeView: React.FC<HomeViewProps> = ({
  user,
  vipPlans,
  onOpenModal,
  onNavigateToOrder,
  onLogout,
  currentLanguage,
  onSelectLanguage,
  onUpdateUser,
  unreadNotificationCount = 0,
  onOpenNotifications,
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [uploadToast, setUploadToast] = React.useState<string | null>(null);
  const [copiedCode, setCopiedCode] = React.useState(false);
  const [isDragOver, setIsDragOver] = React.useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleAvatarFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (PNG, JPG, JPEG, WEBP, GIF)');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl && onUpdateUser) {
        onUpdateUser({ avatarUrl: dataUrl });
        setUploadToast('Profile picture uploaded successfully!');
        setTimeout(() => setUploadToast(null), 3500);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleAvatarFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleAvatarFile(file);
    }
  };

  return (
    <div className="space-y-3.5 sm:space-y-4.5 animate-in fade-in duration-300 relative">
      {/* Upload Toast Notification */}
      {uploadToast && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2 text-xs sm:text-sm font-bold animate-in fade-in slide-in-from-top-2">
          <CheckCircle className="w-4 h-4 shrink-0 text-white" />
          <span>{uploadToast}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* HEADER SECTION - NEXMART ECOM (EXACT MATCH FOR UPLOADED DESIGN)            */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-br from-[#04120a] via-[#071f14] to-[#020b06] border border-emerald-500/35 sm:border-emerald-500/40 rounded-2xl sm:rounded-3xl p-4 sm:p-5.5 text-white shadow-[0_10px_35px_-5px_rgba(0,0,0,0.6),0_0_25px_rgba(16,185,129,0.18)] relative overflow-hidden">
        {/* Glowing Ambient Radial Lights */}
        <div className="absolute -top-24 -left-20 w-72 h-72 bg-emerald-500/18 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-20 w-72 h-72 bg-teal-500/18 rounded-full blur-3xl pointer-events-none" />

        {/* Subtle Background Flow Waves */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
          <svg className="w-full h-full" viewBox="0 0 1000 300" preserveAspectRatio="none">
            <path
              d="M0,80 C300,15 600,165 1000,40 L1000,300 L0,300 Z"
              fill="rgba(16, 185, 129, 0.25)"
            />
            <path
              d="M350,0 C650,110 820,15 1000,90 L1000,0 Z"
              fill="rgba(56, 189, 248, 0.15)"
            />
          </svg>
        </div>

        {/* Top Header Branding Row (NexMart Logo + Welcome to NexMart Ecom + Languages Button on side corner) */}
        <div className="relative z-30 flex items-center justify-between gap-3.5 sm:gap-4 mb-3.5 sm:mb-4">
          <div className="flex items-center gap-3.5 sm:gap-4">
            {/* NexMart Ecom Logo */}
            <div className="flex items-center gap-3 sm:gap-4">
              <NexMartLogo />
              {/* Glowing vertical divider */}
              <div className="h-8 sm:h-11 w-[1px] bg-gradient-to-b from-transparent via-emerald-400/40 to-transparent" />
            </div>

            {/* Typography */}
            <div className="flex flex-col">
              <span className="text-xs sm:text-base font-normal text-emerald-200/90 leading-tight">
                Welcome to
              </span>
              <h1 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight flex items-center gap-1.5 sm:gap-2">
                <span>NexMart</span>
                <span className="bg-gradient-to-r from-emerald-400 via-green-300 to-teal-200 bg-clip-text text-transparent drop-shadow-[0_0_12px_rgba(16,185,129,0.5)]">
                  Ecom
                </span>
              </h1>
              <span className="text-[9px] sm:text-[11px] font-black tracking-[0.24em] text-emerald-400 drop-shadow-[0_0_8px_rgba(0,255,135,0.4)] uppercase mt-0.5">
                SHOP. COMPLETE. EARN.
              </span>
            </div>
          </div>

          {/* Top-Right Side Corner Controls (Notification Bell + Languages Dropdown) */}
          <div className="flex items-center gap-2">
            {onOpenNotifications && (
              <button
                type="button"
                onClick={onOpenNotifications}
                title="Notifications (Daily Quota & VIP Salary)"
                className="relative bg-[#07251a]/95 hover:bg-[#0d3b2a] text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.18)] p-2 sm:p-2.5 rounded-xl sm:rounded-2xl border border-emerald-500/40 hover:border-emerald-400 transition-all active:scale-95 cursor-pointer flex items-center justify-center shrink-0"
              >
                <Bell className="w-4 h-4 text-emerald-400" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-gradient-to-r from-red-500 to-rose-600 text-white rounded-full text-[10px] font-black flex items-center justify-center shadow-[0_0_8px_rgba(239,68,68,0.6)] animate-pulse">
                    {unreadNotificationCount}
                  </span>
                )}
              </button>
            )}

            <LanguageDropdown
              currentLanguage={currentLanguage}
              onSelectLanguage={onSelectLanguage}
              buttonClassName="!bg-[#07251a]/95 hover:!bg-[#0d3b2a] !text-white !border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.18)] hover:!border-emerald-400 [&>span]:!text-white [&>svg]:!text-emerald-400"
            />
          </div>
        </div>

        {/* Inner Card / Welcome Back Section (Avatar, Name Mia, Code, Balance, Logout) */}
        <div className="relative z-10 bg-[#051c14]/85 backdrop-blur-md border border-emerald-500/35 rounded-xl sm:rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3.5 sm:gap-4 shadow-[inset_0_1px_1px_rgba(255,255,255,0.06),0_4px_20px_rgba(0,0,0,0.3)]">
          {/* Left: User Profile & Details */}
          <div className="flex items-center gap-3 sm:gap-3.5">
            {/* Avatar Circle with Neon Green / Cyan Glowing Ring & Camera Badge */}
            <div
              className="relative group shrink-0"
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
            >
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleAvatarFileChange}
                className="hidden"
                id="avatar-photo-upload"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Click to upload profile picture"
                className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full p-0.5 bg-gradient-to-tr from-[#00ff87] via-[#10b981] to-[#00d2ff] shadow-[0_0_16px_rgba(0,255,135,0.35)] flex items-center justify-center cursor-pointer transition-all hover:scale-105 focus:outline-none ${
                  isDragOver ? 'ring-4 ring-emerald-300' : ''
                }`}
              >
                <div className="w-full h-full rounded-full bg-[#03170e] flex items-center justify-center overflow-hidden relative">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.username}
                      className="w-full h-full object-cover rounded-full"
                    />
                  ) : (
                    <svg viewBox="0 0 24 24" className="w-7 h-7 sm:w-8 sm:h-8 fill-emerald-100">
                      <circle cx="12" cy="8" r="4" />
                      <path d="M4 20c0-4 4-6 8-6s8 2 8 6" />
                    </svg>
                  )}

                  {/* Dark Hover Overlay */}
                  <div className="absolute inset-0 bg-black/55 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                    <Camera className="w-3.5 h-3.5 text-white" />
                    <span className="text-[7px] font-bold text-white uppercase mt-0.5">Upload</span>
                  </div>
                </div>
              </button>

              {/* Camera Badge (bottom right) */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Upload photo"
                className="absolute -bottom-0.5 -right-0.5 w-4.5 h-4.5 sm:w-5 sm:h-5 bg-emerald-500 border-2 border-[#051c14] text-white rounded-full flex items-center justify-center shadow-md hover:bg-emerald-400 transition-transform active:scale-95 cursor-pointer"
              >
                <Camera className="w-2 h-2 sm:w-2.5 sm:h-2.5" />
              </button>
            </div>

            {/* Username & Code Pill */}
            <div className="flex flex-col justify-center min-w-0">
              <span className="text-[9px] sm:text-[10px] font-black tracking-widest text-emerald-400 uppercase drop-shadow-[0_0_6px_rgba(16,185,129,0.3)]">
                WELCOME BACK
              </span>
              <span className="text-lg sm:text-xl font-black text-white capitalize leading-tight">
                {user.username}
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  title="Click to copy referral code"
                  className="inline-flex items-center gap-1.5 bg-[#042419]/90 hover:bg-[#073624] border border-emerald-500/40 px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-emerald-100 transition-all shadow-[0_0_10px_rgba(16,185,129,0.12)] active:scale-95 cursor-pointer"
                >
                  <span>Code : {user.referralCode}</span>
                  {copiedCode ? (
                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-2.5 h-2.5 text-emerald-300 hover:text-white" />
                  )}
                </button>
                {copiedCode && (
                  <span className="text-[10px] text-emerald-300 font-semibold animate-in fade-in">
                    Copied!
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Right: Balance Card & Logout Button */}
          <div className="flex items-center justify-between lg:justify-end gap-2.5 sm:gap-3">
            {/* Balance Card (Deep dark green container with glowing wallet) */}
            <div className="bg-gradient-to-br from-[#062c1e] to-[#031d14] border border-emerald-500/50 shadow-[0_0_16px_rgba(16,185,129,0.22)] rounded-xl px-3.5 sm:px-4 py-2 sm:py-2.5 flex items-center gap-2.5 sm:gap-3">
              <BalanceWalletIcon className="w-9 h-8 sm:w-10 sm:h-9" />
              <div className="flex flex-col">
                <span className="text-[9px] sm:text-[10px] font-bold text-emerald-300/90 tracking-widest uppercase">
                  BALANCE
                </span>
                <span className="text-lg sm:text-xl font-black text-white leading-none">
                  ${user.balance.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Logout Button */}
            <button
              onClick={onLogout}
              className="border border-emerald-500/40 bg-[#06251b]/90 hover:bg-[#0c3929] hover:border-emerald-400 text-white hover:text-emerald-200 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl flex items-center gap-1.5 font-bold text-xs sm:text-sm transition-all shadow-[0_0_12px_rgba(16,185,129,0.12)] active:scale-95 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* QUICK ACTION CARDS (EXACT MATCH FOR IMAGE 2)                               */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4.5">
        {/* Card 1: Withdraw */}
        <div
          onClick={() => onOpenModal('withdraw')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-blue-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          {/* Subtle Top-Left Pastel Glow */}
          <div className="absolute -top-10 -left-10 w-24 h-24 bg-blue-100/40 rounded-full blur-xl pointer-events-none" />

          {/* Left Side: Squircle Icon + Texts */}
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Blue Squircle App Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#2575fc] to-[#0052cc] shadow-[0_8px_18px_rgba(0,82,204,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <WithdrawWalletIcon />
            </div>

            {/* Texts */}
            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Withdraw
              </h3>
              {/* Cyan Accent Dash */}
              <div className="w-3.5 h-0.5 bg-[#00d2ff] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                Get your earnings to your wallet
              </p>
            </div>
          </div>

          {/* Right Side: Circular Arrow Button */}
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-blue-50/80 text-blue-600 group-hover:bg-[#0052cc] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>

        {/* Card 2: Deposit */}
        <div
          onClick={() => onOpenModal('deposit')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-emerald-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          {/* Subtle Top-Left Pastel Glow */}
          <div className="absolute -top-10 -left-10 w-24 h-24 bg-emerald-100/40 rounded-full blur-xl pointer-events-none" />

          {/* Left Side: Squircle Icon + Texts */}
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Green Squircle App Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#14e89c] to-[#05b875] shadow-[0_8px_18px_rgba(5,184,117,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <DepositCoinsIcon />
            </div>

            {/* Texts */}
            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Deposit
              </h3>
              {/* Teal Accent Dash */}
              <div className="w-3.5 h-0.5 bg-[#05b875] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                Add funds to your account
              </p>
            </div>
          </div>

          {/* Right Side: Circular Arrow Button */}
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-50/80 text-emerald-600 group-hover:bg-[#05b875] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>

        {/* Card 3: Live Chat Support */}
        <div
          onClick={() => onOpenModal('services')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-purple-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          {/* Subtle Top-Left Pastel Glow */}
          <div className="absolute -top-10 -left-10 w-24 h-24 bg-purple-100/40 rounded-full blur-xl pointer-events-none" />

          {/* Left Side: Squircle Icon + Texts */}
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Purple Squircle App Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#8b5cf6] to-[#6366f1] shadow-[0_8px_18px_rgba(99,102,241,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <LiveChatSupportIcon />
            </div>

            {/* Texts */}
            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Live Chat Support
              </h3>
              {/* Cyan Accent Dash */}
              <div className="w-3.5 h-0.5 bg-[#00d2ff] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                We're here to help you 24/7
              </p>
            </div>
          </div>

          {/* Right Side: Circular Arrow Button */}
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-purple-50/80 text-purple-600 group-hover:bg-[#6366f1] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIP TIERS SECTION (EXACT MATCH FOR IMAGE 1)                               */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
        {/* VIP 1: Amazon */}
        <div
          onClick={() => onNavigateToOrder(1)}
          className="bg-white rounded-[24px] sm:rounded-[28px] overflow-hidden shadow-[0_10px_28px_rgba(0,0,0,0.06)] hover:shadow-[0_16px_36px_rgba(0,0,0,0.1)] border border-blue-50/80 flex flex-col cursor-pointer transition-all duration-200 hover:-translate-y-0.5 group"
        >
          {/* Header Bar */}
          <div className="bg-[#0070f3] text-white px-5 sm:px-6 py-3.5 sm:py-4 flex items-center justify-between font-bold">
            <span className="text-lg sm:text-xl font-bold tracking-tight">VIP 1</span>
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="h-4 w-[1px] bg-white/40" />
              <span className="text-sm sm:text-base font-bold">Profit 4%</span>
            </div>
          </div>

          {/* Logo Area */}
          <div className="p-6 sm:p-7 flex-1 flex flex-col items-center justify-center min-h-[140px] sm:min-h-[160px]">
            <AmazonLogo className="h-11 sm:h-13 group-hover:scale-105 transition-transform" />
          </div>

          {/* Minimum Balance Box */}
          <div className="px-5 pb-5 sm:px-6 sm:pb-6">
            <div className="bg-[#edf4fe] rounded-2xl py-3.5 px-4 text-center transition-colors group-hover:bg-[#e4effd]">
              <div className="text-xs sm:text-sm font-semibold text-gray-600">
                Minimum Balance:
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#0f294a] tracking-tight mt-0.5">
                $30.00
              </div>
            </div>
          </div>
        </div>

        {/* VIP 2: Shopify */}
        <div
          onClick={() => onNavigateToOrder(2)}
          className="bg-white rounded-[24px] sm:rounded-[28px] overflow-hidden shadow-[0_10px_28px_rgba(0,0,0,0.06)] hover:shadow-[0_16px_36px_rgba(0,0,0,0.1)] border border-blue-50/80 flex flex-col cursor-pointer transition-all duration-200 hover:-translate-y-0.5 group"
        >
          {/* Header Bar */}
          <div className="bg-[#0070f3] text-white px-5 sm:px-6 py-3.5 sm:py-4 flex items-center justify-between font-bold">
            <span className="text-lg sm:text-xl font-bold tracking-tight">VIP 2</span>
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="h-4 w-[1px] bg-white/40" />
              <span className="text-sm sm:text-base font-bold">Profit 8%</span>
            </div>
          </div>

          {/* Logo Area */}
          <div className="p-6 sm:p-7 flex-1 flex flex-col items-center justify-center min-h-[140px] sm:min-h-[160px]">
            <ShopifyLogo className="h-12 sm:h-14 group-hover:scale-105 transition-transform" />
          </div>

          {/* Minimum Balance Box */}
          <div className="px-5 pb-5 sm:px-6 sm:pb-6">
            <div className="bg-[#edf4fe] rounded-2xl py-3.5 px-4 text-center transition-colors group-hover:bg-[#e4effd]">
              <div className="text-xs sm:text-sm font-semibold text-gray-600">
                Minimum Balance:
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#0f294a] tracking-tight mt-0.5">
                $499.00
              </div>
            </div>
          </div>
        </div>

        {/* VIP 3: Walmart */}
        <div
          onClick={() => onNavigateToOrder(3)}
          className="bg-white rounded-[24px] sm:rounded-[28px] overflow-hidden shadow-[0_10px_28px_rgba(0,0,0,0.06)] hover:shadow-[0_16px_36px_rgba(0,0,0,0.1)] border border-blue-50/80 flex flex-col cursor-pointer transition-all duration-200 hover:-translate-y-0.5 group"
        >
          {/* Header Bar */}
          <div className="bg-[#0070f3] text-white px-5 sm:px-6 py-3.5 sm:py-4 flex items-center justify-between font-bold">
            <span className="text-lg sm:text-xl font-bold tracking-tight">VIP 3</span>
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="h-4 w-[1px] bg-white/40" />
              <span className="text-sm sm:text-base font-bold">Profit 12%</span>
            </div>
          </div>

          {/* Logo Area */}
          <div className="p-6 sm:p-7 flex-1 flex flex-col items-center justify-center min-h-[140px] sm:min-h-[160px]">
            <WalmartLogo className="h-10 sm:h-12 group-hover:scale-105 transition-transform" />
          </div>

          {/* Minimum Balance Box */}
          <div className="px-5 pb-5 sm:px-6 sm:pb-6">
            <div className="bg-[#edf4fe] rounded-2xl py-3.5 px-4 text-center transition-colors group-hover:bg-[#e4effd]">
              <div className="text-xs sm:text-sm font-semibold text-gray-600">
                Minimum Balance:
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#0f294a] tracking-tight mt-0.5">
                $900.00
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dedicated bottom spacer so VIP cards are 100% visible above BottomNav */}
      <div className="h-10 sm:h-14 w-full shrink-0" aria-hidden="true" />
    </div>
  );
};

