import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  MessageCircle,
  Send,
  Paperclip,
  Mic,
  MicOff,
  Image as ImageIcon,
  Clock,
  Users,
  X,
  Play,
  Pause,
  CheckCheck,
  Sparkles,
  Headphones,
  Check,
} from 'lucide-react';
import { UserProfile, AdminChatMessage } from '../types';

interface CustomerSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  initialView?: 'channels' | 'chat';
}

const DEFAULT_WELCOME_MESSAGES: AdminChatMessage[] = [];

export const CustomerSupportModal: React.FC<CustomerSupportModalProps> = ({
  isOpen,
  onClose,
  user,
  initialView = 'channels',
}) => {
  const userCode = user.referralCode || (user as any).inviteCode || '';
  const [currentView, setCurrentView] = useState<'channels' | 'chat'>(initialView);
  const [messages, setMessages] = useState<AdminChatMessage[]>(() => {
    try {
      if (userCode) {
        const saved = localStorage.getItem(`bam_chat_${userCode}`);
        if (saved) {
          return JSON.parse(saved);
        }
      }
    } catch (e) {
      console.warn('Failed to load chat messages from localStorage:', e);
    }
    return DEFAULT_WELCOME_MESSAGES;
  });

  const [inputMessage, setInputMessage] = useState('');
  const [isAgentTyping, setIsAgentTyping] = useState(false);
  const [agentStatus, setAgentStatus] = useState<'online' | 'offline'>(() => {
    try {
      const savedMode = localStorage.getItem('bam_chat_mode');
      if (savedMode === 'offline' || savedMode === 'online') {
        return savedMode;
      }
    } catch (e) {
      // fallback
    }
    return 'online';
  });
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [previewEnlargedImage, setPreviewEnlargedImage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recordingTimerRef = useRef<any>(null);

  // Anti-rapid-spam and anti-repetition memory
  const botReplyHistoryRef = useRef<{ category: string; text: string; timestamp: number }[]>([]);
  const pendingBotTimerRef = useRef<any>(null);
  const pendingUserMessagesRef = useRef<string[]>([]);

  // Sync initial view when modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentView(initialView);
    }
  }, [isOpen, initialView]);

  // Real-time synchronization for Admin replies & Mode toggling from AdminBackend
  useEffect(() => {
    const syncFromStorage = () => {
      try {
        // 1. Sync messages from AdminBackend
        if (userCode) {
          const saved = localStorage.getItem(`bam_chat_${userCode}`);
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed)) {
              setMessages((current) => {
                if (JSON.stringify(current) !== saved) {
                  return parsed;
                }
                return current;
              });
            }
          }
        }
        // 2. Sync chat mode
        const savedMode = localStorage.getItem('bam_chat_mode');
        if (savedMode === 'offline' || savedMode === 'online') {
          setAgentStatus((prev) => (prev !== savedMode ? (savedMode as any) : prev));
        }
      } catch (e) {
        console.warn('Chat storage sync error:', e);
      }
    };

    window.addEventListener('storage', syncFromStorage);
    window.addEventListener('bam_chat_update', syncFromStorage);
    window.addEventListener('bam_chat_mode_changed', syncFromStorage);

    const interval = setInterval(syncFromStorage, 1000);

    return () => {
      window.removeEventListener('storage', syncFromStorage);
      window.removeEventListener('bam_chat_update', syncFromStorage);
      window.removeEventListener('bam_chat_mode_changed', syncFromStorage);
      clearInterval(interval);
    };
  }, [userCode]);

  // Persist messages to localStorage & update global conversations
  useEffect(() => {
    try {
      if (!userCode || messages.length === 0) {
        return;
      }
      localStorage.setItem(`bam_chat_${userCode}`, JSON.stringify(messages));
      // Also sync to global conversations for AdminBackend
      const lastMsg = messages.length > 0 ? messages[messages.length - 1].text : 'No messages';
      const lastTime = messages.length > 0 ? messages[messages.length - 1].time : 'Just now';
      const lastSender = messages.length > 0 ? messages[messages.length - 1].sender : 'admin';
      
      // If this user was deleted or blocked (e.g. Kali / rani), do not re-add
      const userNameLower = (user.username || '').toLowerCase();
      if (
        userNameLower === 'kali' ||
        userNameLower === 'rani' ||
        userCode === '992812' ||
        userCode === '441029'
      ) {
        return;
      }

      const activeConv = {
        id: `conv-${userCode}`,
        username: user.username,
        userCode: userCode,
        lastMessage: lastMsg,
        time: lastTime,
        unreadCount: lastSender === 'user' ? 1 : 0,
        messages: messages,
      };

      const existingConvs = JSON.parse(localStorage.getItem('bam_admin_conversations') || '[]');
      const filtered = existingConvs.filter(
        (c: any) =>
          c.userCode !== userCode &&
          c.username?.toLowerCase() !== 'kali' &&
          c.username?.toLowerCase() !== 'rani' &&
          c.userCode !== '992812' &&
          c.userCode !== '441029' &&
          c.userCode &&
          c.userCode !== '—' &&
          c.userCode !== 'undefined'
      );
      localStorage.setItem('bam_admin_conversations', JSON.stringify([activeConv, ...filtered]));
      window.dispatchEvent(new CustomEvent('bam_chat_update', { detail: { userCode } }));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [messages, user, userCode]);

  // Scroll to bottom when messages update
  useEffect(() => {
    if (currentView === 'chat') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, currentView, isAgentTyping]);

  // Voice recording timer simulation
  useEffect(() => {
    if (isRecording) {
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      setRecordingSeconds(0);
    }
    return () => {
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    };
  }, [isRecording]);

  if (!isOpen) return null;

  const getCurrentTime = () => {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    return `${hours.toString().padStart(2, '0')}:${minutes} ${ampm}`;
  };

  // Toggle or change agent mode
  const handleSetMode = (mode: 'online' | 'offline') => {
    setAgentStatus(mode);
    try {
      localStorage.setItem('bam_chat_mode', mode);
      window.dispatchEvent(new Event('bam_chat_mode_changed'));
    } catch (e) {
      console.warn('Failed to save chat mode:', e);
    }
  };

  // Smart non-repetitive bot response engine (Level 1, 2, 3 progressive replies)
  const generateSmartBotReply = (
    userQueries: string[],
    hasImg: boolean,
    hasAudio: boolean
  ): { replyText: string; category: string } => {
    const combinedQuery = userQueries.join(' ').toLowerCase().trim();
    const now = Date.now();

    // Count how many times this topic was answered in the last 4 minutes
    const getCategoryCount = (cat: string) => {
      return botReplyHistoryRef.current.filter(
        (r) => r.category === cat && now - r.timestamp < 240000
      ).length;
    };

    // 1. Image Attachment
    if (hasImg) {
      const count = getCategoryCount('image');
      if (count === 0) {
        return {
          category: 'image',
          replyText: `Thank you for uploading the image attachment! Our VIP verification desk has received your document and is reviewing it now (Reference #BAM-${Math.floor(100000 + Math.random() * 900000)}).`,
        };
      }
      return {
        category: 'image',
        replyText: `Additional document logged under your support ticket. Our team is cross-referencing this screenshot against your account #${userCode}.`,
      };
    }

    // 2. Audio Note
    if (hasAudio) {
      const count = getCategoryCount('audio');
      if (count === 0) {
        return {
          category: 'audio',
          replyText: `We have received your voice message. Our support specialist is listening to your audio note and will respond promptly.`,
        };
      }
      return {
        category: 'audio',
        replyText: `Follow-up audio note received and appended to your active ticket. Reviewing now.`,
      };
    }

    // 3. Deposit / Recharge / USDT / TRC
    if (
      combinedQuery.includes('deposit') ||
      combinedQuery.includes('recharge') ||
      combinedQuery.includes('usdt') ||
      combinedQuery.includes('trc') ||
      combinedQuery.includes('topup') ||
      combinedQuery.includes('crypto') ||
      combinedQuery.includes('payment')
    ) {
      const count = getCategoryCount('deposit');
      if (count === 0) {
        return {
          category: 'deposit',
          replyText: `To deposit USDT (TRC-20): Go to "Deposit" on your dashboard, copy our official TRC-20 wallet address or scan the QR code. Minimum deposit is 30 USDT. Blockchain confirmations typically take 3 to 10 minutes.`,
        };
      } else if (count === 1) {
        return {
          category: 'deposit',
          replyText: `If you have already sent your deposit, please send your Transaction ID (TxID) or transfer screenshot using the paperclip 📎 button below. Our audit team will manually verify the blockchain receipt and credit your balance immediately.`,
        };
      }
      return {
        category: 'deposit',
        replyText: `Your deposit inquiry is prioritized with our TRC-20 blockchain auditor. As soon as the TRC-20 network validates the blocks, the funds will immediately credit to your balance.`,
      };
    }

    // 4. Withdrawal / Payout / Cashout
    if (
      combinedQuery.includes('withdraw') ||
      combinedQuery.includes('payout') ||
      combinedQuery.includes('cashout') ||
      combinedQuery.includes('money') ||
      combinedQuery.includes('arrival') ||
      combinedQuery.includes('fee')
    ) {
      const count = getCategoryCount('withdraw');
      if (count === 0) {
        return {
          category: 'withdraw',
          replyText: `Withdrawals are processed 24/7. VIP 1 members enjoy 0% handling fee with an arrival time of 10 to 30 minutes. Please ensure your TRC-20 wallet address is correctly bound under "Withdrawal Account".`,
        };
      } else if (count === 1) {
        return {
          category: 'withdraw',
          replyText: `All withdrawal transactions undergo an automated security audit. You can review your real-time processing status under My Profile > History > Withdrawal Records.`,
        };
      }
      return {
        category: 'withdraw',
        replyText: `Our financial team is clearing the withdrawal queue in order. If your request has been pending for over 30 minutes, please confirm your TRC-20 wallet address here for priority clearing.`,
      };
    }

    // 5. Order Tasks / Amazon Orders / Commissions
    if (
      combinedQuery.includes('order') ||
      combinedQuery.includes('task') ||
      combinedQuery.includes('grab') ||
      combinedQuery.includes('commission') ||
      combinedQuery.includes('freeze') ||
      combinedQuery.includes('product') ||
      combinedQuery.includes('submit')
    ) {
      const count = getCategoryCount('order');
      if (count === 0) {
        return {
          category: 'order',
          replyText: `Each VIP tier unlocks daily merchant ranking tasks (e.g. VIP 1 gives 30 orders/day with 5% commission per order). After clicking "Submit Order", your commission profit is settled to your available balance immediately!`,
        };
      } else if (count === 1) {
        return {
          category: 'order',
          replyText: `Daily merchant orders refresh every 24 hours at 00:00. Completing all daily tasks ensures your account reputation remains high and unlocks continuous VIP bonus commissions.`,
        };
      }
      return {
        category: 'order',
        replyText: `If an order task appears on hold, check your available balance or navigate to "Amazon Orders" and tap "Submit Order". Our order dispatch desk is available to assist if you need manual clearance.`,
      };
    }

    // 6. VIP Levels & Upgrades
    if (
      combinedQuery.includes('vip') ||
      combinedQuery.includes('upgrade') ||
      combinedQuery.includes('level') ||
      combinedQuery.includes('tier') ||
      combinedQuery.includes('plan')
    ) {
      const count = getCategoryCount('vip');
      if (count === 0) {
        return {
          category: 'vip',
          replyText: `VIP upgrades activate automatically as soon as your account balance meets the threshold (VIP 1: $30+, VIP 2: $499+, VIP 3: $900+). Higher VIP tiers grant higher commission rates and more daily orders without any manual upgrade fee!`,
        };
      }
      return {
        category: 'vip',
        replyText: `Once you reach a higher VIP tier, lower tiers lock automatically and your commission percentage increases immediately (e.g., VIP 2 earns 8% and VIP 3 earns 12%).`,
      };
    }

    // 7. Salary & Referral Program
    if (
      combinedQuery.includes('salary') ||
      combinedQuery.includes('invit') ||
      combinedQuery.includes('reward') ||
      combinedQuery.includes('bonus') ||
      combinedQuery.includes('referral') ||
      combinedQuery.includes('team')
    ) {
      const count = getCategoryCount('salary');
      if (count === 0) {
        return {
          category: 'salary',
          replyText: `Our Daily Salary program pays automated bonuses based on qualified active team members. Share your referral code (${userCode}) with friends to unlock up to $1,000+ daily salaries!`,
        };
      }
      return {
        category: 'salary',
        replyText: `You can check your attendance streak and claim team salary bonuses directly on the "Salary" tab in the bottom menu.`,
      };
    }

    // 8. Help / Problems / Errors
    if (
      combinedQuery.includes('help') ||
      combinedQuery.includes('issue') ||
      combinedQuery.includes('problem') ||
      combinedQuery.includes('error') ||
      combinedQuery.includes('not working') ||
      combinedQuery.includes('stuck') ||
      combinedQuery.includes('support')
    ) {
      const count = getCategoryCount('help');
      if (count === 0) {
        return {
          category: 'help',
          replyText: `We are actively monitoring your account (${user.username}, Code: ${userCode}). Could you please describe the specific issue or error message you are seeing?`,
        };
      }
      return {
        category: 'help',
        replyText: `Our live support team has logged your report. You can also tap the paperclip icon 📎 to upload a screenshot so we can investigate faster.`,
      };
    }

    // 9. Greetings (hi, hello, hey)
    if (
      combinedQuery.includes('hi') ||
      combinedQuery.includes('hello') ||
      combinedQuery.includes('hey') ||
      combinedQuery.includes('good morning') ||
      combinedQuery.includes('good afternoon') ||
      combinedQuery.includes('good evening')
    ) {
      const count = getCategoryCount('greeting');
      if (count === 0) {
        return {
          category: 'greeting',
          replyText: `Hello ${user.username}! Welcome to Boss Ecomm Marketing 24/7 Live Support. How may we assist you today with deposits, withdrawals, or orders?`,
        };
      } else if (count === 1) {
        return {
          category: 'greeting',
          replyText: `I'm still right here with you, ${user.username}! Feel free to type your question or tell me what task you are working on.`,
        };
      }
      return {
        category: 'greeting',
        replyText: `You can ask anything regarding your account, or attach a payment receipt if you have a pending transaction.`,
      };
    }

    // 10. General / Unmatched Fallbacks (Rotated across 3 distinct variations)
    const fallbacks = [
      `Thank you for reaching out, ${user.username}. I have noted your inquiry regarding "${combinedQuery.slice(0, 35)}${combinedQuery.length > 35 ? '...' : ''}" and our system is checking your account (Code: ${userCode}). Please hold on.`,
      `Received! We have registered your message under your account #${userCode}. Our on-duty representative is reviewing the merchant records now.`,
      `Understood, ${user.username}. If you have any relevant screenshots, order IDs, or transfer details, please feel free to attach them using the paperclip 📎 icon below.`,
    ];

    const generalCount = getCategoryCount('general');
    const selectedFallback = fallbacks[generalCount % fallbacks.length];
    return {
      category: 'general',
      replyText: selectedFallback,
    };
  };

  // Send text message (with strict Online vs Offline mode separation)
  const handleSendMessage = (overrideText?: string) => {
    const textToSend = overrideText !== undefined ? overrideText : inputMessage.trim();
    if (!textToSend && !attachedImage) return;

    const newMsg: AdminChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: textToSend || (attachedImage ? 'Sent an attachment' : ''),
      time: getCurrentTime(),
      imageUrl: attachedImage || undefined,
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputMessage('');
    const hadImage = Boolean(attachedImage);
    setAttachedImage(null);

    // =========================================================================
    // OFFLINE MODE: "Don't send any auto reply i will manage myself from backend"
    // =========================================================================
    if (agentStatus === 'offline') {
      // In offline mode: absolutely NO bot reply or typing indicator is triggered!
      // The message is stored in localStorage & bam_admin_conversations for admin review.
      return;
    }

    // =========================================================================
    // ONLINE MODE: Smart Auto-Reply with anti-rapid burst debounce & non-repetition
    // =========================================================================
    if (textToSend) {
      pendingUserMessagesRef.current.push(textToSend);
    }

    // Cancel any previous pending timer if user is typing rapidly (Prevents rapid duplicate answers!)
    if (pendingBotTimerRef.current) {
      clearTimeout(pendingBotTimerRef.current);
    }

    // Wait for customer to finish their message burst before calculating smart response
    pendingBotTimerRef.current = setTimeout(() => {
      const bufferedQueries = [...pendingUserMessagesRef.current];
      pendingUserMessagesRef.current = [];

      setIsAgentTyping(true);

      setTimeout(() => {
        setIsAgentTyping(false);
        const { replyText, category } = generateSmartBotReply(
          bufferedQueries,
          hadImage,
          false
        );

        // Record response to history to prevent duplicate answers
        botReplyHistoryRef.current.push({
          category,
          text: replyText,
          timestamp: Date.now(),
        });
        if (botReplyHistoryRef.current.length > 25) {
          botReplyHistoryRef.current.shift();
        }

        const botMsg: AdminChatMessage = {
          id: `msg-agent-${Date.now()}`,
          sender: 'admin',
          text: replyText,
          time: getCurrentTime(),
        };
        setMessages((prev) => [...prev, botMsg]);
      }, 900);
    }, 1300);
  };

  // Handle image upload from file picker
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  // Toggle voice note recording
  const handleToggleRecord = () => {
    if (isRecording) {
      // Finish recording and send simulated voice note
      setIsRecording(false);
      const seconds = recordingSeconds > 0 ? recordingSeconds : 3;
      const newVoiceMsg: AdminChatMessage = {
        id: `voice-${Date.now()}`,
        sender: 'user',
        text: `Voice Note (0:${seconds.toString().padStart(2, '0')})`,
        time: getCurrentTime(),
        isAudio: true,
        audioDuration: `0:${seconds.toString().padStart(2, '0')}`,
      };
      setMessages((prev) => [...prev, newVoiceMsg]);

      // If offline mode, DO NOT send auto-reply
      if (agentStatus === 'offline') {
        return;
      }

      // Online mode auto-reply for audio note
      if (pendingBotTimerRef.current) {
        clearTimeout(pendingBotTimerRef.current);
      }
      pendingBotTimerRef.current = setTimeout(() => {
        setIsAgentTyping(true);
        setTimeout(() => {
          setIsAgentTyping(false);
          const { replyText, category } = generateSmartBotReply([], false, true);
          botReplyHistoryRef.current.push({
            category,
            text: replyText,
            timestamp: Date.now(),
          });
          const botMsg: AdminChatMessage = {
            id: `msg-agent-${Date.now()}`,
            sender: 'admin',
            text: replyText,
            time: getCurrentTime(),
          };
          setMessages((prev) => [...prev, botMsg]);
        }, 900);
      }, 1000);
    } else {
      setIsRecording(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md sm:max-w-lg md:max-w-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[640px] max-h-[92vh] border border-gray-100">
        
        {/* ========================================================================= */}
        {/* VIEW 1: ONLINE CUSTOMER SERVICES (Matches Screenshot 1 Exactly)           */}
        {/* ========================================================================= */}
        {currentView === 'channels' && (
          <div className="flex-1 flex flex-col overflow-y-auto bg-[#f8f9fb]">
            {/* Top Banner (Theme Blue Header) */}
            <div className="bg-gradient-to-b from-[#1877f2] to-[#166fe5] text-white p-5 pt-4 rounded-b-3xl shadow-md text-center relative">
              {/* Back Button */}
              <button
                onClick={onClose}
                className="absolute left-4 top-4 px-3 py-1 bg-white/20 hover:bg-white/30 text-white rounded-full text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>

              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-6">
                Online Customer Services
              </h2>
              <p className="text-xs sm:text-sm text-blue-100 font-medium mt-1">
                24/7 Support Available
              </p>
            </div>

            <div className="p-4 sm:p-6 space-y-4">
              {/* Announcement strip with accent border */}
              <div className="bg-white rounded-2xl p-3.5 sm:p-4 border-l-4 border-[#1877f2] shadow-xs text-xs sm:text-sm text-gray-700 font-medium leading-relaxed">
                Get instant support from our customer service team. We&apos;re here to help you 24/7.
              </div>

              {/* Main Channels Card */}
              <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-gray-100 text-center space-y-3.5">
                <h3 className="text-sm sm:text-base font-bold text-gray-900 mb-1">
                  Contact Us on Telegram
                </h3>

                {/* Button 1: Join Our Telegram Support */}
                <button
                  onClick={() => {
                    const telegramUrl = 'https://t.me/BossEcommSupport';
                    window.open(telegramUrl, '_blank') || alert('Connecting to official Telegram support channel: @BossEcommSupport');
                  }}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#0088cc] hover:bg-[#0077b3] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-[0.99] cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.828.946z" />
                  </svg>
                  <span>Join Our Telegram Support</span>
                </button>

                {/* Button 2: Contact Us WhatsApp Support */}
                <button
                  onClick={() => {
                    const whatsappUrl = 'https://wa.me/12025550193';
                    window.open(whatsappUrl, '_blank') || alert('Connecting to WhatsApp VIP Support line: +1 (202) 555-0193');
                  }}
                  className="w-full py-3.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-[0.99] cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
                  </svg>
                  <span>Contact Us WhatsApp Support</span>
                </button>

                {/* Button 3: LIVE SUPPORT CHAT (The Highlighted Feature from Screenshot 1!) */}
                <div className="pt-1">
                  <button
                    onClick={() => setCurrentView('chat')}
                    className="w-full py-4 px-4 rounded-xl bg-gradient-to-r from-[#1877f2] via-[#2563eb] to-[#1d4ed8] hover:from-[#166fe5] hover:to-[#1e40af] text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-lg shadow-blue-500/25 transition-all transform hover:scale-[1.01] active:scale-[0.98] border-2 border-blue-300/40 cursor-pointer group"
                  >
                    <div className="relative">
                      <MessageCircle className="w-5 h-5 fill-current" />
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-[#1877f2] animate-pulse"></span>
                    </div>
                    <span>Live Support Chat</span>
                  </button>
                  <p className="text-[11px] text-gray-500 font-medium mt-2">
                    Click above to connect with our support team instantly
                  </p>
                </div>
              </div>

              {/* Bottom 2 Feature Badges (Fast Response, 24/7 Support) */}
              <div className="grid grid-cols-2 gap-3">
                {/* Fast Response */}
                <div className="bg-white rounded-2xl p-4 shadow-xs border border-gray-100 flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-[#1877f2] flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-900">Fast Response</h4>
                    <p className="text-[10px] text-gray-500 mt-0.5">Typically replies within 5 minutes</p>
                  </div>
                </div>

                {/* 24/7 Support */}
                <div className="bg-white rounded-2xl p-4 shadow-xs border border-gray-100 flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-blue-50 text-[#1877f2] flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-900">24/7 Support</h4>
                    <p className="text-[10px] text-gray-500 mt-0.5">Available round the clock</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: CHAT SUPPORT (Matches Screenshot 2 Exactly)                       */}
        {/* ========================================================================= */}
        {currentView === 'chat' && (
          <div className="flex-1 flex flex-col h-full bg-[#f8f9fb]">
            {/* Chat Top Header */}
            <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shrink-0 shadow-xs">
              {/* Back Button */}
              <button
                onClick={() => setCurrentView('channels')}
                className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center text-gray-700 transition-colors cursor-pointer"
                title="Back to Customer Services"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              {/* Title & Status */}
              <div className="text-center">
                <h3 className="text-sm font-black text-gray-900 leading-tight">Chat Support</h3>
                <p className="text-[10px] text-gray-500">
                  {agentStatus === 'online' ? '24/7 Smart Live Support' : 'Support Desk (Manual Mode)'}
                </p>
                <div className="flex items-center justify-center gap-1.5 mt-0.5">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      agentStatus === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                    }`}
                  ></span>
                  <span
                    className={`text-[9px] font-bold uppercase tracking-wider ${
                      agentStatus === 'online' ? 'text-emerald-600' : 'text-amber-700'
                    }`}
                  >
                    {agentStatus === 'online' ? 'Online (Auto-Reply)' : 'Offline (Manual Only)'}
                  </span>
                </div>
              </div>

              {/* Status Selector (Syncs with Admin Backend) */}
              <div className="relative">
                <select
                  value={agentStatus}
                  onChange={(e) => handleSetMode(e.target.value as 'online' | 'offline')}
                  className="px-2.5 py-1 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg text-[11px] font-bold text-gray-700 focus:outline-none cursor-pointer"
                  title="Switch Live Chat Mode"
                >
                  <option value="online">🟢 Online</option>
                  <option value="offline">🔴 Offline</option>
                </select>
              </div>
            </div>

            {/* Conversation Scroll Container */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
              {/* Offline Mode Notice Banner */}
              {agentStatus === 'offline' && (
                <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-3 text-xs text-amber-900 flex items-start gap-2.5 shadow-2xs">
                  <span className="w-2 h-2 rounded-full bg-amber-500 mt-1 shrink-0"></span>
                  <div>
                    <p className="font-bold text-[11px]">Support Mode: Offline / Manual Queue</p>
                    <p className="text-[10px] text-amber-800/80 mt-0.5 leading-relaxed">
                      Automated replies are disabled. Send your questions or screenshots here — our team will reply to you manually from the admin dashboard.
                    </p>
                  </div>
                </div>
              )}
              {/* Empty State (Screenshot 2: Start a Conversation) */}
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-4 py-12 my-auto">
                  {/* Two Overlapping Chat Bubbles */}
                  <div className="relative mb-4 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-3xl bg-blue-50 flex items-center justify-center text-[#1877f2]/70 shadow-xs">
                      <MessageCircle className="w-9 h-9 fill-current" />
                    </div>
                    <div className="w-10 h-10 rounded-2xl bg-blue-100 text-[#1877f2] flex items-center justify-center shadow-xs -ml-4 -mt-6 border-2 border-white">
                      <MessageCircle className="w-5 h-5 fill-current" />
                    </div>
                  </div>

                  <h4 className="text-base font-extrabold text-gray-900 mb-1">
                    Start a Conversation
                  </h4>
                  <p className="text-xs text-gray-500 max-w-xs leading-relaxed mb-6">
                    Have a question or facing an issue?<br />
                    Our support team is here to help.
                  </p>

                  {/* Quick Starter Prompts */}
                  <div className="flex flex-wrap gap-2 justify-center max-w-sm">
                    {[
                      'How to deposit USDT?',
                      'Check withdrawal status',
                      'How do order tasks work?',
                      'VIP tier requirements',
                    ].map((prompt, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendMessage(prompt)}
                        className="px-3 py-1.5 bg-white hover:bg-blue-50 text-gray-700 hover:text-[#1877f2] border border-gray-200 hover:border-blue-300 rounded-full text-xs font-semibold shadow-2xs transition-all cursor-pointer"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <>
                  {messages.map((msg) => {
                    const isUser = msg.sender === 'user';
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                      >
                        <div className="flex items-end gap-2 max-w-[85%]">
                          {!isUser && (
                            <div className="w-7 h-7 rounded-full bg-[#1877f2] text-white flex items-center justify-center text-[10px] font-bold shrink-0 mb-1">
                              CS
                            </div>
                          )}

                          <div
                            className={`rounded-2xl px-3.5 py-2.5 text-xs shadow-2xs ${
                              isUser
                                ? 'bg-[#1877f2] text-white rounded-br-xs'
                                : 'bg-white text-gray-800 border border-gray-200/80 rounded-bl-xs'
                            }`}
                          >
                            {/* Image Attachment inside message */}
                            {msg.imageUrl && (
                              <div className="mb-2 rounded-xl overflow-hidden max-w-[220px] bg-black/5">
                                <img
                                  src={msg.imageUrl}
                                  alt="Attachment"
                                  className="w-full h-auto object-cover max-h-48 cursor-pointer hover:opacity-95 transition-opacity"
                                  onClick={() => setPreviewEnlargedImage(msg.imageUrl || null)}
                                />
                              </div>
                            )}

                            {/* Voice Audio Note */}
                            {msg.isAudio ? (
                              <div className="flex items-center gap-2.5 py-1 min-w-[150px]">
                                <button
                                  onClick={() =>
                                    setPlayingAudioId(playingAudioId === msg.id ? null : msg.id)
                                  }
                                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                                    isUser
                                      ? 'bg-white text-[#1877f2]'
                                      : 'bg-[#1877f2] text-white'
                                  }`}
                                >
                                  {playingAudioId === msg.id ? (
                                    <Pause className="w-3.5 h-3.5 fill-current" />
                                  ) : (
                                    <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                                  )}
                                </button>
                                <div className="flex-1">
                                  {/* Waveform Bars */}
                                  <div className="flex items-center gap-0.5 h-4">
                                    {[6, 12, 16, 10, 14, 8, 16, 12, 6, 14, 10, 4].map((h, i) => (
                                      <span
                                        key={i}
                                        style={{ height: `${h}px` }}
                                        className={`w-0.5 rounded-full ${
                                          isUser ? 'bg-white/80' : 'bg-[#1877f2]/70'
                                        } ${playingAudioId === msg.id ? 'animate-pulse' : ''}`}
                                      ></span>
                                    ))}
                                  </div>
                                  <span
                                    className={`text-[9px] font-mono mt-0.5 block ${
                                      isUser ? 'text-blue-100' : 'text-gray-400'
                                    }`}
                                  >
                                    {msg.audioDuration || '0:05'}
                                  </span>
                                </div>
                              </div>
                            ) : (
                              <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                            )}
                          </div>
                        </div>

                        {/* Timestamp & Status */}
                        <div className="flex items-center gap-1 mt-1 px-1">
                          <span className="text-[9px] text-gray-400 font-medium">{msg.time}</span>
                          {isUser && <CheckCheck className="w-3 h-3 text-[#1877f2]" />}
                        </div>
                      </div>
                    );
                  })}

                  {/* Typing Indicator */}
                  {isAgentTyping && (
                    <div className="flex items-end gap-2">
                      <div className="w-7 h-7 rounded-full bg-[#1877f2] text-white flex items-center justify-center text-[10px] font-bold shrink-0 mb-1">
                        CS
                      </div>
                      <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-xs px-3 py-2 flex items-center gap-1.5 shadow-2xs">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce"></span>
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:0.2s]"></span>
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce [animation-delay:0.4s]"></span>
                        <span className="text-[10px] text-gray-400 font-medium ml-1">Support typing...</span>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            {/* Image Upload Preview (if an image is staged for sending) */}
            {attachedImage && (
              <div className="px-4 py-2 bg-blue-50/70 border-t border-blue-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <img
                    src={attachedImage}
                    alt="Ready to attach"
                    className="w-10 h-10 rounded-lg object-cover border border-blue-200"
                  />
                  <div>
                    <p className="text-xs font-bold text-gray-800">Screenshot Attached</p>
                    <p className="text-[10px] text-gray-500">Ready to send</p>
                  </div>
                </div>
                <button
                  onClick={() => setAttachedImage(null)}
                  className="p-1 text-gray-400 hover:text-red-500 rounded-full"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Voice Recording Bar (if recording is active) */}
            {isRecording && (
              <div className="px-4 py-2.5 bg-red-50 border-t border-red-200 flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                  <span className="text-xs font-bold text-red-700">
                    Recording Audio... 0:{recordingSeconds.toString().padStart(2, '0')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsRecording(false)}
                    className="px-2 py-1 text-xs text-gray-600 hover:text-gray-900"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleToggleRecord}
                    className="px-3 py-1 bg-red-600 text-white rounded-lg text-xs font-bold shadow-xs hover:bg-red-700"
                  >
                    Send Audio
                  </button>
                </div>
              </div>
            )}

            {/* Bottom Input Bar (Matches Red Box in Screenshot 2) */}
            <div className="p-3 bg-white border-t border-gray-200 flex items-center gap-2 shrink-0">
              {/* Hidden File Input */}
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              {/* Attachment Icon (Paperclip) - Highlighted in Screenshot 2 */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-9 h-9 rounded-xl hover:bg-gray-100 flex items-center justify-center text-gray-500 hover:text-[#1877f2] transition-colors cursor-pointer shrink-0"
                title="Attach Screenshot or Receipt"
              >
                <Paperclip className="w-5 h-5" />
              </button>

              {/* Voice Note Icon (Mic) - Highlighted in Screenshot 2 */}
              <button
                onClick={handleToggleRecord}
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                  isRecording
                    ? 'bg-red-50 text-red-600'
                    : 'hover:bg-gray-100 text-gray-500 hover:text-[#1877f2]'
                }`}
                title="Record Voice Note"
              >
                <Mic className="w-5 h-5" />
              </button>

              {/* Message Input Field */}
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder="Type your message..."
                  className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-2xl text-xs sm:text-sm text-gray-900 placeholder-gray-400 focus:outline-hidden focus:bg-white focus:border-[#1877f2] transition-colors"
                />
              </div>

              {/* Send Button (Circular Blue Button with Paperplane) */}
              <button
                onClick={() => handleSendMessage()}
                disabled={!inputMessage.trim() && !attachedImage}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0 cursor-pointer shadow-xs ${
                  inputMessage.trim() || attachedImage
                    ? 'bg-[#1877f2] hover:bg-[#166fe5] text-white scale-100'
                    : 'bg-blue-300 text-white cursor-not-allowed opacity-75'
                }`}
                title="Send Message"
              >
                <Send className="w-4 h-4 fill-current ml-0.5" />
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Enlarged Image Preview Modal */}
      {previewEnlargedImage && (
        <div
          className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setPreviewEnlargedImage(null)}
        >
          <div className="relative max-w-xl max-h-[85vh] overflow-hidden rounded-2xl">
            <img
              src={previewEnlargedImage}
              alt="Enlarged"
              className="w-full h-auto object-contain max-h-[85vh]"
            />
            <button
              onClick={() => setPreviewEnlargedImage(null)}
              className="absolute top-3 right-3 w-8 h-8 bg-black/60 text-white rounded-full flex items-center justify-center"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
