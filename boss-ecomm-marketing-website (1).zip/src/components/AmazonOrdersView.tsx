import React, { useState, useEffect } from 'react';
import { ChevronLeft, CheckCircle2, Loader2, Sparkles, ShoppingBag } from 'lucide-react';
import { UserProfile, OrderItem } from '../types';

interface AmazonOrdersViewProps {
  user: UserProfile;
  currentProductIndex: number;
  productPool: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[];
  onBack: () => void;
  onSubmitOrder: (product: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>) => void;
}

export const AmazonOrdersView: React.FC<AmazonOrdersViewProps> = ({
  user,
  currentProductIndex,
  productPool,
  onBack,
  onSubmitOrder,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStep, setSubmissionStep] = useState<string>('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [lastEarnedCommission, setLastEarnedCommission] = useState(0);

  // Current active product
  const activeProduct = productPool[currentProductIndex % productPool.length];
  const [selectedThumb, setSelectedThumb] = useState<string>(activeProduct.image);

  useEffect(() => {
    setSelectedThumb(activeProduct.image);
  }, [activeProduct.image]);

  const handleSubmit = () => {
    if (user.completedOrders >= user.totalOrders) {
      alert('You have completed all 25 daily orders! Return tomorrow or upgrade your VIP level to grab more orders.');
      return;
    }

    setIsSubmitting(true);
    setSubmissionStep('Matching Amazon cloud merchant listing...');

    setTimeout(() => {
      setSubmissionStep('Securing merchant escrow & validating product...');
    }, 900);

    setTimeout(() => {
      setSubmissionStep('Submitting order & calculating 4% VIP commission...');
    }, 1800);

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmissionStep('');
      setLastEarnedCommission(activeProduct.commission);
      setShowSuccessToast(true);

      onSubmitOrder(activeProduct);

      setTimeout(() => {
        setShowSuccessToast(false);
      }, 3000);
    }, 2600);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Top Header Bar (Matches Screenshot 4) */}
      <div className="bg-[#1877f2] rounded-2xl p-4 text-white shadow-md flex items-center justify-between">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-1 bg-white/20 hover:bg-white/30 text-white px-3 py-1.5 rounded-full text-xs font-bold transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        {/* Center Title with Amazon Icon */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-1.5 font-black text-base sm:text-lg">
            <span className="bg-white text-gray-900 rounded-md px-1 py-0.5 text-xs font-black">
              a
            </span>
            <span>Amazon Orders</span>
          </div>
          <span className="text-[11px] text-blue-100 font-medium block">
            Complete orders and earn profits
          </span>
        </div>

        {/* Orders Counter Pill */}
        <div className="bg-white/20 text-white px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap">
          Orders: {user.completedOrders}/{user.totalOrders}
        </div>
      </div>

      {/* Row 1 Stats: 3 Cards (Matches Screenshot 4) */}
      <div className="grid grid-cols-3 gap-2.5 sm:gap-4">
        {/* Current Balance */}
        <div className="bg-[#f0f7ff] border border-blue-200/60 rounded-2xl p-3 sm:p-4 text-center shadow-xs">
          <span className="text-sm sm:text-lg font-black text-[#1877f2] block leading-tight">
            ${user.balance.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-600 font-medium mt-0.5 block">
            Current Balance
          </span>
        </div>

        {/* Orders Submitted */}
        <div className="bg-[#ebfbf3] border border-emerald-200/60 rounded-2xl p-3 sm:p-4 text-center shadow-xs">
          <span className="text-sm sm:text-lg font-black text-emerald-600 block leading-tight">
            {user.completedOrders}/{user.totalOrders}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-600 font-medium mt-0.5 block">
            Orders Submitted
          </span>
        </div>

        {/* Next Order Amount */}
        <div className="bg-[#f0f7ff] border border-blue-200/60 rounded-2xl p-3 sm:p-4 text-center shadow-xs">
          <span className="text-sm sm:text-lg font-black text-[#1877f2] block leading-tight">
            ${activeProduct.orderAmount.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-600 font-medium mt-0.5 block">
            Next Order Amount
          </span>
        </div>
      </div>

      {/* Row 2 Stats: 4 Cards (Matches Screenshot 4) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Amount */}
        <div className="bg-[#f0f7ff] border border-blue-200/60 rounded-2xl p-3 text-center shadow-xs">
          <span className="text-sm sm:text-base font-black text-[#1877f2] block leading-tight">
            ${activeProduct.orderAmount.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-500 font-medium mt-0.5 block">
            Amount
          </span>
        </div>

        {/* Commission */}
        <div className="bg-[#ebfbf3] border border-emerald-200/60 rounded-2xl p-3 text-center shadow-xs">
          <span className="text-sm sm:text-base font-black text-emerald-600 block leading-tight">
            +${activeProduct.commission.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-500 font-medium mt-0.5 block">
            Commission
          </span>
        </div>

        {/* Total Profit */}
        <div className="bg-[#fefde8] border border-yellow-200/60 rounded-2xl p-3 text-center shadow-xs">
          <span className="text-sm sm:text-base font-black text-amber-600 block leading-tight">
            ${user.totalProfit.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-500 font-medium mt-0.5 block">
            Total Profit
          </span>
        </div>

        {/* Your Balance */}
        <div className="bg-[#fefde8] border border-yellow-200/60 rounded-2xl p-3 text-center shadow-xs">
          <span className="text-sm sm:text-base font-black text-amber-600 block leading-tight">
            ${user.balance.toFixed(2)}
          </span>
          <span className="text-[10px] sm:text-xs text-gray-500 font-medium mt-0.5 block">
            Your Balance
          </span>
        </div>
      </div>

      {/* Main Product Card (Matches Screenshot 4) */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-xs border border-gray-100">
        <div className="flex flex-col sm:flex-row gap-5 items-start">
          {/* Product Image and Thumbnails */}
          <div className="w-full sm:w-44 flex-shrink-0 flex flex-col items-center">
            <div className="w-36 h-36 sm:w-40 sm:h-40 rounded-xl overflow-hidden border border-gray-200 bg-gray-50 flex items-center justify-center p-1">
              <img
                src={selectedThumb || activeProduct.image}
                alt={activeProduct.title}
                className="w-full h-full object-contain"
              />
            </div>

            {/* Thumbnails row */}
            {activeProduct.thumbnails && activeProduct.thumbnails.length > 0 && (
              <div className="flex items-center gap-1.5 mt-2 overflow-x-auto max-w-full pb-1">
                {activeProduct.thumbnails.map((thumb, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedThumb(thumb)}
                    className={`w-9 h-9 rounded-md border overflow-hidden p-0.5 transition-all ${
                      selectedThumb === thumb ? 'border-[#1877f2] ring-1 ring-[#1877f2]' : 'border-gray-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={thumb} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="flex-1 flex flex-col justify-between w-full">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-gray-900 leading-snug line-clamp-3 mb-2.5">
                {activeProduct.title}
              </h3>

              {/* Badges */}
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className="bg-blue-50 text-[#1877f2] border border-blue-200 text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full">
                  Order #{activeProduct.position || (currentProductIndex % productPool.length) + 1} of {productPool.length}
                </span>
                <span className="bg-blue-50 text-[#1877f2] border border-blue-200 text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full">
                  AMAZON
                </span>
                <span className="bg-gray-100 text-gray-700 text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full">
                  Single Order
                </span>
                {activeProduct.totalProfit && (
                  <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full">
                    Target Total Profit: ${activeProduct.totalProfit.toFixed(2)}
                  </span>
                )}
              </div>
            </div>

            {/* Order Amount and Commission summary pills */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-[#f8f9fa] rounded-xl p-3 text-center border border-gray-200">
                <span className="text-[11px] text-gray-500 font-medium block">Order Amount</span>
                <span className="text-base sm:text-lg font-black text-gray-900 mt-0.5 block">
                  ${activeProduct.orderAmount.toFixed(2)}
                </span>
              </div>

              <div className="bg-[#f8f9fa] rounded-xl p-3 text-center border border-gray-200">
                <span className="text-[11px] text-gray-500 font-medium block">Commission</span>
                <span className="text-base sm:text-lg font-black text-emerald-600 mt-0.5 block">
                  +${activeProduct.commission.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Big Action Button */}
            <button
              id="submit-order-button"
              disabled={isSubmitting || user.completedOrders >= user.totalOrders}
              onClick={handleSubmit}
              className={`w-full py-3.5 px-4 rounded-xl font-extrabold text-sm sm:text-base text-white shadow-md transition-all flex items-center justify-center gap-2 ${
                isSubmitting
                  ? 'bg-blue-400 cursor-wait'
                  : user.completedOrders >= user.totalOrders
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-[#1877f2] hover:bg-[#166fe5] active:scale-[0.99] cursor-pointer'
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{submissionStep}</span>
                </>
              ) : user.completedOrders >= user.totalOrders ? (
                <span>All 25 Orders Completed Today</span>
              ) : (
                <>
                  <span>Submit Order & Earn Profit</span>
                  <Sparkles className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Success Toast */}
      {showSuccessToast && (
        <div className="bg-emerald-600 text-white p-3.5 rounded-xl shadow-lg flex items-center justify-between animate-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <span>Order successfully submitted! +${lastEarnedCommission.toFixed(2)} credited to your balance.</span>
          </div>
        </div>
      )}

      {/* Task Guidelines & Rules Card */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs text-xs text-gray-600 space-y-1.5">
        <h4 className="font-bold text-gray-900 flex items-center gap-1.5">
          <ShoppingBag className="w-4 h-4 text-[#1877f2]" />
          Order Grabbing Guidelines:
        </h4>
        <p className="text-[11px] leading-relaxed text-gray-500">
          1. Orders are automatically allocated based on VIP level 1 (4% return per order).
        </p>
        <p className="text-[11px] leading-relaxed text-gray-500">
          2. The commission will be immediately credited to your account balance after each order submission.
        </p>
        <p className="text-[11px] leading-relaxed text-gray-500">
          3. Complete all 25 daily orders before 23:59 to receive your daily platform attendance salary bonus.
        </p>
      </div>
    </div>
  );
};
