import React, { useEffect, useState } from 'react';
import { Sparkles, ShoppingBag, X, ArrowRight, CheckCircle2, Bell } from 'lucide-react';
import { AppNotification } from '../types';

interface NotificationToastBannerProps {
  notification: AppNotification | null;
  onClose: () => void;
  onAction: (notification: AppNotification) => void;
}

export const NotificationToastBanner: React.FC<NotificationToastBannerProps> = ({
  notification,
  onClose,
  onAction,
}) => {
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    if (!notification) return;
    setProgress(100);

    const startTime = Date.now();
    const duration = 7000; // 7 seconds

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
        onClose();
      }
    }, 50);

    return () => clearInterval(interval);
  }, [notification, onClose]);

  if (!notification) return null;

  const isSalary = notification.type === 'salary_available';
  const isQuota = notification.type === 'quota_refreshed';

  return (
    <aside
      role="status"
      aria-live="polite"
      aria-label={notification.title}
      className="fixed top-14 sm:top-16 right-3 sm:right-6 z-[120] max-w-sm sm:max-w-md w-full animate-in slide-in-from-top-4 fade-in duration-300"
    >
      <div className="bg-slate-900/95 backdrop-blur-md text-white rounded-2xl p-4 shadow-2xl border border-slate-700/80 overflow-hidden relative group">
        {/* Top Accent Light Bar */}
        <div
          className={`absolute top-0 left-0 right-0 h-1 ${
            isSalary
              ? 'bg-gradient-to-r from-emerald-400 to-teal-400'
              : isQuota
              ? 'bg-gradient-to-r from-blue-400 to-indigo-400'
              : 'bg-gradient-to-r from-amber-400 to-orange-400'
          }`}
        />

        <div className="flex items-start gap-3.5 pt-1">
          {/* Icon Badge */}
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-md ${
              isSalary
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : isQuota
                ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
            }`}
          >
            {isSalary ? (
              <Sparkles className="w-5 h-5 animate-pulse" />
            ) : isQuota ? (
              <ShoppingBag className="w-5 h-5" />
            ) : (
              <Bell className="w-5 h-5" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 pr-2">
            <div className="flex items-center gap-2 mb-0.5">
              <span
                className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider ${
                  isSalary
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                }`}
              >
                {isSalary ? 'VIP Reward' : 'Daily Quota'}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">Just now</span>
            </div>

            <h4 className="text-sm font-bold text-white tracking-tight leading-snug">
              {notification.title}
            </h4>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed line-clamp-2">
              {notification.message}
            </p>

            {/* Quick Action Button */}
            <div className="mt-3 flex items-center gap-2">
              {notification.actionType === 'claim_salary' && (
                <button
                  type="button"
                  onClick={() => onAction(notification)}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-extrabold rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    Claim{' '}
                    {notification.metadata?.salaryAmount
                      ? `$${notification.metadata.salaryAmount}.00`
                      : 'Salary'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

              {notification.actionType === 'navigate_tasks' && (
                <button
                  type="button"
                  onClick={() => onAction(notification)}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-extrabold rounded-xl shadow-lg transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>Start Orders (25)</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>

          {/* Close X */}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close notification banner"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800/80 transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom Timeout Progress Line */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-slate-800">
          <div
            className={`h-full transition-all duration-75 ${
              isSalary ? 'bg-emerald-400' : 'bg-blue-400'
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </aside>
  );
};
