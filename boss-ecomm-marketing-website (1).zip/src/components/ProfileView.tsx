import React from 'react';
import {
  Gift,
  Coins,
  Wallet,
  CreditCard,
  DollarSign,
  ShoppingCart,
  LogOut,
  Camera,
  CheckCircle,
  Copy,
  Check,
  ArrowRight,
  ShieldCheck,
  Crown,
  Download,
  ExternalLink,
  X,
  FileArchive,
  Loader2,
} from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileViewProps {
  user: UserProfile;
  onOpenModal: (
    type: 'deposit' | 'withdraw' | 'about' | 'services' | 'invite' | 'withdrawal-account'
  ) => void;
  onLogout: () => void;
  onUpdateUser?: (updated: Partial<UserProfile>) => void;
}

// Green Wallet icon for Balance card matching new theme
function BalanceWalletIcon({ className = 'w-9 h-8 sm:w-10 sm:h-9' }: { className?: string }) {
  return (
    <div className={`relative shrink-0 flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 46 40" className="w-full h-full drop-shadow-xs">
        <rect x="10" y="3" width="23" height="13" rx="3" fill="#a7f3d0" />
        <circle cx="21.5" cy="9.5" r="3.2" fill="#34d399" />
        <rect x="4" y="9" width="38" height="27" rx="7" fill="#10b981" />
        <path d="M4 14.5 C 4 10.5 7.5 9 11 9 L 35 9 C 38.5 9 42 10.5 42 14.5 Z" fill="#059669" />
        <path d="M29 18 H 40 C 42 18 43 19.5 43 22.5 C 43 25.5 42 27 40 27 H 29 Z" fill="#059669" />
        <circle cx="34" cy="22.5" r="2.5" fill="#facc15" />
      </svg>
    </div>
  );
}

// 3D-styled Coins Icon
function DepositCoinsIcon() {
  return (
    <div className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center shrink-0">
      <svg viewBox="0 0 44 44" className="w-full h-full">
        <circle cx="16" cy="18" r="11" fill="#fef08a" />
        <circle cx="16" cy="18" r="8" fill="#eab308" />
        <text x="16" y="22" fontSize="11" fontWeight="bold" textAnchor="middle" fill="#713f12">
          $
        </text>
        <circle cx="27" cy="25" r="12" fill="#fef9c3" />
        <circle cx="27" cy="25" r="9" fill="#facc15" />
        <text x="27" y="30" fontSize="13" fontWeight="bold" textAnchor="middle" fill="#854d0e">
          $
        </text>
      </svg>
    </div>
  );
}

// 3D-styled Blue Wallet Icon
function WithdrawWalletIcon() {
  return (
    <div className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center shrink-0">
      <svg viewBox="0 0 44 44" className="w-full h-full">
        <rect x="5" y="10" width="34" height="25" rx="6" fill="#38bdf8" />
        <path d="M5 16 C 5 12 8 10 12 10 L 32 10 C 36 10 39 12 39 16 Z" fill="#0284c7" />
        <rect x="23" y="17" width="18" height="11" rx="4" fill="#ffffff" />
        <circle cx="28" cy="22.5" r="2.5" fill="#0284c7" />
        <path d="M12 6 L 24 6 C 26 6 27 7 27 8 L 9 8 C 9 7 10 6 12 6 Z" fill="#bae6fd" />
      </svg>
    </div>
  );
}

// 3D-styled Credit Card Icon
function AccountCardIcon() {
  return (
    <div className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center shrink-0">
      <svg viewBox="0 0 44 44" className="w-full h-full">
        <rect x="5" y="11" width="34" height="23" rx="5" fill="#c084fc" />
        <path d="M5 16 H 39 V 21 H 5 Z" fill="#7e22ce" />
        <rect x="9" y="26" width="9" height="4" rx="1.5" fill="#ffffff" />
        <circle cx="31" cy="28" r="3" fill="#f472b6" />
        <circle cx="27" cy="28" r="3" fill="#fb923c" opacity="0.8" />
      </svg>
    </div>
  );
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onOpenModal,
  onLogout,
  onUpdateUser,
}) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [profileToast, setProfileToast] = React.useState<string | null>(null);
  const [copiedCode, setCopiedCode] = React.useState(false);
  const [isDragOver, setIsDragOver] = React.useState(false);
  const [downloadModalOpen, setDownloadModalOpen] = React.useState(false);
  const [downloadCopied, setDownloadCopied] = React.useState(false);
  const [isDownloading, setIsDownloading] = React.useState(false);

  const getDirectDownloadUrl = () => {
    return `${window.location.origin}/website.zip`;
  };

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    setDownloadModalOpen(true);
    try {
      const res = await fetch('/website.zip');
      if (!res.ok) throw new Error('Fetch failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'boss-ecomm-marketing-website.zip';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }, 1000);
    } catch (e) {
      console.warn('Iframe download may require direct link opening', e);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyDownloadUrl = () => {
    navigator.clipboard.writeText(getDirectDownloadUrl());
    setDownloadCopied(true);
    setTimeout(() => setDownloadCopied(false), 2500);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file (PNG, JPG, JPEG, WEBP)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl && onUpdateUser) {
        onUpdateUser({ avatarUrl: dataUrl });
        setProfileToast('Profile photo updated successfully!');
        setTimeout(() => setProfileToast(null), 3000);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  return (
    <div className="space-y-4 sm:space-y-5 animate-in fade-in duration-300 relative">
      {/* Toast Notification */}
      {profileToast && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2 text-xs sm:text-sm font-bold animate-in fade-in slide-in-from-top-2">
          <CheckCircle className="w-4 h-4 shrink-0 text-white" />
          <span>{profileToast}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TOP USER CARD (NEW BOSS ECOMM MARKETING THEME)                          */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-[#02246b] via-[#0047ba] to-[#04338c] rounded-2xl sm:rounded-3xl p-4 sm:p-6 text-white shadow-md relative overflow-hidden">
        {/* Soft Background Wave Graphics */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-25">
          <svg className="w-full h-full" viewBox="0 0 1000 300" preserveAspectRatio="none">
            <path
              d="M0,100 C150,180 350,40 500,120 C650,200 850,50 1000,130 L1000,300 L0,300 Z"
              fill="#38bdf8"
            />
            <path
              d="M0,170 C200,80 400,220 600,140 C800,60 900,180 1000,160 L1000,300 L0,300 Z"
              fill="#0284c7"
            />
          </svg>
        </div>

        {/* Top Branding Bar */}
        <div className="relative z-10 flex items-center justify-between pb-3 sm:pb-4 mb-3 sm:mb-4 border-b border-white/15">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-normal text-white/90">Account Center</span>
            <span className="text-white/30">•</span>
            <span className="text-[10px] sm:text-xs font-semibold tracking-widest text-[#38bdf8] uppercase">
              Boss Ecomm Marketing
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
            </span>
            <span className="text-[11px] font-bold text-emerald-300">Active</span>
          </div>
        </div>

        {/* Main User Control Deck */}
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* User Info (Avatar + Details) */}
          <div className="flex items-center gap-3.5 sm:gap-4">
            {/* Clickable Profile Avatar with Cyan-to-Blue Ring */}
            <div
              className="relative group shrink-0"
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragOver(false);
                const file = e.dataTransfer.files?.[0];
                if (file && file.type.startsWith('image/')) {
                  const reader = new FileReader();
                  reader.onload = (event) => {
                    const dataUrl = event.target?.result as string;
                    if (dataUrl && onUpdateUser) {
                      onUpdateUser({ avatarUrl: dataUrl });
                      setProfileToast('Profile photo updated successfully!');
                      setTimeout(() => setProfileToast(null), 3000);
                    }
                  };
                  reader.readAsDataURL(file);
                }
              }}
            >
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
                id="profile-avatar-upload"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Click to upload profile photo"
                className={`w-14 h-14 sm:w-16 sm:h-16 rounded-full p-0.5 bg-gradient-to-tr from-cyan-400 to-blue-500 shadow-[0_0_15px_rgba(56,189,248,0.45)] flex items-center justify-center cursor-pointer transition-all hover:scale-105 focus:outline-none ${
                  isDragOver ? 'ring-4 ring-yellow-300' : ''
                }`}
              >
                <div className="w-full h-full rounded-full bg-[#002b80] overflow-hidden flex items-center justify-center font-black text-xl text-white relative">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.username}
                      className="w-full h-full object-cover rounded-full"
                    />
                  ) : (
                    <span>{user.avatarInitials || user.username.slice(0, 2).toUpperCase()}</span>
                  )}

                  {/* Dark Hover Overlay */}
                  <div className="absolute inset-0 bg-black/45 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-full">
                    <Camera className="w-4 h-4 text-white" />
                    <span className="text-[8px] font-bold text-white uppercase mt-0.5">Upload</span>
                  </div>
                </div>
              </button>

              {/* Little Camera Badge Button */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Upload photo"
                className="absolute -bottom-0.5 -right-0.5 w-5 h-5 bg-[#0084ff] border-2 border-[#001d54] text-white rounded-full flex items-center justify-center shadow-md hover:bg-[#0070db] transition-transform active:scale-95 cursor-pointer"
              >
                <Camera className="w-2.5 h-2.5" />
              </button>
            </div>

            {/* User details */}
            <div className="flex flex-col justify-center min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="inline-flex items-center gap-1 bg-cyan-400/20 text-cyan-300 border border-cyan-400/35 px-2 py-0.5 rounded-full text-[10px] sm:text-[11px] font-extrabold uppercase tracking-wide">
                  <Crown className="w-3 h-3 text-cyan-300" />
                  VIP 1 Verified Member
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white capitalize leading-tight">
                {user.username}
              </h2>

              {/* Referral Code with interactive copy button */}
              <div className="flex items-center gap-2 mt-1">
                <button
                  type="button"
                  onClick={handleCopyCode}
                  title="Click to copy invitation code"
                  className="inline-flex items-center gap-1.5 bg-[#021844]/80 hover:bg-[#032363] border border-blue-400/40 px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-white transition-all shadow-xs active:scale-95 cursor-pointer"
                >
                  <span>Code: {user.referralCode}</span>
                  {copiedCode ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3 text-blue-300 hover:text-white" />
                  )}
                </button>
                {copiedCode && (
                  <span className="text-[10px] text-emerald-300 font-bold animate-in fade-in">
                    Copied!
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Right: Total Amount / Balance Card (Deep teal container matching HomeView) */}
          <div className="flex items-center justify-between md:justify-end">
            <div className="bg-[#032e33] border border-[#0d6e6a]/90 rounded-xl sm:rounded-2xl px-4 py-2.5 sm:py-3 flex items-center gap-3 shadow-md w-full md:w-auto justify-between md:justify-start">
              <BalanceWalletIcon />
              <div className="flex flex-col text-left">
                <span className="text-[10px] font-bold text-teal-200/90 tracking-widest uppercase">
                  TOTAL AMOUNT
                </span>
                <span className="text-xl sm:text-2xl font-black text-white leading-tight">
                  ${user.balance.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Sub-deck: Credit Reputation */}
        <div className="relative z-10 pt-3.5 mt-3.5 border-t border-white/15 flex flex-wrap items-center justify-between gap-3 text-xs font-semibold">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-white/90">Credit Reputation:</span>
            <span className="font-extrabold text-emerald-300">{user.creditReputation}%</span>
            {/* Visual reputation progress bar */}
            <div className="hidden sm:block w-24 h-2 bg-white/20 rounded-full overflow-hidden ml-1">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-teal-300 rounded-full"
                style={{ width: `${Math.min(user.creditReputation, 100)}%` }}
              />
            </div>
          </div>

          <div className="text-[11px] text-blue-200/80 font-medium">
            Account Status: <span className="text-emerald-300 font-bold">Good Standing</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. 3 STATS CARDS (TODAY PROFIT, TOTAL BALANCE, ORDERS)                     */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4.5">
        {/* Stat 1: Today Profit */}
        <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-emerald-50/80 flex items-center gap-3.5 sm:gap-4 group transition-all duration-200">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#14e89c] to-[#05b875] shadow-[0_8px_18px_rgba(5,184,117,0.3)] flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-200">
            <DollarSign className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] sm:text-[11px] font-bold text-gray-500 tracking-wider uppercase">
              TODAY PROFIT
            </span>
            <span className="text-xl sm:text-2xl font-black text-[#0a1931] leading-tight">
              ${user.todayProfit.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Stat 2: Total Balance */}
        <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-blue-50/80 flex items-center gap-3.5 sm:gap-4 group transition-all duration-200">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#2575fc] to-[#0052cc] shadow-[0_8px_18px_rgba(0,82,204,0.3)] flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-200">
            <Wallet className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] sm:text-[11px] font-bold text-gray-500 tracking-wider uppercase">
              TOTAL BALANCE
            </span>
            <span className="text-xl sm:text-2xl font-black text-[#0a1931] leading-tight">
              ${user.balance.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Stat 3: Orders */}
        <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-purple-50/80 flex items-center gap-3.5 sm:gap-4 group transition-all duration-200">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#8b5cf6] to-[#6366f1] shadow-[0_8px_18px_rgba(99,102,241,0.3)] flex items-center justify-center text-white shrink-0 group-hover:scale-105 transition-transform duration-200">
            <ShoppingCart className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-[10px] sm:text-[11px] font-bold text-gray-500 tracking-wider uppercase">
              ORDERS
            </span>
            <span className="text-xl sm:text-2xl font-black text-[#0a1931] leading-tight">
              <span className="text-[#0062ff]">{user.completedOrders}</span>/{user.totalOrders}
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. INVITE FRIENDS BANNER (VIBRANT GRADIENT + REWARD CALLOUT)               */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-[#0052cc] via-[#1a73e8] to-[#0066ff] rounded-2xl sm:rounded-3xl p-5 sm:p-6 text-white shadow-[0_10px_28px_rgba(0,82,204,0.22)] relative overflow-hidden flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 group">
        {/* Soft Background Gift Watermark */}
        <div className="absolute -right-4 -bottom-6 opacity-15 pointer-events-none group-hover:scale-105 transition-transform duration-300">
          <Gift className="w-36 h-36 text-white" />
        </div>

        {/* Left: Gift Squircle + Texts */}
        <div className="flex items-center gap-3.5 sm:gap-4 relative z-10">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-white shadow-inner shrink-0 group-hover:rotate-6 transition-transform">
            <Gift className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.2]" />
          </div>
          <div className="flex flex-col">
            <h3 className="text-lg sm:text-xl font-extrabold leading-tight text-white">
              Invite Friends
            </h3>
            <p className="text-xs sm:text-sm text-blue-100 font-medium mt-0.5">
              Invite Friends to get Rewards &amp; Commissions
            </p>
          </div>
        </div>

        {/* Right: Invite Button */}
        <button
          type="button"
          onClick={() => onOpenModal('invite')}
          className="bg-white hover:bg-gray-50 text-[#0052cc] font-extrabold text-xs sm:text-sm px-5 sm:px-6 py-2.5 sm:py-3 rounded-full shadow-[0_4px_16px_rgba(0,0,0,0.12)] hover:shadow-lg transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 shrink-0 relative z-10"
        >
          <span>Invite Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 4. 3 ACTION CARDS (DEPOSIT, WITHDRAW, WITHDRAWAL ACCOUNT)                   */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4.5">
        {/* Deposit Card */}
        <div
          onClick={() => onOpenModal('deposit')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-emerald-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Green Squircle Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#14e89c] to-[#05b875] shadow-[0_8px_18px_rgba(5,184,117,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <DepositCoinsIcon />
            </div>

            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Deposit
              </h3>
              <div className="w-3.5 h-0.5 bg-[#05b875] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                Add funds to your account
              </p>
            </div>
          </div>

          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-50/80 text-emerald-600 group-hover:bg-[#05b875] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>

        {/* Withdraw Card */}
        <div
          onClick={() => onOpenModal('withdraw')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-blue-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Blue Squircle Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#2575fc] to-[#0052cc] shadow-[0_8px_18px_rgba(0,82,204,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <WithdrawWalletIcon />
            </div>

            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Withdraw
              </h3>
              <div className="w-3.5 h-0.5 bg-[#00d2ff] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                Get earnings to your wallet
              </p>
            </div>
          </div>

          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-blue-50/80 text-blue-600 group-hover:bg-[#0052cc] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>

        {/* Withdrawal Account Card */}
        <div
          onClick={() => onOpenModal('withdrawal-account')}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-[0_4px_20px_rgba(0,0,0,0.04)] hover:shadow-[0_8px_26px_rgba(0,0,0,0.07)] border border-purple-50/80 relative overflow-hidden flex items-center justify-between group transition-all duration-200 cursor-pointer active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
            {/* Purple Squircle Icon */}
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#8b5cf6] to-[#6366f1] shadow-[0_8px_18px_rgba(99,102,241,0.3)] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200">
              <AccountCardIcon />
            </div>

            <div className="flex flex-col min-w-0">
              <h3 className="text-lg sm:text-xl font-extrabold text-[#0a1b39] leading-tight">
                Withdrawal Account
              </h3>
              <div className="w-3.5 h-0.5 bg-[#8b5cf6] rounded-full my-1" />
              <p className="text-xs text-gray-500 font-medium leading-snug">
                Manage bank &amp; crypto info
              </p>
            </div>
          </div>

          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-purple-50/80 text-purple-600 group-hover:bg-[#6366f1] group-hover:text-white flex items-center justify-center transition-colors shrink-0 ml-2 shadow-xs">
            <ArrowRight className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 5. DOWNLOAD ZIP & LOG OUT BUTTONS                                         */}
      {/* ========================================================================= */}
      <div className="space-y-2.5 sm:space-y-3">
        <button
          type="button"
          onClick={handleDownloadZip}
          className="w-full py-3.5 sm:py-4 bg-gradient-to-r from-[#0052cc] via-[#1a73e8] to-[#0066ff] hover:opacity-95 text-white font-extrabold text-sm sm:text-base rounded-2xl transition-all shadow-md flex items-center justify-center gap-2.5 cursor-pointer active:scale-98 text-center"
        >
          {isDownloading ? (
            <Loader2 className="w-4 h-4 sm:w-5 sm:h-5 text-white animate-spin" />
          ) : (
            <Download className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
          )}
          <span>Download Website ZIP File</span>
        </button>

        <button
          type="button"
          onClick={onLogout}
          className="w-full py-3.5 sm:py-4 bg-[#062464] hover:bg-[#0a2e7c] text-white border border-blue-400/35 font-extrabold text-sm sm:text-base rounded-2xl transition-all shadow-md flex items-center justify-center gap-2.5 cursor-pointer active:scale-98"
        >
          <LogOut className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
          <span>Log Out</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* DOWNLOAD ZIP MODAL (Overcomes iframe sandbox download blocks)            */}
      {/* ========================================================================= */}
      {downloadModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-gray-100 relative">
            <button
              onClick={() => setDownloadModalOpen(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#0066ff] flex items-center justify-center shrink-0">
                <FileArchive className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#0f294a]">
                  Download Website ZIP
                </h3>
                <span className="text-xs text-gray-500 font-medium">
                  Complete project archive (~101 KB)
                </span>
              </div>
            </div>

            <div className="bg-blue-50/70 border border-blue-100 rounded-2xl p-3.5 mb-4 text-xs text-blue-900 space-y-1.5">
              <p className="font-bold">
                ⚠️ Note for AI Studio preview:
              </p>
              <p className="leading-relaxed text-blue-800">
                Browser iframe security blocks automatic file saves inside preview windows. Use the direct link below in your browser address bar:
              </p>
            </div>

            {/* Direct Link Box with Copy Button */}
            <div className="mb-4">
              <label className="block text-xs font-bold text-gray-600 mb-1.5 uppercase tracking-wide">
                Direct Download Link
              </label>
              <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl p-2 pl-3">
                <input
                  type="text"
                  readOnly
                  value={getDirectDownloadUrl()}
                  className="bg-transparent text-xs font-mono text-gray-700 flex-1 outline-none truncate select-all"
                />
                <button
                  onClick={handleCopyDownloadUrl}
                  className="bg-[#0066ff] hover:bg-blue-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
                >
                  {downloadCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Instructions list */}
            <div className="space-y-2 mb-5 text-xs text-gray-600 bg-gray-50/60 p-3 rounded-xl">
              <div className="flex items-center gap-2 font-medium">
                <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[10px]">1</span>
                <span>Click <strong>Copy</strong> above</span>
              </div>
              <div className="flex items-center gap-2 font-medium">
                <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[10px]">2</span>
                <span>Open a <strong>New Tab</strong> in your browser</span>
              </div>
              <div className="flex items-center gap-2 font-medium">
                <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[10px]">3</span>
                <span>Paste &amp; press Enter to download instantly</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-2">
              <a
                href="/website.zip"
                download="boss-ecomm-marketing-website.zip"
                className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl text-center shadow-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Retry Download</span>
              </a>
              <button
                type="button"
                onClick={() => setDownloadModalOpen(false)}
                className="py-2.5 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
