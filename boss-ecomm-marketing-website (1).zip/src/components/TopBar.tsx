import React, { useState } from 'react';
import { ShieldCheck, Sliders, Globe, RefreshCw, Smartphone, Eye, EyeOff, Bell } from 'lucide-react';
import { LanguageDropdown } from './LanguageDropdown';

interface TopBarProps {
  currentUrl: string;
  isAdmin: boolean;
  onToggleAdmin: () => void;
  onRefresh: () => void;
  onOpenLanguage: () => void;
  currentLanguage: string;
  onSelectLanguage?: (lang: string) => void;
  unreadNotificationCount?: number;
  onOpenNotifications?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentUrl,
  isAdmin,
  onToggleAdmin,
  onRefresh,
  onOpenLanguage,
  currentLanguage,
  onSelectLanguage,
  unreadNotificationCount = 0,
  onOpenNotifications,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);

  if (isMinimized && !isAdmin) {
    return (
      <div className="fixed top-2 right-2 z-50 flex items-center gap-1.5 opacity-80 hover:opacity-100 transition-opacity">
        {onOpenNotifications && (
          <button
            type="button"
            onClick={onOpenNotifications}
            title="Notifications"
            className="bg-white/90 hover:bg-white text-gray-700 p-1.5 rounded-full shadow-md border border-gray-200 text-xs flex items-center justify-center relative cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 text-gray-600" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white rounded-full text-[9px] font-black flex items-center justify-center animate-pulse">
                {unreadNotificationCount}
              </span>
            )}
          </button>
        )}
        <button
          onClick={() => setIsMinimized(false)}
          title="Show URL Simulator"
          className="bg-white/90 hover:bg-white text-gray-700 p-1.5 rounded-full shadow-md border border-gray-200 text-xs flex items-center gap-1 cursor-pointer"
        >
          <Eye className="w-3.5 h-3.5 text-gray-500" />
        </button>
        <button
          onClick={onToggleAdmin}
          className="bg-slate-900 hover:bg-slate-800 text-white px-2.5 py-1 rounded-full text-xs font-bold shadow-md flex items-center gap-1 cursor-pointer"
        >
          <Sliders className="w-3 h-3" />
          <span>Admin</span>
        </button>
      </div>
    );
  }

  return (
    <header className="sticky top-0 z-50 bg-[#f1f3f4] border-b border-gray-300 px-3 py-1.5 shadow-xs">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 text-xs">
        {/* URL Simulation pill */}
        <div className="flex-1 flex items-center bg-white rounded-full px-3 py-1 border border-gray-300 text-gray-700 shadow-inner overflow-hidden">
          <div className="flex items-center gap-1.5 text-gray-500 mr-2 flex-shrink-0">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span className="text-[11px] text-gray-400 font-mono">https://</span>
          </div>
          <span className="font-medium truncate text-gray-800 text-[12px]">
            {isAdmin ? 'boostmarketingwithus.com/admin-dashboard.html' : currentUrl}
          </span>
          <button
            onClick={onRefresh}
            title="Refresh page"
            className="ml-auto text-gray-400 hover:text-gray-700 p-0.5 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
          </button>
        </div>

        {/* Notifications Bell */}
        {!isAdmin && onOpenNotifications && (
          <button
            type="button"
            onClick={onOpenNotifications}
            title="Notifications (Daily Quota & VIP Salary)"
            className="relative p-1.5 rounded-full bg-white hover:bg-gray-100 border border-gray-300 text-gray-700 shadow-2xs transition-colors cursor-pointer shrink-0"
          >
            <Bell className="w-3.5 h-3.5 text-gray-700" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-1 bg-red-500 text-white rounded-full text-[9px] font-black flex items-center justify-center shadow-xs">
                {unreadNotificationCount}
              </span>
            )}
          </button>
        )}

        {/* Language Quick Dropdown */}
        {!isAdmin && (
          <div className="hidden sm:block">
            <LanguageDropdown
              currentLanguage={currentLanguage}
              onSelectLanguage={onSelectLanguage}
              buttonClassName="!py-1 !px-2.5 !text-[11px] !rounded-full border-gray-300"
            />
          </div>
        )}

        {/* Hide Bar button */}
        {!isAdmin && (
          <button
            onClick={() => setIsMinimized(true)}
            title="Hide URL bar"
            className="text-gray-500 hover:text-gray-800 p-1 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <EyeOff className="w-3.5 h-3.5" />
          </button>
        )}

        {/* Backend Admin switch */}
        <button
          onClick={onToggleAdmin}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold transition-all shadow-xs cursor-pointer ${
            isAdmin
              ? 'bg-slate-900 text-white hover:bg-slate-800'
              : 'bg-[#1877f2] text-white hover:bg-[#166fe5]'
          }`}
        >
          {isAdmin ? (
            <>
              <Smartphone className="w-3.5 h-3.5" />
              <span>User App</span>
            </>
          ) : (
            <>
              <Sliders className="w-3.5 h-3.5" />
              <span>Backend Admin</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
