import React, { useState, useRef, useEffect } from 'react';
import { Globe, ChevronDown } from 'lucide-react';
import { DROPDOWN_LANGUAGES, DropdownLanguage } from '../languages';

interface LanguageDropdownProps {
  currentLanguage?: string;
  onSelectLanguage?: (languageName: string, langObj?: DropdownLanguage) => void;
  align?: 'left' | 'right';
  className?: string;
  buttonClassName?: string;
  showToastFeedback?: boolean;
}

// Crisp rectangular flag matching reference screenshots
const FlagIcon: React.FC<{ countryCode: string; flagEmoji: string; alt: string }> = ({
  countryCode,
  flagEmoji,
  alt,
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return <span className="text-base leading-none shrink-0 select-none">{flagEmoji}</span>;
  }

  return (
    <img
      src={`https://flagcdn.com/w40/${countryCode.toLowerCase()}.png`}
      srcSet={`https://flagcdn.com/w80/${countryCode.toLowerCase()}.png 2x`}
      alt={alt}
      onError={() => setHasError(true)}
      className="w-5 h-3.5 object-cover rounded-[2px] shadow-2xs border border-black/10 shrink-0 select-none"
      loading="lazy"
    />
  );
};

export const LanguageDropdown: React.FC<LanguageDropdownProps> = ({
  currentLanguage = 'English',
  onSelectLanguage,
  align = 'right',
  className = '',
  buttonClassName = '',
  showToastFeedback = true,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeLang, setActiveLang] = useState<string>(() => {
    try {
      return localStorage.getItem('bam_selected_language') || currentLanguage || 'English';
    } catch (e) {
      return currentLanguage || 'English';
    }
  });
  const [toastText, setToastText] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Sync when prop changes
  useEffect(() => {
    if (currentLanguage && currentLanguage !== activeLang) {
      setActiveLang(currentLanguage);
    }
  }, [currentLanguage]);

  // Sync with cross-component events
  useEffect(() => {
    const handleLangSync = (e: any) => {
      try {
        const saved = localStorage.getItem('bam_selected_language');
        if (saved && saved !== activeLang) {
          setActiveLang(saved);
        }
      } catch (err) {}
    };

    window.addEventListener('bam_language_changed', handleLangSync);
    window.addEventListener('storage', handleLangSync);
    return () => {
      window.removeEventListener('bam_language_changed', handleLangSync);
      window.removeEventListener('storage', handleLangSync);
    };
  }, [activeLang]);

  // Close when clicking outside or pressing Escape
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelect = (lang: DropdownLanguage) => {
    setActiveLang(lang.name);
    try {
      localStorage.setItem('bam_selected_language', lang.name);
      localStorage.setItem('bam_selected_language_code', lang.id);
      window.dispatchEvent(
        new CustomEvent('bam_language_changed', {
          detail: { name: lang.name, langObj: lang },
        })
      );
    } catch (e) {
      console.warn('Storage error on language change:', e);
    }

    if (onSelectLanguage) {
      onSelectLanguage(lang.name, lang);
    }

    if (showToastFeedback) {
      setToastText(`Language set to ${lang.name}`);
      setTimeout(() => setToastText(null), 2400);
    }

    setIsOpen(false);
  };

  const isSelected = (lang: DropdownLanguage) => {
    const cur = activeLang.toLowerCase().trim();
    return (
      cur === lang.name.toLowerCase() ||
      cur === lang.englishLabel.toLowerCase() ||
      cur === lang.id.toLowerCase()
    );
  };

  return (
    <div ref={containerRef} className={`relative z-30 inline-block text-left ${className}`}>
      {/* Trigger Button - Exactly matching Screenshots (Globe + "Languages" + Down Chevron) */}
      <button
        type="button"
        id="language-dropdown-button"
        aria-haspopup="true"
        aria-expanded={isOpen}
        onClick={() => setIsOpen(!isOpen)}
        className={`bg-white hover:bg-gray-50 text-gray-800 shadow-[0_2px_8px_rgba(0,0,0,0.08)] px-3 py-1.5 sm:px-3.5 sm:py-1.5 rounded-xl sm:rounded-2xl flex items-center gap-2 font-semibold text-xs sm:text-sm border border-gray-100 transition-all active:scale-95 cursor-pointer shrink-0 ${buttonClassName}`}
      >
        <Globe className="w-4 h-4 text-[#1877f2] shrink-0" />
        <span className="text-gray-900 font-semibold tracking-tight">Languages</span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-gray-500 shrink-0 transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-[#1877f2]' : ''
          }`}
        />
      </button>

      {/* Dropdown Floating Menu - Exactly matching Screenshots 1, 2, 3 */}
      {isOpen && (
        <div
          id="language-dropdown-menu"
          className={`absolute ${
            align === 'right' ? 'right-0' : 'left-0'
          } top-full mt-1.5 z-[100] w-44 sm:w-48 bg-white rounded-2xl shadow-[0_12px_36px_rgba(0,0,0,0.16)] border border-gray-100 overflow-hidden animate-in fade-in zoom-in-95 duration-150`}
        >
          <div
            className="dropdown-scroll max-h-[340px] sm:max-h-[380px] overflow-y-auto py-1 px-1 divide-y-0"
          >
            {DROPDOWN_LANGUAGES.map((lang) => {
              const selected = isSelected(lang);

              return (
                <button
                  key={lang.id}
                  type="button"
                  onClick={() => handleSelect(lang)}
                  className={`w-full text-left flex items-center gap-3 px-3 py-2 my-0.5 rounded-lg text-xs transition-colors cursor-pointer select-none ${
                    selected
                      ? 'bg-[#f0f7ff] text-[#1877f2] font-bold'
                      : 'text-gray-800 hover:bg-gray-50 font-medium'
                  }`}
                >
                  <FlagIcon countryCode={lang.countryCode} flagEmoji={lang.flagEmoji} alt={lang.name} />
                  <span
                    className={`truncate text-[12px] sm:text-[13px] ${
                      lang.isRtl ? 'font-medium font-sans' : ''
                    }`}
                  >
                    {lang.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating Toast notification upon language change */}
      {toastText && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 backdrop-blur-md text-white px-4 py-2 rounded-full text-xs font-bold shadow-xl border border-white/10 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200 pointer-events-none">
          <Globe className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span>{toastText}</span>
        </div>
      )}
    </div>
  );
};
