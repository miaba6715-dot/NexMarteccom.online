import { AppNotification, NotificationSettings } from '../types';

const STORAGE_KEY_NOTIFS = 'bam_notifications';
const STORAGE_KEY_SETTINGS = 'bam_notif_settings';
const STORAGE_KEY_SALARY_PREFIX = 'bam_salary_claimed_';
const STORAGE_KEY_QUOTA_PREFIX = 'bam_quota_refreshed_';

export const DEFAULT_SETTINGS: NotificationSettings = {
  browserEnabled: false,
  soundEnabled: true,
  inAppBannerEnabled: true,
};

export function getTodayKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function playNotificationSound(): void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // Tone 1: Gentle chime
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.35);

    // Tone 2: Higher bell harmonic
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880.0, now + 0.12); // A5
    gain2.gain.setValueAtTime(0.18, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.65);
  } catch (e) {
    // Gracefully ignore audio context restrictions if blocked by browser policy
  }
}

export async function requestBrowserPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (e) {
    return 'denied';
  }
}

export function showBrowserNotification(title: string, body: string, icon = '/favicon.ico'): void {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return;
  }
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon,
        tag: 'bam-notif-' + Date.now(),
      });
    } catch (e) {
      console.debug('Browser notification blocked in iframe context');
    }
  }
}

export function getStoredNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_NOTIFS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
}

export function saveStoredNotifications(notifs: AppNotification[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_NOTIFS, JSON.stringify(notifs.slice(0, 50)));
  } catch (e) {}
}

export function getNotificationSettings(): NotificationSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_SETTINGS, ...parsed };
    }
  } catch (e) {}
  return DEFAULT_SETTINGS;
}

export function saveNotificationSettings(settings: NotificationSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (e) {}
}

export function isSalaryClaimedToday(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY_SALARY_PREFIX + getTodayKey()) === 'true';
  } catch (e) {
    return false;
  }
}

export function markSalaryClaimedToday(): void {
  try {
    localStorage.setItem(STORAGE_KEY_SALARY_PREFIX + getTodayKey(), 'true');
    window.dispatchEvent(new CustomEvent('bam_salary_claimed_updated'));
  } catch (e) {}
}

export function resetSalaryClaimForToday(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_SALARY_PREFIX + getTodayKey());
    window.dispatchEvent(new CustomEvent('bam_salary_claimed_updated'));
  } catch (e) {}
}

export function isQuotaRefreshedToday(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY_QUOTA_PREFIX + getTodayKey()) === 'true';
  } catch (e) {
    return false;
  }
}

export function markQuotaRefreshedToday(): void {
  try {
    localStorage.setItem(STORAGE_KEY_QUOTA_PREFIX + getTodayKey(), 'true');
  } catch (e) {}
}
