export interface UserProfile {
  username: string;
  referralCode: string;
  balance: number;
  creditReputation: number;
  todayProfit: number;
  totalProfit: number;
  completedOrders: number;
  totalOrders: number;
  currentVipLevel: number;
  withdrawalAddress: string;
  phoneOrEmail: string;
  avatarInitials: string;
  avatarUrl?: string;
}

export interface OrderItem {
  id: string;
  title: string;
  image: string;
  thumbnails: string[];
  platform: 'AMAZON' | 'SHOPIFY' | 'WALMART' | 'ALIBABA' | 'ALIEXPRESS';
  orderAmount: number;
  commissionRate: number;
  commission: number;
  status: 'Completed' | 'Pending' | 'Frozen';
  timestamp: string;
  orderNumber: string;
  position?: number;
  totalProfit?: number;
  type?: 'single' | 'combine';
}

export interface VipPlan {
  level: number;
  name: string;
  platform: 'AMAZON' | 'SHOPIFY' | 'WALMART' | 'ALIBABA' | 'ALIEXPRESS';
  platformName: string;
  profitRate: number;
  minBalance: number;
  description: string;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw' | 'commission' | 'salary';
  amount: number;
  status: 'Approved' | 'Pending' | 'Rejected';
  timestamp: string;
  method?: string;
  account?: string;
  txHash?: string;
}

export interface AdminWithdrawalRecord {
  id: number;
  username: string;
  vipPlan?: string;
  tasks: string;
  amount: number;
  walletAddress: string;
  status: 'Approved' | 'Rejected' | 'Pending';
  date: string;
  userCode?: string;
}

export interface AdminDepositRecord {
  id: number;
  username: string;
  amount: number;
  status: 'Approved' | 'Rejected' | 'Pending';
  date: string;
  userCode?: string;
}

export interface AdminRecoveryRequest {
  id: number;
  userCode: string;
  issueDescription: string;
  matchedUsername: string;
  status: 'Pending' | 'Resolved';
  submittedAt: string;
}

export interface AdminChatMessage {
  id: string;
  sender: 'user' | 'admin';
  text: string;
  time: string;
  imageUrl?: string;
  isAudio?: boolean;
  audioDuration?: string;
}

export interface AdminConversation {
  id: string;
  username: string;
  userCode: string;
  lastMessage: string;
  time: string;
  unreadCount?: number;
  messages: AdminChatMessage[];
}

export type ActiveTab = 'home' | 'history' | 'order' | 'salary' | 'profile';
export type SubView = 'main' | 'amazon-orders' | 'deposit' | 'withdraw' | 'about' | 'services' | 'live-chat' | 'invite' | 'withdrawal-account';
export type AdminSidebarItem =
  | 'dashboard'
  | 'withdrawals'
  | 'deposits'
  | 'update-balance'
  | 'user-finder'
  | 'csv-upload'
  | 'single-order'
  | 'combine-orders'
  | 'credentials'
  | 'support-teams'
  | 'chat-support';

export interface AppNotification {
  id: string;
  type: 'quota_refreshed' | 'salary_available' | 'system';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionType?: 'navigate_tasks' | 'claim_salary';
  metadata?: {
    salaryAmount?: number;
    vipLevel?: number;
    quotaTotal?: number;
  };
}

export interface NotificationSettings {
  browserEnabled: boolean;
  soundEnabled: boolean;
  inAppBannerEnabled: boolean;
}
