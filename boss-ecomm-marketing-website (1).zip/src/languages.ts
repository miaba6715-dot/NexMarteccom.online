export interface NationalLanguage {
  code: string;
  label: string;
  native: string;
  country: string;
  flag: string;
}

export const NATIONAL_LANGUAGES: NationalLanguage[] = [
  // Major International & North America
  { code: 'en-US', label: 'English (US)', native: 'English', country: 'United States', flag: '🇺🇸' },
  { code: 'en-GB', label: 'English (UK)', native: 'English', country: 'United Kingdom', flag: '🇬🇧' },
  { code: 'en-CA', label: 'English (Canada)', native: 'English', country: 'Canada', flag: '🇨🇦' },
  { code: 'en-AU', label: 'English (Australia)', native: 'English', country: 'Australia', flag: '🇦🇺' },
  { code: 'es', label: 'Español', native: 'Español', country: 'Spain, Mexico, Latin America', flag: '🇪🇸' },
  { code: 'fr', label: 'Français', native: 'Français', country: 'France, Canada, Belgium', flag: '🇫🇷' },
  { code: 'de', label: 'Deutsch', native: 'Deutsch', country: 'Germany, Austria, Switzerland', flag: '🇩🇪' },
  { code: 'it', label: 'Italiano', native: 'Italiano', country: 'Italy, Switzerland', flag: '🇮🇹' },
  { code: 'pt-BR', label: 'Português (Brasil)', native: 'Português', country: 'Brazil', flag: '🇧🇷' },
  { code: 'pt-PT', label: 'Português (Portugal)', native: 'Português', country: 'Portugal', flag: '🇵🇹' },
  { code: 'ru', label: 'Русский', native: 'Русский', country: 'Russia, Belarus, Kazakhstan', flag: '🇷🇺' },

  // Asia & Pacific
  { code: 'zh-CN', label: '中文 (简体)', native: '简体中文', country: 'China, Singapore', flag: '🇨🇳' },
  { code: 'zh-TW', label: '中文 (繁體)', native: '繁體中文', country: 'Taiwan, Hong Kong', flag: '🇹🇼' },
  { code: 'ja', label: '日本語', native: '日本語', country: 'Japan', flag: '🇯🇵' },
  { code: 'ko', label: '한국어', native: '한국어', country: 'South Korea', flag: '🇰🇷' },
  { code: 'hi', label: 'हिन्दी', native: 'हिन्दी', country: 'India', flag: '🇮🇳' },
  { code: 'ur', label: 'اردو', native: 'اردو', country: 'Pakistan', flag: '🇵🇰' },
  { code: 'bn', label: 'বাংলা', native: 'বাংলা', country: 'Bangladesh, India', flag: '🇧🇩' },
  { code: 'pa', label: 'ਪੰਜਾਬੀ', native: 'ਪੰਜਾਬੀ', country: 'Pakistan, India', flag: '🇵🇰' },
  { code: 'ta', label: 'தமிழ்', native: 'தமிழ்', country: 'India, Sri Lanka, Singapore', flag: '🇮🇳' },
  { code: 'te', label: 'తెలుగు', native: 'తెలుగు', country: 'India', flag: '🇮🇳' },
  { code: 'mr', label: 'मराठी', native: 'मराठी', country: 'India', flag: '🇮🇳' },
  { code: 'gu', label: 'ગુજરાતી', native: 'ગુજરાતી', country: 'India', flag: '🇮🇳' },
  { code: 'ml', label: 'മലയാളം', native: 'മലയാളം', country: 'India', flag: '🇮🇳' },
  { code: 'kn', label: 'ಕನ್ನಡ', native: 'ಕನ್ನಡ', country: 'India', flag: '🇮🇳' },
  { code: 'id', label: 'Bahasa Indonesia', native: 'Indonesia', country: 'Indonesia', flag: '🇮🇩' },
  { code: 'ms', label: 'Bahasa Melayu', native: 'Melayu', country: 'Malaysia, Brunei', flag: '🇲🇾' },
  { code: 'fil', label: 'Filipino (Tagalog)', native: 'Filipino', country: 'Philippines', flag: '🇵🇭' },
  { code: 'vi', label: 'Tiếng Việt', native: 'Tiếng Việt', country: 'Vietnam', flag: '🇻🇳' },
  { code: 'th', label: 'ภาษาไทย', native: 'ไทย', country: 'Thailand', flag: '🇹🇭' },
  { code: 'my', label: 'မြန်မာဘာသာ', native: 'မြန်မာ', country: 'Myanmar', flag: '🇲🇲' },
  { code: 'km', label: 'ភាសាខ្មែរ', native: 'ខ្មែរ', country: 'Cambodia', flag: '🇰🇭' },
  { code: 'lo', label: 'ພາສາລາວ', native: 'ລາວ', country: 'Laos', flag: '🇱🇦' },
  { code: 'si', label: 'සිංහල', native: 'සිංහල', country: 'Sri Lanka', flag: '🇱🇰' },
  { code: 'ne', label: 'नेपाली', native: 'नेपाली', country: 'Nepal', flag: '🇳🇵' },
  { code: 'mn', label: 'Монгол хэл', native: 'Монгол', country: 'Mongolia', flag: '🇲🇳' },
  { code: 'uz', label: "O'zbekcha", native: "O'zbek", country: 'Uzbekistan', flag: '🇺🇿' },
  { code: 'kk', label: 'Қазақ тілі', native: 'Қазақша', country: 'Kazakhstan', flag: '🇰🇿' },
  { code: 'az', label: 'Azərbaycan dili', native: 'Azərbaycanca', country: 'Azerbaijan', flag: '🇦🇿' },
  { code: 'ka', label: 'ქართული', native: 'ქართული', country: 'Georgia', flag: '🇬🇪' },
  { code: 'hy', label: 'Հայերեն', native: 'Հայերեն', country: 'Armenia', flag: '🇦🇲' },

  // Middle East & North Africa
  { code: 'ar-SA', label: 'العربية (السعودية)', native: 'العربية', country: 'Saudi Arabia', flag: '🇸🇦' },
  { code: 'ar-AE', label: 'العربية (الإمارات)', native: 'العربية', country: 'United Arab Emirates', flag: '🇦🇪' },
  { code: 'ar-EG', label: 'العربية (مصر)', native: 'العربية', country: 'Egypt', flag: '🇪🇬' },
  { code: 'ar-QA', label: 'العربية (قطر)', native: 'العربية', country: 'Qatar', flag: '🇶🇦' },
  { code: 'ar-KW', label: 'العربية (الكويت)', native: 'العربية', country: 'Kuwait', flag: '🇰🇼' },
  { code: 'ar-OM', label: 'العربية (عمان)', native: 'العربية', country: 'Oman', flag: '🇴🇲' },
  { code: 'ar-MA', label: 'العربية (المغرب)', native: 'العربية', country: 'Morocco', flag: '🇲🇦' },
  { code: 'ar-DZ', label: 'العربية (الجزائر)', native: 'العربية', country: 'Algeria', flag: '🇩🇿' },
  { code: 'ar-IQ', label: 'العربية (العراق)', native: 'العربية', country: 'Iraq', flag: '🇮🇶' },
  { code: 'tr', label: 'Türkçe', native: 'Türkçe', country: 'Turkey', flag: '🇹🇷' },
  { code: 'fa', label: 'فارسی', native: 'فارسی', country: 'Iran', flag: '🇮🇷' },
  { code: 'ps', label: 'پښتو', native: 'پښتو', country: 'Afghanistan', flag: '🇦🇫' },
  { code: 'he', label: 'עברית', native: 'עברית', country: 'Israel', flag: '🇮🇱' },
  { code: 'ku', label: 'Kurdî', native: 'کوردی', country: 'Kurdistan, Iraq', flag: '🇮🇶' },

  // Europe
  { code: 'nl', label: 'Nederlands', native: 'Nederlands', country: 'Netherlands, Belgium', flag: '🇳🇱' },
  { code: 'pl', label: 'Polski', native: 'Polski', country: 'Poland', flag: '🇵🇱' },
  { code: 'uk', label: 'Українська', native: 'Українська', country: 'Ukraine', flag: '🇺🇦' },
  { code: 'ro', label: 'Română', native: 'Română', country: 'Romania, Moldova', flag: '🇷🇴' },
  { code: 'cs', label: 'Čeština', native: 'Čeština', country: 'Czech Republic', flag: '🇨🇿' },
  { code: 'el', label: 'Ελληνικά', native: 'Ελληνικά', country: 'Greece, Cyprus', flag: '🇬🇷' },
  { code: 'hu', label: 'Magyar', native: 'Magyar', country: 'Hungary', flag: '🇭🇺' },
  { code: 'sv', label: 'Svenska', native: 'Svenska', country: 'Sweden, Finland', flag: '🇸🇪' },
  { code: 'no', label: 'Norsk', native: 'Norsk', country: 'Norway', flag: '🇳🇴' },
  { code: 'da', label: 'Dansk', native: 'Dansk', country: 'Denmark', flag: '🇩🇰' },
  { code: 'fi', label: 'Suomi', native: 'Suomi', country: 'Finland', flag: '🇫🇮' },
  { code: 'sk', label: 'Slovenčina', native: 'Slovenčina', country: 'Slovakia', flag: '🇸🇰' },
  { code: 'bg', label: 'Български', native: 'Български', country: 'Bulgaria', flag: '🇧🇬' },
  { code: 'hr', label: 'Hrvatski', native: 'Hrvatski', country: 'Croatia', flag: '🇭🇷' },
  { code: 'sr', label: 'Српски', native: 'Srpski', country: 'Serbia', flag: '🇷🇸' },
  { code: 'bs', label: 'Bosanski', native: 'Bosanski', country: 'Bosnia and Herzegovina', flag: '🇧🇦' },
  { code: 'sq', label: 'Shqip', native: 'Shqip', country: 'Albania, Kosovo', flag: '🇦🇱' },
  { code: 'lt', label: 'Lietuvių', native: 'Lietuvių', country: 'Lithuania', flag: '🇱🇹' },
  { code: 'lv', label: 'Latviešu', native: 'Latviešu', country: 'Latvia', flag: '🇱🇻' },
  { code: 'et', label: 'Eesti', native: 'Eesti', country: 'Estonia', flag: '🇪🇪' },
  { code: 'sl', label: 'Slovenščina', native: 'Slovenski', country: 'Slovenia', flag: '🇸🇮' },
  { code: 'mk', label: 'Македонски', native: 'Македонски', country: 'North Macedonia', flag: '🇲🇰' },
  { code: 'be', label: 'Беларуская', native: 'Беларуская', country: 'Belarus', flag: '🇧🇾' },
  { code: 'is', label: 'Íslenska', native: 'Íslenska', country: 'Iceland', flag: '🇮🇸' },
  { code: 'ga', label: 'Gaeilge', native: 'Gaeilge', country: 'Ireland', flag: '🇮🇪' },
  { code: 'cy', label: 'Cymraeg', native: 'Cymraeg', country: 'Wales', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿' },
  { code: 'mt', label: 'Malti', native: 'Malti', country: 'Malta', flag: '🇲🇹' },
  { code: 'ca', label: 'Català', native: 'Català', country: 'Catalonia, Spain, Andorra', flag: '🇦🇩' },
  { code: 'eu', label: 'Euskara', native: 'Euskara', country: 'Basque Country, Spain', flag: '🇪🇸' },

  // Africa
  { code: 'sw', label: 'Kiswahili', native: 'Swahili', country: 'Kenya, Tanzania, Uganda', flag: '🇰🇪' },
  { code: 'ha', label: 'Hausa', native: 'هَوُسَ', country: 'Nigeria, Niger', flag: '🇳🇬' },
  { code: 'yo', label: 'Yorùbá', native: 'Yorùbá', country: 'Nigeria, Benin', flag: '🇳🇬' },
  { code: 'ig', label: 'Asụsụ Igbo', native: 'Igbo', country: 'Nigeria', flag: '🇳🇬' },
  { code: 'am', label: 'አማርኛ (Amharic)', native: 'አማርኛ', country: 'Ethiopia', flag: '🇪🇹' },
  { code: 'so', label: 'Soomaali', native: 'Somali', country: 'Somalia, Djibouti', flag: '🇸🇴' },
  { code: 'zu', label: 'isiZulu', native: 'Zulu', country: 'South Africa', flag: '🇿🇦' },
  { code: 'xh', label: 'isiXhosa', native: 'Xhosa', country: 'South Africa', flag: '🇿🇦' },
  { code: 'af', label: 'Afrikaans', native: 'Afrikaans', country: 'South Africa, Namibia', flag: '🇿🇦' },
  { code: 'rw', label: 'Ikinyarwanda', native: 'Kinyarwanda', country: 'Rwanda', flag: '🇷🇼' },
  { code: 'mg', label: 'Malagasy', native: 'Malagasy', country: 'Madagascar', flag: '🇲🇬' },
];

export interface DropdownLanguage {
  id: string;
  name: string;
  countryCode: string;
  flagEmoji: string;
  englishLabel: string;
  isRtl?: boolean;
}

// Exactly ordered as requested from the user's reference screenshots (1, 2, 3)
export const DROPDOWN_LANGUAGES: DropdownLanguage[] = [
  // Screenshot 1:
  { id: 'en', name: 'English', countryCode: 'us', flagEmoji: '🇺🇸', englishLabel: 'English' },
  { id: 'ur', name: 'اردو', countryCode: 'pk', flagEmoji: '🇵🇰', englishLabel: 'Urdu', isRtl: true },
  { id: 'ar', name: 'العربية', countryCode: 'sa', flagEmoji: '🇸🇦', englishLabel: 'Arabic', isRtl: true },
  { id: 'fr', name: 'Français', countryCode: 'fr', flagEmoji: '🇫🇷', englishLabel: 'French' },
  { id: 'es', name: 'Español', countryCode: 'es', flagEmoji: '🇪🇸', englishLabel: 'Spanish' },
  { id: 'zh', name: '简体中文', countryCode: 'cn', flagEmoji: '🇨🇳', englishLabel: 'Simplified Chinese' },
  { id: 'hi', name: 'हिन्दी', countryCode: 'in', flagEmoji: '🇮🇳', englishLabel: 'Hindi' },
  { id: 'pt', name: 'Português', countryCode: 'pt', flagEmoji: '🇵🇹', englishLabel: 'Portuguese' },
  { id: 'ru', name: 'Русский', countryCode: 'ru', flagEmoji: '🇷🇺', englishLabel: 'Russian' },
  { id: 'ja', name: '日本語', countryCode: 'jp', flagEmoji: '🇯🇵', englishLabel: 'Japanese' },

  // Screenshot 2:
  { id: 'it', name: 'Italiano', countryCode: 'it', flagEmoji: '🇮🇹', englishLabel: 'Italian' },
  { id: 'tr', name: 'Türkçe', countryCode: 'tr', flagEmoji: '🇹🇷', englishLabel: 'Turkish' },
  { id: 'vi', name: 'Tiếng Việt', countryCode: 'vn', flagEmoji: '🇻🇳', englishLabel: 'Vietnamese' },
  { id: 'th', name: 'ไทย', countryCode: 'th', flagEmoji: '🇹🇭', englishLabel: 'Thai' },
  { id: 'bn', name: 'বাংলা', countryCode: 'bd', flagEmoji: '🇧🇩', englishLabel: 'Bengali' },
  { id: 'fa', name: 'فارسی', countryCode: 'ir', flagEmoji: '🇮🇷', englishLabel: 'Persian', isRtl: true },
  { id: 'pl', name: 'Polski', countryCode: 'pl', flagEmoji: '🇵🇱', englishLabel: 'Polish' },
  { id: 'ms', name: 'Bahasa Melayu', countryCode: 'my', flagEmoji: '🇲🇾', englishLabel: 'Malay' },
  { id: 'id', name: 'Bahasa Indonesia', countryCode: 'id', flagEmoji: '🇮🇩', englishLabel: 'Indonesian' },
  { id: 'nl', name: 'Nederlands', countryCode: 'nl', flagEmoji: '🇳🇱', englishLabel: 'Dutch' },

  // Screenshot 3:
  { id: 'el', name: 'Ελληνικά', countryCode: 'gr', flagEmoji: '🇬🇷', englishLabel: 'Greek' },
  { id: 'ro', name: 'Română', countryCode: 'ro', flagEmoji: '🇷🇴', englishLabel: 'Romanian' },
  { id: 'hu', name: 'Magyar', countryCode: 'hu', flagEmoji: '🇭🇺', englishLabel: 'Hungarian' },
  { id: 'cs', name: 'Čeština', countryCode: 'cz', flagEmoji: '🇨🇿', englishLabel: 'Czech' },
  { id: 'sv', name: 'Svenska', countryCode: 'se', flagEmoji: '🇸🇪', englishLabel: 'Swedish' },
  { id: 'da', name: 'Dansk', countryCode: 'dk', flagEmoji: '🇩🇰', englishLabel: 'Danish' },
  { id: 'fi', name: 'Suomi', countryCode: 'fi', flagEmoji: '🇫🇮', englishLabel: 'Finnish' },
  { id: 'no', name: 'Norsk', countryCode: 'no', flagEmoji: '🇳🇴', englishLabel: 'Norwegian' },
  { id: 'he', name: 'עברית', countryCode: 'il', flagEmoji: '🇮🇱', englishLabel: 'Hebrew', isRtl: true },
];
