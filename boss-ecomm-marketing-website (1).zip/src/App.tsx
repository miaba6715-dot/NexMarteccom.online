/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { UserProfile, OrderItem, Transaction, ActiveTab, SubView, AppNotification, NotificationSettings } from './types';
import { INITIAL_USER, VIP_PLANS, PRODUCT_POOL, INITIAL_ORDERS_HISTORY, INITIAL_TRANSACTIONS } from './data';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { VipPlansView } from './components/VipPlansView';
import { AmazonOrdersView } from './components/AmazonOrdersView';
import { ProfileView } from './components/ProfileView';
import { HistoryView } from './components/HistoryView';
import { SalaryView } from './components/SalaryView';
import { Modals } from './components/Modals';
import { CustomerSupportModal } from './components/CustomerSupportModal';
import { AdminBackend } from './components/AdminBackend';
import { NotificationToastBanner } from './components/NotificationToastBanner';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import {
  getStoredNotifications,
  saveStoredNotifications,
  getNotificationSettings,
  saveNotificationSettings,
  playNotificationSound,
  showBrowserNotification,
  isSalaryClaimedToday,
  markSalaryClaimedToday,
  resetSalaryClaimForToday,
  isQuotaRefreshedToday,
  markQuotaRefreshedToday,
} from './services/notificationService';

export default function App() {
  // Persistent state initialized from localStorage or defaults
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('bam_user');
      return saved ? JSON.parse(saved) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });

  const [orders, setOrders] = useState<OrderItem[]>(() => {
    try {
      const saved = localStorage.getItem('bam_orders');
      return saved ? JSON.parse(saved) : INITIAL_ORDERS_HISTORY;
    } catch {
      return INITIAL_ORDERS_HISTORY;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('bam_txs');
      return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  });

  const [productPool, setProductPool] = useState<Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>[]>(() => {
    try {
      const saved = localStorage.getItem('bam_products_v3');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 25) return parsed;
      }
      return PRODUCT_POOL;
    } catch {
      return PRODUCT_POOL;
    }
  });

  const [currentProductIndex, setCurrentProductIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [subView, setSubView] = useState<SubView>('main');
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeModal, setActiveModal] = useState<'deposit' | 'withdraw' | 'about' | 'services' | 'invite' | 'withdrawal-account' | 'language' | null>(null);
  const [currentLanguage, setCurrentLanguage] = useState(() => {
    try {
      return localStorage.getItem('bam_selected_language') || 'English';
    } catch (e) {
      return 'English';
    }
  });

  // Local Notifications System State
  const [notifications, setNotifications] = useState<AppNotification[]>(() => getStoredNotifications());
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() => getNotificationSettings());
  const [activeNotificationToast, setActiveNotificationToast] = useState<AppNotification | null>(null);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);

  // Sync notifications to localStorage
  useEffect(() => {
    saveStoredNotifications(notifications);
  }, [notifications]);

  const handleUpdateNotificationSettings = (newSettings: NotificationSettings) => {
    setNotificationSettings(newSettings);
    saveNotificationSettings(newSettings);
  };

  const dispatchNotification = (notif: AppNotification) => {
    setNotifications((prev) => [notif, ...prev.filter((n) => n.id !== notif.id)]);
    if (notificationSettings.soundEnabled) {
      playNotificationSound();
    }
    if (notificationSettings.browserEnabled) {
      showBrowserNotification(notif.title, notif.message);
    }
    if (notificationSettings.inAppBannerEnabled) {
      setActiveNotificationToast(notif);
    }
  };

  const triggerQuotaRefreshedNotification = (isManual = false) => {
    const notif: AppNotification = {
      id: `quota-${Date.now()}`,
      type: 'quota_refreshed',
      title: 'Daily Task Quota Refreshed!',
      message: 'Your 25 daily Amazon merchant tasks have been refreshed. Grab orders today to earn VIP commissions!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      actionType: 'navigate_tasks',
      metadata: { quotaTotal: user.totalOrders || 25 },
    };
    markQuotaRefreshedToday();
    dispatchNotification(notif);
  };

  const triggerSalaryAvailableNotification = (isManual = false) => {
    const dailySalary = user.currentVipLevel === 3 ? 50 : user.currentVipLevel === 2 ? 30 : 15;
    const notif: AppNotification = {
      id: `salary-${Date.now()}`,
      type: 'salary_available',
      title: 'VIP Salary Available to Claim!',
      message: `Your daily VIP ${user.currentVipLevel} attendance salary of $${dailySalary}.00 is now ready to claim!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      actionType: 'claim_salary',
      metadata: { salaryAmount: dailySalary, vipLevel: user.currentVipLevel },
    };
    dispatchNotification(notif);
  };

  // Automated detection on mount and periodically
  useEffect(() => {
    // Check if new day quota refresh is needed
    if (!isQuotaRefreshedToday()) {
      setUser((prev) => ({
        ...prev,
        completedOrders: 0,
        todayProfit: 0,
      }));
      resetSalaryClaimForToday();
      triggerQuotaRefreshedNotification();
    } else if (user.completedOrders >= 1 && !isSalaryClaimedToday()) {
      // Check if user has unclaimed salary and hasn't received notification today
      const alreadyNotified = notifications.some(
        (n) => n.type === 'salary_available' && !n.read
      );
      if (!alreadyNotified) {
        triggerSalaryAvailableNotification();
      }
    }

    const interval = setInterval(() => {
      if (!isQuotaRefreshedToday()) {
        setUser((prev) => ({
          ...prev,
          completedOrders: 0,
          todayProfit: 0,
        }));
        resetSalaryClaimForToday();
        triggerQuotaRefreshedNotification();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleNotificationAction = (notif: AppNotification) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
    );
    setActiveNotificationToast(null);

    if (notif.actionType === 'claim_salary') {
      const dailySalary =
        notif.metadata?.salaryAmount ||
        (user.currentVipLevel === 3 ? 50 : user.currentVipLevel === 2 ? 30 : 15);
      if (isSalaryClaimedToday()) {
        alert('Daily VIP salary has already been claimed today.');
        return;
      }
      markSalaryClaimedToday();
      handleClaimSalary(dailySalary);
      const confirmation: AppNotification = {
        id: `sys-${Date.now()}`,
        type: 'system',
        title: 'VIP Salary Received!',
        message: `Successfully credited $${dailySalary}.00 to your available account balance.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: true,
      };
      setNotifications((prev) => [confirmation, ...prev]);
    } else if (notif.actionType === 'navigate_tasks') {
      setSubView('amazon-orders');
    }
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
    saveStoredNotifications([]);
  };

  const handleDeleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleSimulateQuotaRefresh = () => {
    setUser((prev) => ({ ...prev, completedOrders: 0 }));
    triggerQuotaRefreshedNotification(true);
  };

  const handleSimulateSalaryAvailable = () => {
    resetSalaryClaimForToday();
    triggerSalaryAvailableNotification(true);
  };

  const unreadNotificationCount = notifications.filter((n) => !n.read).length;

  const handleSelectLanguage = (langName: string) => {
    setCurrentLanguage(langName);
    try {
      localStorage.setItem('bam_selected_language', langName);
    } catch (e) {}
  };

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bam_user', JSON.stringify(user));
      localStorage.setItem('bam_orders', JSON.stringify(orders));
      localStorage.setItem('bam_txs', JSON.stringify(transactions));
      localStorage.setItem('bam_products_v3', JSON.stringify(productPool));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [user, orders, transactions, productPool]);

  // Derive simulated URL to match the exact URLs in the screenshots
  const getSimulatedUrl = () => {
    if (isAdmin) {
      return 'boostmarketingwithus.com/admin-dashboard.html';
    }
    if (subView === 'amazon-orders') {
      return 'boostmarketingwithus.com/amazon-orders.html';
    }
    switch (activeTab) {
      case 'home':
        return 'boostmarketingwithus.com/user-dashboard.html';
      case 'order':
        return 'boostmarketingwithus.com/user-order.html';
      case 'profile':
        return 'boostmarketingwithus.com/user-profile.html';
      case 'history':
        return 'boostmarketingwithus.com/user-history.html';
      case 'salary':
        return 'boostmarketingwithus.com/user-salary.html';
      default:
        return 'boostmarketingwithus.com/user-dashboard.html';
    }
  };

  // User state updates
  const handleUpdateUser = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
  };

  // Add transaction
  const handleAddTransaction = (tx: Transaction) => {
    setTransactions((prev) => [tx, ...prev]);
  };

  // Submit order & earn commission
  const handleSubmitOrder = (product: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>) => {
    const newCompleted = user.completedOrders + 1;
    const newBalance = Number((user.balance + product.commission).toFixed(2));
    const newTodayProfit = Number((user.todayProfit + product.commission).toFixed(2));
    const newTotalProfit = Number((user.totalProfit + product.commission).toFixed(2));

    const newOrder: OrderItem = {
      id: `ord-${Date.now()}`,
      orderNumber: `BAM-${Math.floor(10000000 + Math.random() * 90000000)}`,
      title: product.title,
      image: product.image,
      thumbnails: product.thumbnails,
      platform: product.platform,
      orderAmount: product.orderAmount,
      commissionRate: product.commissionRate,
      commission: product.commission,
      status: 'Completed',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      position: product.position,
      totalProfit: product.totalProfit,
      type: product.type || 'single',
    };

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'commission',
      amount: product.commission,
      status: 'Approved',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      method: `${product.platform} Order Commission`,
    };

    setUser((prev) => ({
      ...prev,
      completedOrders: newCompleted,
      balance: newBalance,
      todayProfit: newTodayProfit,
      totalProfit: newTotalProfit,
    }));

    setOrders((prev) => [newOrder, ...prev]);
    setTransactions((prev) => [newTx, ...prev]);
    setCurrentProductIndex((prev) => prev + 1);

    // If user completed first order and hasn't claimed salary today, alert them!
    if (newCompleted >= 1 && !isSalaryClaimedToday()) {
      triggerSalaryAvailableNotification();
    }
  };

  // Claim daily salary
  const handleClaimSalary = (amount: number) => {
    const newBalance = Number((user.balance + amount).toFixed(2));
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      type: 'salary',
      amount: amount,
      status: 'Approved',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      method: `VIP ${user.currentVipLevel} Attendance Salary`,
    };

    setUser((prev) => ({
      ...prev,
      balance: newBalance,
    }));
    setTransactions((prev) => [newTx, ...prev]);
  };

  // Admin approves transaction
  const handleApproveTransaction = (txId: string) => {
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === txId) {
          if (t.type === 'deposit') {
            setUser((u) => ({ ...u, balance: Number((u.balance + t.amount).toFixed(2)) }));
          }
          return { ...t, status: 'Approved' };
        }
        return t;
      })
    );
  };

  // Admin rejects transaction
  const handleRejectTransaction = (txId: string) => {
    setTransactions((prev) =>
      prev.map((t) => {
        if (t.id === txId) {
          if (t.type === 'withdraw') {
            // Refund to user
            setUser((u) => ({ ...u, balance: Number((u.balance + t.amount).toFixed(2)) }));
          }
          return { ...t, status: 'Rejected' };
        }
        return t;
      })
    );
  };

  // Reset to default screenshot state
  const handleResetToDefault = () => {
    setUser(INITIAL_USER);
    setOrders(INITIAL_ORDERS_HISTORY);
    setTransactions(INITIAL_TRANSACTIONS);
    setProductPool(PRODUCT_POOL);
    setCurrentProductIndex(0);
    localStorage.clear();
  };

  // Add custom product to pool
  const handleAddProduct = (prod: Omit<OrderItem, 'id' | 'timestamp' | 'status' | 'orderNumber'>) => {
    setProductPool((prev) => [prod, ...prev]);
  };

  // Navigate tab
  const handleSelectTab = (tab: ActiveTab) => {
    setActiveTab(tab);
    setSubView('main');
  };

  // Logout handler
  const handleLogout = () => {
    if (confirm('Are you sure you want to log out of Boss Ecomm Marketing?')) {
      alert('Logged out. Reloading session...');
      handleResetToDefault();
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f4f7] text-slate-800 flex flex-col font-['Plus_Jakarta_Sans',sans-serif] overflow-x-hidden">
      {/* Top Bar with URL Simulator & Backend Switcher */}
      <TopBar
        currentUrl={getSimulatedUrl()}
        isAdmin={isAdmin}
        onToggleAdmin={() => setIsAdmin(!isAdmin)}
        onRefresh={() => window.location.reload()}
        onOpenLanguage={() => setActiveModal('language')}
        currentLanguage={currentLanguage}
        onSelectLanguage={handleSelectLanguage}
        unreadNotificationCount={unreadNotificationCount}
        onOpenNotifications={() => setIsNotificationModalOpen(true)}
      />

      {/* Main Content Area */}
      {isAdmin ? (
        <main className="flex-1 w-full">
          <AdminBackend
            user={user}
            onUpdateUser={handleUpdateUser}
            onVisitSite={() => setIsAdmin(false)}
            productPool={productPool}
            onAddProduct={handleAddProduct}
            onSetProductPool={(prods) => setProductPool(prods)}
          />
        </main>
      ) : (
        <main className="flex-1 w-full max-w-md sm:max-w-xl md:max-w-3xl lg:max-w-5xl xl:max-w-6xl mx-auto px-3 sm:px-6 pt-3 sm:pt-4 pb-28 sm:pb-32">
          {subView === 'amazon-orders' ? (
            <AmazonOrdersView
              user={user}
              currentProductIndex={currentProductIndex}
              productPool={productPool}
              onBack={() => setSubView('main')}
              onSubmitOrder={handleSubmitOrder}
            />
          ) : (
            <>
              {activeTab === 'home' && (
                <HomeView
                  user={user}
                  vipPlans={VIP_PLANS}
                  onOpenModal={(type) => setActiveModal(type)}
                  onNavigateToOrder={(vipLevel) => {
                    if (vipLevel && vipLevel > 1 && user.balance < VIP_PLANS[vipLevel - 1].minBalance) {
                      setActiveTab('order');
                    } else {
                      setSubView('amazon-orders');
                    }
                  }}
                  onLogout={handleLogout}
                  currentLanguage={currentLanguage}
                  onSelectLanguage={handleSelectLanguage}
                  onUpdateUser={handleUpdateUser}
                  unreadNotificationCount={unreadNotificationCount}
                  onOpenNotifications={() => setIsNotificationModalOpen(true)}
                />
              )}

              {activeTab === 'order' && (
                <VipPlansView
                  user={user}
                  vipPlans={VIP_PLANS}
                  onSelectVip={(level) => {
                    if (level === 1) {
                      setSubView('amazon-orders');
                    } else {
                      alert(`VIP ${level} unlocked! Loading merchant tasks.`);
                      setSubView('amazon-orders');
                    }
                  }}
                  onOpenDeposit={() => setActiveModal('deposit')}
                />
              )}

              {activeTab === 'profile' && (
                <ProfileView
                  user={user}
                  onOpenModal={(type) => setActiveModal(type)}
                  onLogout={handleLogout}
                  onUpdateUser={handleUpdateUser}
                />
              )}

              {activeTab === 'history' && (
                <HistoryView orders={orders} transactions={transactions} />
              )}

              {activeTab === 'salary' && (
                <SalaryView user={user} onClaimSalary={handleClaimSalary} />
              )}

              {/* Bottom safe spacer to ensure full visibility above fixed BottomNav */}
              <div className="h-10 sm:h-12 w-full shrink-0" aria-hidden="true" />
            </>
          )}
        </main>
      )}

      {/* Fixed Bottom Navigation (visible when not in admin mode) */}
      {!isAdmin && (
        <BottomNav
          activeTab={subView === 'amazon-orders' ? 'order' : activeTab}
          onSelectTab={handleSelectTab}
        />
      )}

      {/* Modals for Quick Actions (Deposit, Withdraw, Withdrawal Account, Invite, etc.) */}
      <Modals
        isOpen={activeModal !== null && activeModal !== 'services'}
        onClose={() => setActiveModal(null)}
        user={user}
        onUpdateUser={handleUpdateUser}
        onAddTransaction={handleAddTransaction}
        modalType={activeModal}
        currentLanguage={currentLanguage}
        onSelectLanguage={(lang) => setCurrentLanguage(lang)}
      />

      {/* Online Customer Services & Live Support Chat System (Matches Screenshot 1 & 2) */}
      <CustomerSupportModal
        isOpen={activeModal === 'services'}
        onClose={() => setActiveModal(null)}
        user={user}
        initialView="channels"
      />

      {/* Local Notification Floating Toast Banner */}
      <NotificationToastBanner
        notification={activeNotificationToast}
        onClose={() => setActiveNotificationToast(null)}
        onAction={handleNotificationAction}
      />

      {/* Notification Center Modal */}
      <NotificationCenterModal
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        notifications={notifications}
        settings={notificationSettings}
        onUpdateSettings={handleUpdateNotificationSettings}
        onMarkAllRead={handleMarkAllNotificationsRead}
        onClearAll={handleClearAllNotifications}
        onDeleteNotification={handleDeleteNotification}
        onAction={handleNotificationAction}
        onSimulateQuotaRefresh={handleSimulateQuotaRefresh}
        onSimulateSalaryAvailable={handleSimulateSalaryAvailable}
      />
    </div>
  );
}
